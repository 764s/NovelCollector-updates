"""Immutable search modes and per-execution allowances, independent of storage."""
from copy import deepcopy
from dataclasses import dataclass
import math


@dataclass(frozen=True)
class ContentMode:
    start_body: str | None
    sample_chars: int
    keywords: tuple
    strategies: tuple
    version: int = 1

    @classmethod
    def from_config(cls, config, start_body=None):
        from text_strategies import normalize_strategies
        specs = normalize_strategies(config.get('strategies'))
        return cls(start_body, config['sample_chars'],
                   tuple(sorted((k['term'], bool(k.get('focused'))) for k in config['keywords'])),
                   tuple((s['id'], s['version'], s['enabled'], tuple(sorted(s['params'].items()))) for s in specs))

    @classmethod
    def from_binding(cls, value):
        if value.get('version') != 1:
            raise ValueError('不支持的内容种子模式版本')
        return cls.from_config(value, value.get('start_body'))

    def binding(self):
        # Preserve the v1 wire format so existing seeds retain their identity.
        return {'version': self.version, 'start_body': self.start_body, 'sample_chars': self.sample_chars,
                'keywords': [{'term': term, 'focused': focus} for term, focus in self.keywords],
                'strategies': [{'id': key, 'version': version, 'enabled': enabled, 'params': dict(params)}
                               for key, version, enabled, params in self.strategies]}


class ContentExecution:
    """A view of a run's allowance; the v2 persisted field names remain readable.

    Reconstructing this view never allocates an allowance. Only start/continue
    do so; resuming a paused task simply uses the saved values.
    """
    def __init__(self, state):
        self.state = state

    def begin(self, allowance, total_chars, baseline_chars, evidence_count, adaptive):
        state = self.state
        state.update(limit=total_chars + allowance,
                     coverage_reserve=baseline_chars + (math.ceil(allowance * .6) if adaptive else allowance),
                     iteration=state.get('iteration', 0) + 1,
                     iteration_start=evidence_count, iteration_budget=allowance)

    def snapshot(self, total_chars, run_chars):
        state = self.state
        return {'iteration': state.get('iteration', 1),
                'budget_chars': state.get('iteration_budget', state['limit']),
                'scanned_chars': run_chars, 'remaining_chars': max(0, state['limit'] - total_chars),
                'pending': deepcopy(state.get('pending'))}
