"""Progressive sampling configuration; execution budgets do not change a seed."""


def normalize_progressive(value=None):
    value = {} if value is None else value
    if not isinstance(value, dict) or set(value) - {'enabled', 'rounds', 'initial_samples', 'growth'}:
        raise ValueError('无效的逐轮粗筛设置')
    enabled = value.get('enabled', False)
    if type(enabled) is not bool:
        raise ValueError('逐轮粗筛须为布尔值')
    result = {'enabled': enabled}
    for key, default, low, high in (('rounds', 3, 1, 12), ('initial_samples', 2, 1, 64), ('growth', 2, 2, 4)):
        number = value.get(key, default)
        if type(number) is not int or not low <= number <= high:
            raise ValueError(f'{key} 须为 {low}–{high} 的整数')
        result[key] = number
    return result


def round_budget(config, iteration):
    settings = config['progressive']
    count = settings['initial_samples']
    if iteration > 1:
        count *= (settings['growth'] - 1) * settings['growth'] ** min(iteration - 2, 30)
    return min(50000, count * config['sample_chars'])
