"""Discovery behavior against synthetic pages; never accesses a live site."""
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch
from urllib.parse import urlencode

from board_reader import BoardReader, BoardTransportAdapter, normalize_board
from board_search import board_id, seed_config
from core import Manager, validate_config
from data_paths import inspect_data, snapshot_data, DataPathError
from downloader import Downloader
from novel_crawler.adapters.shuku52 import Shuku52Adapter
from novel_crawler.models import CrawlStop, UnknownTemplate
from transport import FetchResult, SafeTransport, PauseRequested

HOME = 'https://www.52shuku.net/'
LIST = HOME + 'wuxia/'
NEXT = LIST + 'index_2.html'


def book_url(name):
    return LIST + name + '.html'


def listing(names, next_url=None):
    return ''.join(f'<h2><a href="{book_url(name)}">书 {name}</a></h2>' for name in names) + (
        f'<div class="pagination"><a href="{next_url}">下一页</a></div>' if next_url else '')


def article(names):
    return '<article class="article-content">' + ''.join(
        f'<p>推荐 <a href="{book_url(name)}">书 {name}</a></p>' for name in names) + '</article>'


class FixtureTransport:
    def __init__(self, factory, **kwargs):
        self.factory, self.adapter = factory, kwargs['adapter']
        self.count, self.maximum = kwargs['request_count'], kwargs['max_requests']
        self.event, self.cancel = kwargs['on_request'], kwargs['cancellation']

    def load_robots(self):
        self.tick(HOME + 'robots.txt')

    def tick(self, url):
        if self.count >= self.maximum:
            raise CrawlStop('request_budget_reached', url)
        self.count += 1
        self.event({'count': self.count, 'event': 'started', 'url': url})

    def fetch(self, url, validators=None):
        return self.answer(url, 'GET', None)

    def fetch_form(self, url, fields):
        return self.answer(url, 'POST', fields)

    def answer(self, url, method, fields):
        self.tick(url)
        self.factory.calls.append((method, url, fields))
        answer = self.factory.pages.get(url)
        if isinstance(answer, Exception):
            raise answer
        if callable(answer):
            answer = answer(self, url)
        if answer is None:
            name = url.rsplit('/', 1)[-1][:-5]
            if name.endswith('_1'):
                answer = '<article class="article-content"><p>第一章</p><p>修仙种田。测试正文。</p><div class="pagination2"></div></article>'
            else:
                answer = f'<h1>书 {name}</h1><article class="article-content"><p>小说简介：</p><li class="mulu"><a href="{url[:-5]}_1.html">正文</a></li></article>'
        return answer if isinstance(answer, FetchResult) else FetchResult(answer, url, 200)

    def close(self):
        pass


class Factory:
    def __init__(self):
        self.pages, self.calls = {}, []

    def __call__(self, **kwargs):
        return FixtureTransport(self, **kwargs)


class BoardTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.factory = Factory()
        self.manager = Manager(self.tmp.name, transport_factory=self.factory, auto_start=False)

    def tearDown(self):
        self.manager.close()
        self.tmp.cleanup()

    def collection(self, mode='category', base=LIST, keys='', offset=0, interval=0, maximum=2, **extra):
        return self.manager.create_collection({'name': '榜测试',
            'board': {'type': mode, 'base_url': base, 'keys': keys},
            'discovery_seed': {'offset': offset, 'interval': interval},
            'keywords': [{'term': '修仙', 'weight': 1}], 'max_books': maximum,
            'chars_per_book': 20, **extra})

    def scan(self, collection, **kwargs):
        job = self.manager.start_scan(collection['id'], **kwargs)
        self.manager._run_job(job['id'])
        return next(j for j in self.manager.snapshot()['jobs'] if j['id'] == job['id'])

    def selected(self, collection):
        return [r[0] for r in self.manager.db.execute(
            'SELECT directory_url FROM discovery_selections WHERE board_id=? ORDER BY selected_at',
            (board_id(collection['board']),))]

    def test_offset_interval_cross_pages_and_continue_without_rereading(self):
        self.factory.pages = {LIST: listing(['a', 'b', 'c'], NEXT), NEXT: listing(['d', 'e', 'f', 'g'])}
        c = self.collection(offset=1, interval=1)
        first = self.scan(c)
        self.assertEqual(first['status'], 'completed', first)
        self.assertEqual(self.selected(c), [book_url('b'), book_url('d')])
        self.factory.calls.clear()
        second = self.scan(c)
        self.assertEqual(second['discovery_stop'], 'board_exhausted')
        self.assertEqual(self.selected(c), [book_url('b'), book_url('d'), book_url('f')])
        self.assertNotIn(LIST, [r[1] for r in self.factory.calls])
        self.assertNotIn(NEXT, [r[1] for r in self.factory.calls])

    def test_defaults_contiguous_and_cached_tail_survives_restart(self):
        c = self.collection(maximum=1)
        self.factory.pages[LIST] = listing(['a', 'b', 'c'])
        self.assertEqual(self.scan(c)['status'], 'completed')
        self.manager.close()
        self.manager = Manager(self.tmp.name, transport_factory=self.factory, auto_start=False)
        self.factory.calls.clear()
        self.assertEqual(self.scan(c)['status'], 'completed')
        self.assertEqual(self.selected(c), [book_url('a'), book_url('b')])
        self.assertNotIn(LIST, [r[1] for r in self.factory.calls])

    def test_refresh_preserves_context_but_recalculates_actual_positions(self):
        c = self.collection(interval=1)
        self.factory.pages[LIST] = listing(['a', 'x', 'b'])
        self.scan(c)
        old_version = self.manager.snapshot()['boards'][0]['current_version']
        self.factory.pages[LIST] = listing(['b', 'z', 'd', 'y', 'a'])
        self.factory.calls.clear()
        job = self.scan(c, refresh_board=True)
        self.assertEqual(job['status'], 'completed', job)
        self.assertEqual(self.selected(c), [book_url('a'), book_url('b'), book_url('d')])
        self.assertEqual(job['progress']['books_done'], 1)
        self.assertNotIn(book_url('a'), [r[1] for r in self.factory.calls])
        self.assertNotIn(book_url('b'), [r[1] for r in self.factory.calls])
        self.assertEqual(self.manager.boards.version(old_version)['status'], 'obsolete')
        board = self.manager.snapshot()['boards'][0]
        self.assertEqual(board['known_books'], 6)
        self.assertEqual(len(self.manager.snapshot()['boards']), 1)

    def test_next_day_refreshes_but_pause_resume_keeps_original_version(self):
        c = self.collection(maximum=1)
        self.factory.pages[LIST] = listing(['a', 'b'])
        with patch('board_search.utcnow', return_value='2026-10-01T09:00:00+00:00'):
            self.scan(c)
        old = self.manager.snapshot()['boards'][0]['current_version']
        self.factory.pages[LIST] = listing(['c', 'a'])
        with patch('board_search.utcnow', return_value='2026-10-02T09:00:00+00:00'):
            job = self.manager.start_scan(c['id'])
            new = self.manager.snapshot()['boards'][0]['current_version']
            self.manager.pause_job(job['id'])
        with patch('board_search.utcnow', return_value='2026-10-03T09:00:00+00:00'):
            self.manager.resume_job(job['id'])
            self.manager._run_job(job['id'])
        self.assertNotEqual(old, new)
        self.assertEqual(self.manager.snapshot()['boards'][0]['current_version'], new)
        self.assertEqual(self.selected(c), [book_url('a'), book_url('c')])

    def test_cross_board_references_reuse_evidence_without_reading_book(self):
        first, second = self.collection(maximum=1), self.collection('annual_article', HOME + 'special/2026.html', maximum=1)
        self.factory.pages = {LIST: listing(['a']), second['board']['base_url']: article(['a']).replace('书 a', '点击阅读')}
        self.scan(first)
        previous = self.manager.snapshot()['results'][0]
        self.factory.calls.clear()
        job = self.scan(second, content_seed='another-content-seed')
        self.assertEqual(job['status'], 'completed', job)
        self.assertEqual(job['progress']['shared_reused_books'], 1)
        self.assertEqual([r[1] for r in self.factory.calls], [second['board']['base_url']])
        row = next(r for r in self.manager.snapshot()['results'] if r['collection_id'] == second['id'])
        self.assertEqual(row['counts'], previous['counts'])
        self.assertEqual(row['checked_at'], previous['checked_at'])
        self.assertEqual(len(row['board_sources']), 2)
        import csv, io
        from main import report_csv
        exported = list(csv.reader(io.StringIO(report_csv([row]).decode('utf-8-sig'))))
        self.assertEqual(json.loads(exported[1][exported[0].index('搜书来源')]), row['board_sources'])
        self.assertEqual(len(row['content_searches']), 1)
        self.assertEqual(self.manager.content.context(book_url('a'))['title'], '书 a')
        stored = json.loads(self.manager.db.execute('SELECT data FROM books WHERE collection_id=?', (second['id'],)).fetchone()[0])
        self.assertIn('evaluation_ref', stored)
        self.assertNotIn('strategy_run', stored)
        self.assertNotIn('counts', stored)

    def test_already_known_books_still_occupy_positions_in_another_board(self):
        first = self.collection(maximum=1)
        self.factory.pages[LIST] = listing(['a'])
        self.scan(first)
        second = self.collection('tag', HOME + 'tag/test/', interval=1)
        self.factory.pages[second['start_url']] = listing(['a', 'b', 'c'])
        job = self.scan(second)
        self.assertEqual(job['status'], 'completed', job)
        self.assertEqual(self.selected(second), [book_url('a'), book_url('c')])
        self.assertEqual(job['progress']['shared_reused_books'], 1)

    def test_duplicate_entries_do_not_compress_positions(self):
        c = self.collection(interval=1, maximum=5)
        self.factory.pages[LIST] = listing(['a', 'x', 'a'], NEXT)
        self.factory.pages[NEXT] = listing(['y', 'c'])
        self.assertEqual(self.scan(c)['status'], 'completed')
        self.assertEqual(self.selected(c), [book_url('a'), book_url('c')])

    def test_same_board_has_one_search_across_collections(self):
        first, second = self.collection(maximum=1), self.collection(maximum=1)
        self.factory.pages[LIST] = listing(['a', 'b', 'c'])
        self.scan(first)
        self.scan(second)
        self.assertEqual(self.selected(second), [book_url('a'), book_url('b')])
        self.assertEqual(self.manager.db.execute('SELECT COUNT(*) FROM discovery_searches').fetchone()[0], 1)
        self.assertEqual(len([r for r in self.manager.snapshot()['results'] if r['collection_id'] == second['id']]), 2)
        conflict = self.collection(offset=1)
        with self.assertRaisesRegex(ValueError, '一个种子'):
            self.manager.start_scan(conflict['id'])

    def test_pause_during_book_read_preserves_pending_selection(self):
        c = self.collection(maximum=1)
        self.factory.pages = {LIST: listing(['a', 'b']), book_url('a'): PauseRequested(book_url('a'))}
        job = self.scan(c)
        self.assertEqual(job['status'], 'paused', job)
        with self.assertRaisesRegex(ValueError, '未完成任务'):
            self.manager.start_scan(c['id'], refresh_board=True)
        self.assertEqual(self.selected(c), [])
        self.manager.close()
        self.manager = Manager(self.tmp.name, transport_factory=self.factory, auto_start=False)
        del self.factory.pages[book_url('a')]
        self.factory.calls.clear()
        self.manager.resume_job(job['id'])
        self.manager._run_job(job['id'])
        self.assertEqual(self.selected(c), [book_url('a')])
        self.assertNotIn(LIST, [r[1] for r in self.factory.calls])

    def test_stopped_book_retries_pending_on_next_run(self):
        c = self.collection(maximum=1)
        self.factory.pages = {LIST: listing(['a', 'b']), book_url('a'): CrawlStop('http_403_access_stop')}
        self.assertEqual(self.scan(c)['status'], 'stopped')
        del self.factory.pages[book_url('a')]
        self.assertEqual(self.scan(c)['status'], 'completed')
        self.assertEqual(self.selected(c), [book_url('a')])

    def test_request_budget_does_not_mark_list_exhausted(self):
        c = self.collection(offset=100)
        self.factory.pages[LIST] = listing(['a'], NEXT)
        self.factory.pages[NEXT] = listing(['b'])
        job = self.manager.start_scan(c['id'])
        state = self.manager._load_state(self.manager._get_job(job['id']))
        state['request_count'] = 158
        self.manager._save_state(job['id'], state)
        self.manager._run_job(job['id'])
        self.assertEqual(self.manager._get_job(job['id'])['error'], 'request_budget_reached')
        self.assertFalse(self.manager.snapshot()['boards'][0]['exhausted'])
        self.factory.calls.clear()
        self.assertEqual(self.scan(c)['status'], 'completed')
        self.assertEqual([r[1] for r in self.factory.calls], [NEXT])

    def test_cycle_stops_without_infinite_requests(self):
        c = self.collection(offset=20)
        self.factory.pages[LIST] = listing(['a'], LIST)
        job = self.scan(c)
        self.assertEqual(job['error'], 'board_pagination_cycle')
        self.assertFalse(self.manager.snapshot()['boards'][0]['exhausted'])
        self.assertEqual(len(self.factory.calls), 1)

    def test_search_get_uses_observed_form_and_observed_next_query(self):
        c = self.collection('site_search', HOME, '修仙', maximum=2)
        search = HOME + 'search?' + urlencode({'q': '修仙', 'sort': 'new'})
        next_search = search + '&page=2'
        self.factory.pages = {
            HOME: '<form action="/search"><input name="q"><input type="hidden" name="sort" value="new"></form>',
            search: listing(['a'], next_search.replace('&', '&amp;')), next_search: listing(['b'])}
        job = self.scan(c)
        self.assertEqual(job['status'], 'completed', job)
        self.assertIn(search, [r[1] for r in self.factory.calls])
        self.assertIn(next_search, [r[1] for r in self.factory.calls])
        self.assertEqual(len(self.manager.snapshot()['boards']), 1)

    def test_search_post_form_and_empty_results(self):
        c = self.collection('site_search', HOME, '不存在')
        target = HOME + 'e/search/index.php'
        self.factory.pages = {HOME: '<form action="/e/search/index.php" method="post"><input name="keyboard"><input type="hidden" name="show" value="title"></form>',
                              target: '<p>没有找到相关结果</p>'}
        job = self.scan(c)
        self.assertEqual(job['discovery_stop'], 'board_exhausted', job)
        self.assertEqual(self.factory.calls[-1], ('POST', target, [['keyboard', '不存在'], ['show', 'title']]))

    def test_missing_search_form_does_not_fall_back_to_category(self):
        c = self.collection('site_search', HOME, '修仙')
        self.factory.pages[HOME] = listing(['a']) + '<a href="/wuxia/">武侠玄幻</a>'
        job = self.scan(c)
        self.assertEqual(job['status'], 'stopped')
        self.assertIn('搜索表单', job['error'])
        self.assertFalse(self.manager.snapshot()['boards'][0]['exhausted'])
        self.assertEqual(self.selected(c), [])

    def test_article_reads_only_its_book_links_and_has_no_pagination(self):
        c = self.collection('article', HOME + 'special/list.html')
        self.factory.pages[c['start_url']] = '<nav><a href="' + book_url('wrong') + '">导航</a></nav>' + article(['a', 'b'])
        self.assertEqual(self.scan(c)['status'], 'completed')
        self.assertEqual(self.selected(c), [book_url('a'), book_url('b')])
        self.assertTrue(self.manager.snapshot()['boards'][0]['exhausted'])

    def test_changed_content_profile_cannot_reuse_old_evaluation(self):
        first = self.collection(maximum=1)
        self.factory.pages[LIST] = listing(['a'])
        self.scan(first)
        second = self.collection('tag', HOME + 'tag/farming/', maximum=1,
                                 keywords=[{'term': '种田', 'weight': 1}])
        self.factory.pages[second['start_url']] = listing(['a'])
        self.factory.calls.clear()
        job = self.scan(second, content_seed='new-terms')
        self.assertEqual(job['status'], 'completed', job)
        self.assertEqual(job['progress']['shared_reused_books'], 0)
        self.assertIn(book_url('a')[:-5] + '_1.html', [r[1] for r in self.factory.calls])

    def test_weights_recompute_reused_results_without_body_fetch(self):
        first = self.collection(maximum=1)
        self.factory.pages[LIST] = listing(['a'])
        self.scan(first)
        second = self.collection('tag', HOME + 'tag/cultivation/', maximum=1,
                                 keywords=[{'term': '修仙', 'weight': 9}])
        self.factory.pages[second['start_url']] = listing(['a'])
        job = self.scan(second)
        self.assertEqual(job['progress']['shared_reused_books'], 1)
        row = next(r for r in self.manager.snapshot()['results'] if r['collection_id'] == second['id'])
        self.assertEqual(row['score'], 9)

    def test_direct_content_continuation_does_not_advance_board(self):
        c = self.collection(maximum=1)
        self.factory.pages[LIST] = listing(['a', 'b'])
        self.scan(c)
        before = self.manager.boards.search(board_id(c['board']))
        job = self.scan(c, content_seed='default', directory_url=book_url('a'))
        self.assertEqual(job['status'], 'completed', job)
        self.assertIsNone(job['board_id'])
        self.assertEqual(self.manager.boards.search(board_id(c['board'])), before)

    def test_backup_preserves_list_versions_progress_and_references(self):
        c = self.collection(maximum=1)
        self.factory.pages[LIST] = listing(['a', 'b'])
        self.scan(c)
        Downloader(self.tmp.name).close()
        with tempfile.TemporaryDirectory() as destination:
            target = Path(destination) / 'backup'
            with self.manager.lock:
                snapshot_data(self.tmp.name, target)
            self.assertEqual(inspect_data(self.tmp.name)['databases'], inspect_data(target)['databases'])
            restored = Manager(target, transport_factory=self.factory, auto_start=False)
            try:
                self.assertEqual(restored.snapshot()['boards'], self.manager.snapshot()['boards'])
                self.assertEqual(restored.snapshot()['results'], self.manager.snapshot()['results'])
            finally:
                restored.close()
        self.manager.db.execute('DROP TABLE discovery_evaluations')
        self.manager.db.commit()
        with self.assertRaisesRegex(DataPathError, '必要表'):
            inspect_data(self.tmp.name)

    def test_observation_failure_rolls_back_context_and_cursor_together(self):
        c = self.collection(maximum=1)
        self.factory.pages[LIST] = listing(['a', 'b'])
        original = self.manager.boards.observe
        def interrupt(*args, **kwargs):
            original(*args, **kwargs)
            raise RuntimeError('simulated persistence failure')
        with patch.object(self.manager.boards, 'observe', side_effect=interrupt):
            self.assertEqual(self.scan(c)['status'], 'failed')
        for table in ('discovery_entries', 'discovery_context', 'content_contexts'):
            self.assertEqual(self.manager.db.execute('SELECT COUNT(*) FROM ' + table).fetchone()[0], 0)
        self.assertEqual(self.manager.snapshot()['boards'][0]['next_position'], 0)
        self.assertEqual(self.scan(c)['status'], 'completed')
        self.assertEqual(self.selected(c), [book_url('a')])

    def test_tag_keys_resolve_an_observed_tag_link(self):
        c = self.collection('tag', HOME + 'tags/', '修仙', maximum=1)
        self.factory.pages = {c['start_url']: '<a rel="tag" href="/tags/cultivation/">修仙</a>',
                              HOME + 'tags/cultivation/': listing(['a'])}
        self.assertEqual(self.scan(c)['status'], 'completed')
        self.assertEqual(self.selected(c), [book_url('a')])

    def test_pre_discovery_paused_content_job_can_resume_after_reweight(self):
        c = self.manager.create_collection({'name': 'old', 'start_url': book_url('a'),
                                            'keywords': [{'term': '修仙'}]})
        job = self.manager.start_scan(c['id'], content_seed='old-content')
        self.manager.pause_job(job['id'])
        old_config = dict(job['config'])
        old_config.pop('board')
        old_config.pop('discovery_seed')
        self.manager.db.execute('UPDATE jobs SET config=? WHERE id=?', (json.dumps(old_config), job['id']))
        self.manager.db.commit()
        self.manager.update_collection(c['id'], {'keywords': [{'term': '修仙', 'weight': 2}]})
        self.manager.resume_job(job['id'])
        self.manager._run_job(job['id'])
        self.assertEqual(self.manager._get_job(job['id'])['status'], 'completed')
        self.assertEqual(self.manager.snapshot()['results'][0]['score'], 2)


class BoardInterfaceTests(unittest.TestCase):
    def setUp(self):
        self.adapter = Shuku52Adapter()

    def test_identity_uses_exact_three_strings_and_seed_is_separate(self):
        values = [dict(type='site_search', base_url=HOME, keys='修仙'),
                  dict(type='site_search', base_url=HOME, keys='种田'),
                  dict(type='tag', base_url=HOME, keys='修仙'),
                  dict(type='site_search', base_url=LIST, keys='修仙')]
        self.assertEqual(len({board_id(v) for v in values}), 4)
        self.assertEqual(seed_config(), {'offset': 0, 'interval': 0})
        for value in ({'offset': True}, {'offset': -1}, {'interval': 1.5}, {'interval': 1_000_001}, {'seed': 'extra'}):
            with self.assertRaises(ValueError):
                seed_config(value)

    def test_board_identity_validation_rejects_unsafe_and_unknown_inputs(self):
        for url in ('https://evil.example/search', HOME + 'a/../search', HOME + '%2e%2e/search', HOME + 'search#fragment',
                    'https://user:pass@www.52shuku.net/', HOME + 'search?q=%0aX', 'http://www.52shuku.net/'):
            with self.subTest(url=url), self.assertRaises(ValueError):
                normalize_board({'type': 'site_search', 'base_url': url, 'keys': '修仙'}, self.adapter)
        for keys in ([], {}, None, '\n'):
            with self.assertRaises(ValueError):
                normalize_board({'type': 'site_search', 'base_url': HOME, 'keys': keys}, self.adapter)

    def test_unicode_tag_addresses_canonicalize_without_allowing_path_tricks(self):
        board = normalize_board({'type': 'tag', 'base_url': HOME + 'tags/修仙/', 'keys': '修仙'}, self.adapter)
        self.assertEqual(board['base_url'], HOME + 'tags/%E4%BF%AE%E4%BB%99/')
        adapter = BoardTransportAdapter(self.adapter)
        adapter.request = {'url': board['base_url'], 'method': 'GET'}
        self.assertEqual(SafeTransport(adapter=adapter)._validate(board['base_url']), board['base_url'])
        for path in ('tags/%2fadmin', 'tags/%252e%252e/', 'tags/%00/', 'tags/%invalid/', 'tags/%ff/'):
            with self.subTest(path=path), self.assertRaises(ValueError):
                normalize_board({'type': 'tag', 'base_url': HOME + path, 'keys': ''}, self.adapter)

    def test_transport_only_allows_observed_query_and_sends_query_to_server(self):
        from test_core import ImmediateGate, FakeResponse
        from novel_crawler.http import Robots
        adapter = BoardTransportAdapter(self.adapter)
        transport = SafeTransport(adapter=adapter, gate=ImmediateGate(),
                                  resolver=lambda *a, **k: [(2, 1, 6, '', ('93.184.216.34', 443))])
        url = HOME + 'search?' + urlencode({'q': '修仙'})
        with self.assertRaises(CrawlStop):
            transport._validate(url)
        adapter.request = {'url': url, 'method': 'GET'}
        self.assertEqual(transport._validate(url), url)
        with self.assertRaises(CrawlStop):
            transport._validate(HOME + 'admin?q=test')
        with self.assertRaises(CrawlStop):
            transport._validate('https://evil.example/search?q=test')
        with self.assertRaises(CrawlStop):
            transport.fetch_form(url, [['q', '修仙']])
        transport.robots = Robots('User-agent: *\nAllow: /', 'crawler')
        with patch('transport._PinnedHTTPSConnection') as connection:
            connection.return_value.getresponse.return_value = FakeResponse(html=listing(['a']))
            transport.fetch(url)
            args = connection.return_value.request.call_args
            self.assertEqual(args.args, ('GET', '/search?' + urlencode({'q': '修仙'})))

    def test_native_post_preserves_form_body_and_follows_303_as_get(self):
        from test_core import ImmediateGate, FakeResponse
        from novel_crawler.http import Robots
        adapter = BoardTransportAdapter(self.adapter)
        target = HOME + 'e/search/index.php'
        fields = [['keyboard', '修仙'], ['show', 'title']]
        adapter.request = {'url': target, 'method': 'POST', 'fields': fields}
        transport = SafeTransport(adapter=adapter, gate=ImmediateGate(),
                                  resolver=lambda *a, **k: [(2, 1, 6, '', ('93.184.216.34', 443))])
        transport.robots = Robots('User-agent: *\nAllow: /', 'crawler')
        with patch('transport._PinnedHTTPSConnection') as connection:
            connection.return_value.getresponse.side_effect = [
                FakeResponse(303, headers={'Location': '/e/search/result/?searchid=abc'}),
                FakeResponse(html=listing(['a']))]
            response = transport.fetch_form(target, fields)
            calls = connection.return_value.request.call_args_list
            self.assertEqual(calls[0].args, ('POST', '/e/search/index.php'))
            self.assertEqual(calls[0].kwargs['body'], urlencode([tuple(p) for p in fields]).encode())
            self.assertEqual(calls[1].args, ('GET', '/e/search/result/?searchid=abc'))
            self.assertEqual(response.final_url, HOME + 'e/search/result/?searchid=abc')

    def test_numbered_pagination_uses_observed_current_and_next_links(self):
        reader = BoardReader(self.adapter, {'type': 'category', 'base_url': LIST, 'keys': ''})
        html = listing(['a']) + '<div class="pagination"><span class="current">1</span><a href="index_2.html">2</a></div>'
        self.assertEqual(reader.read(html, LIST, {'entered': True})[1]['url'], NEXT)

    def test_site_search_rejects_external_form(self):
        reader = BoardReader(self.adapter, {'type': 'site_search', 'base_url': HOME, 'keys': '修仙'})
        with self.assertRaises(UnknownTemplate):
            reader.read('<form action="https://evil.example/search"><input name="q"></form>', HOME, {})

    def test_conflicting_next_links_are_not_silently_exhausted(self):
        reader = BoardReader(self.adapter, {'type': 'category', 'base_url': LIST, 'keys': ''})
        with self.assertRaises(UnknownTemplate):
            reader.read(listing(['a'], NEXT) + '<a rel="next" href="/wuxia/index_3.html">继续</a>', LIST, {'entered': True})


if __name__ == '__main__':
    unittest.main()
