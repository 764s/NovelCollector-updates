"""Persistent content seeds; synthetic text and transport, no website requests."""
from copy import deepcopy
from hashlib import sha256
import json
import tempfile
import unittest
from unittest.mock import patch

from core import Manager
from content_search import validate_seed
from text_strategies import TextScheduler, consumed, intervals
from transport import PauseRequested, FetchResult
from data_paths import inspect_data, snapshot_data, DataPathError
from test_core import DIRECTORY
from test_strategies import URLS, MapTransport, config, finish, prose


class SeedScheduleTests(unittest.TestCase):
    def test_seed_is_repeatable_and_different_seeds_change_positions(self):
        cfg = config(strategies=[{'id': 'distributed'}])
        texts = {url: prose(10000) for url in URLS}
        def schedule(seed):
            scheduler = TextScheduler.create(URLS, cfg, content_seed=seed)
            return [(r['url'], r['start'], r['end']) for r in finish(scheduler, texts, cfg)]
        self.assertEqual(schedule('alpha'), schedule('alpha'))
        self.assertNotEqual(schedule('alpha'), schedule('beta'))
        self.assertEqual(sum(b - a for _, a, b in schedule('alpha')), 400)

    def test_continuation_keeps_pending_and_never_exceeds_smaller_allowance(self):
        cfg = config(strategies=[{'id': 'distributed'}])
        scheduler = TextScheduler.create(URLS[:1], cfg, content_seed='alpha')
        scheduler.register_source(URLS[0], 10000, 'digest')
        first = deepcopy(scheduler.next())
        scheduler.continue_search(3)
        self.assertEqual(scheduler.next()['start'], first['start'])
        self.assertEqual(scheduler.next()['end'], first['start'] + 3)
        finish(scheduler, {URLS[0]: prose(10000)}, cfg)
        self.assertEqual(consumed(scheduler.state), 3)

    def test_seed_input_is_bounded_and_trimmed(self):
        self.assertEqual(validate_seed(' alpha '), 'alpha')
        for seed in ('', '   ', 'a' * 129, '\nalpha', 2, False, {}, []):
            with self.subTest(seed=seed), self.assertRaises(ValueError):
                validate_seed(seed)


class ContentSearchTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.urls, self.texts, self.calls = URLS[:1], {URLS[0]: prose(4000)}, []
        self.factory = lambda **kw: MapTransport(self, **kw)
        self.manager = Manager(self.temp.name, transport_factory=self.factory, auto_start=False)
        self.cfg = config(chars_per_book=120, strategies=[{'id': 'distributed'}])
        self.cid = self.manager.create_collection(self.cfg)['id']

    def tearDown(self):
        self.manager.close()
        self.temp.cleanup()

    def scan(self, seed='alpha', cid=None, directory_url=None):
        job = self.manager.start_scan(cid or self.cid, content_seed=seed, directory_url=directory_url)
        self.manager._run_job(job['id'])
        row = self.manager._get_job(job['id'])
        self.assertEqual(row['status'], 'completed', row['error'])
        return self.manager._job(row)

    def packed(self, seed='alpha'):
        return json.loads(self.manager.content.get(DIRECTORY, seed)['state'])

    def plan(self, seed='alpha'):
        return self.manager.content.unpack(self.packed(seed))

    def result(self, cid=None):
        return next(r for r in self.manager.snapshot()['results'] if r['collection_id'] == (cid or self.cid))

    def pause(self):
        original = TextScheduler.observe
        calls = 0
        def interrupted(scheduler, *args):
            nonlocal calls
            calls += 1
            if calls == 3:
                raise PauseRequested(URLS[0])
            return original(scheduler, *args)
        job = self.manager.start_scan(self.cid, content_seed='alpha')
        with patch.object(TextScheduler, 'observe', interrupted):
            self.manager._run_job(job['id'])
        self.assertEqual(self.manager._get_job(job['id'])['status'], 'paused')
        return job

    def test_same_seed_has_one_search_and_appends_a_new_allowance(self):
        first = self.scan()
        before = self.plan()
        second = self.scan(directory_url=DIRECTORY)
        after = self.plan()
        self.assertNotEqual(first['id'], second['id'])
        self.assertEqual(self.manager.db.execute('SELECT COUNT(*) FROM content_searches').fetchone()[0], 1)
        self.assertEqual(after['evidence'][:len(before['evidence'])], before['evidence'])
        self.assertEqual(consumed(after), 240)
        self.assertEqual(after['iteration'], 2)
        ranges = [(r['start'], r['end']) for r in after['evidence']]
        self.assertEqual(sum(b - a for a, b in intervals(ranges)), 240)
        self.assertEqual(second['progress']['matched_chars'], 120)
        self.assertEqual(self.result()['strategy_summary']['iteration_scanned_chars'], 120)

    def test_seeds_are_isolated_while_context_coverage_is_a_union(self):
        self.scan()
        before = self.packed()
        self.scan('beta')
        self.assertEqual(self.packed(), before)
        a, b = self.plan(), self.plan('beta')
        self.assertNotEqual([(r['start'], r['end']) for r in a['evidence']], [(r['start'], r['end']) for r in b['evidence']])
        total = sum(y - x for x, y in intervals((r['start'], r['end']) for r in a['evidence'] + b['evidence']))
        self.assertEqual(self.result()['scanned_chars'], total)
        self.assertEqual(len(self.result()['content_searches']), 2)

    def test_searches_jobs_and_reports_store_references_not_copied_facts(self):
        job = self.scan()
        states = [self.packed(), json.loads(self.manager._get_job(job['id'])['state'])]
        book = self.manager._book_data(self.cid, DIRECTORY)
        states.append(book['strategy_run'])
        for state in (states[0], states[2]):
            self.assertIn('evidence_refs', state)
            self.assertNotIn('evidence', state)
            self.assertNotIn('metrics', state)
            for ref in state['evidence_refs']:
                self.assertNotIn('counts', ref)
                self.assertTrue(self.manager.content.fact(ref['id']))
        for table in ('content_contexts', 'content_sources', 'content_facts', 'content_searches', 'jobs', 'books'):
            rows = [tuple(r) for r in self.manager.db.execute('SELECT * FROM ' + table)]
            self.assertNotIn('文' * 80, repr(rows))

    def test_exact_shared_observation_reused_without_double_counting(self):
        self.texts[URLS[0]] = '剑' * 10
        self.scan('alpha')
        a = self.packed()
        second = self.scan('beta')
        b = self.packed('beta')
        self.assertEqual(a['evidence_refs'][0]['id'], b['evidence_refs'][0]['id'])
        self.assertEqual(second['progress']['shared_reused_chars'], 10)
        self.assertEqual(self.result()['scanned_chars'], 10)
        self.assertEqual(self.result()['counts']['剑'], 10)
        # A shared fact is still validated against the live source in each job.
        self.assertEqual(sum(url == URLS[0] for url, _ in self.calls), 2)

    def test_304_after_another_seed_updates_context_uses_the_certified_hash(self):
        self.manager.update_collection(self.cid, {'keywords': [
            {'term': '剑', 'weight': 1}, {'term': '雨', 'weight': 1}]})
        self.texts[URLS[0]] = '剑' * 10
        class VersionedTransport(MapTransport):
            def fetch(transport, url, validators=None):
                response = super().fetch(url, validators)
                if url == DIRECTORY:
                    return response
                etag = '"' + sha256(transport.fixture.texts[url].encode()).hexdigest() + '"'
                return FetchResult('', url, 304) if validators and validators.get('etag') == etag else FetchResult(response.html, url, 200, etag)
        self.manager.transport_factory = lambda **kw: VersionedTransport(self, **kw)
        self.scan('primer')
        job = self.manager.start_scan(self.cid, content_seed='alpha')
        with patch.object(TextScheduler, 'observe_cached', side_effect=PauseRequested(URLS[0])):
            self.manager._run_job(job['id'])
        self.assertEqual(self.manager._get_job(job['id'])['status'], 'paused')
        self.assertEqual(consumed(self.plan()), 0)
        self.texts[URLS[0]] = '雨' * 10
        self.scan('beta')
        current_hash = self.manager.content.source(DIRECTORY, URLS[0])['body_hash']
        self.manager.resume_job(job['id'])
        self.manager._run_job(job['id'])
        self.assertEqual(self.manager._get_job(job['id'])['status'], 'completed')
        fact = self.plan()['evidence'][0]
        self.assertEqual(fact['body_hash'], current_hash)
        self.assertEqual(fact['counts'], {'剑': 0, '雨': 10})

    def test_shared_focus_hint_helps_a_new_seed_without_consuming_its_baseline(self):
        self.cfg = config(chars_per_book=400)
        self.manager.update_collection(self.cid, self.cfg)
        probe = TextScheduler.create(self.urls, self.cfg, content_seed='alpha')
        probe.register_source(URLS[0], 4000, 'digest')
        position = probe.next()['start'] + 3
        self.texts[URLS[0]] = prose(4000, {position: '剑'})
        self.scan('alpha')
        self.assertTrue(self.plan()['strategy_state']['focus_neighbors']['regions'])
        own_before = self.packed()
        self.scan('beta')
        plan = self.plan('beta')
        hints = [r for r in plan['strategy_state']['focus_neighbors']['regions'] if r.get('context_ref')]
        self.assertTrue(hints)
        self.assertTrue(any(r['used_chars'] for r in hints))
        self.assertGreaterEqual(consumed(plan, 'distributed'), 240)
        self.assertEqual(consumed(plan), 400)
        self.assertEqual(self.packed(), own_before)
        self.assertTrue(any(reason.get('region_id', '').startswith('context:') for r in plan['evidence']
            for reason in r['reasons'] if isinstance(reason.get('region_id'), str)))

    def test_pause_restart_keeps_exact_pending_and_allowance(self):
        job = self.pause()
        saved = self.packed()
        self.assertEqual(saved['consumed_chars'], 40)
        self.assertIsNotNone(saved['pending']['start'])
        with self.assertRaisesRegex(ValueError, '暂停'):
            self.manager.start_scan(self.cid, content_seed='alpha')
        self.manager.close()
        self.manager = Manager(self.temp.name, transport_factory=self.factory, auto_start=False)
        self.assertEqual(self.packed(), saved)
        # Weight/allowance changes do not reinterpret a paused search. It keeps
        # the original job's allowance, not the newly configured 240 characters.
        self.manager.update_collection(self.cid, {'chars_per_book': 240,
            'keywords': [{'term': '剑', 'weight': 9, 'focused': True}, {'term': '雨', 'weight': 1}]})
        self.manager.resume_job(job['id'])
        self.manager._run_job(job['id'])
        self.assertEqual(self.manager._get_job(job['id'])['status'], 'completed')
        plan = self.plan()
        self.assertEqual(plan['evidence'][2]['start'], saved['pending']['start'])
        self.assertEqual(consumed(plan), 120)
        self.assertEqual(plan['iteration'], 1)

    def test_shared_information_does_not_move_a_paused_seed(self):
        job = self.pause()
        before = self.packed()
        self.scan('beta')
        self.assertEqual(self.packed(), before)
        self.manager.resume_job(job['id'])
        self.manager._run_job(job['id'])
        self.assertEqual(consumed(self.plan()), 120)
        self.assertEqual(self.plan()['evidence'][2]['start'], before['pending']['start'])
        self.assertEqual(self.result()['latest_job_id'], job['id'])
        self.assertEqual(self.result()['strategy_summary']['content_seed'], 'alpha')

    def test_mode_is_bound_but_weights_and_allowance_can_change(self):
        self.scan()
        self.manager.update_collection(self.cid, {'chars_per_book': 73,
            'keywords': [{'term': '剑', 'weight': 8, 'focused': True}, {'term': '雨', 'weight': 1}]})
        self.scan()
        self.assertEqual(consumed(self.plan()), 193)
        self.manager.update_collection(self.cid, {'sample_chars': 19})
        with self.assertRaisesRegex(ValueError, '绑定'):
            self.manager.start_scan(self.cid, content_seed='alpha')
        self.scan('beta')
        self.assertEqual(self.plan('beta')['sample_chars'], 19)

    def test_book_seed_namespace_and_context_are_shared_across_collections(self):
        self.scan()
        second = self.manager.create_collection({**self.cfg, 'name': 'another collection'})['id']
        self.scan(cid=second)
        self.assertEqual(self.manager.db.execute('SELECT COUNT(*) FROM content_searches').fetchone()[0], 1)
        self.assertEqual(consumed(self.plan()), 240)
        self.assertEqual(self.result(second)['scanned_chars'], 240)
        self.assertEqual(self.result()['scanned_chars'], 240)

    def test_changed_source_preserves_history_and_needs_a_new_seed(self):
        self.scan()
        old = self.packed()
        self.texts[URLS[0]] = '改' + self.texts[URLS[0]][1:]
        job = self.manager.start_scan(self.cid, content_seed='alpha')
        self.manager._run_job(job['id'])
        self.assertEqual(self.manager._get_job(job['id'])['error'], 'source_changed_during_scan')
        self.assertEqual(self.packed()['evidence_refs'], old['evidence_refs'])
        with self.assertRaisesRegex(ValueError, '版本'):
            self.manager.start_scan(self.cid, content_seed='alpha')
        self.scan('beta')
        self.assertEqual(self.manager.content.fact(old['evidence_refs'][0]['id'])['body_hash'], self.plan()['evidence'][0]['body_hash'])
        self.assertEqual(self.result()['strategy_summary']['content_seed'], 'beta')

    def test_body_entry_scope_keeps_first_character_and_seed_binding(self):
        self.manager.update_collection(self.cid, {'start_url': URLS[0]})
        self.scan()
        self.assertEqual(self.plan()['evidence'][0]['start'], 0)
        self.assertEqual(sum(url == URLS[0] for url, _ in self.calls), 1)
        self.scan(directory_url=DIRECTORY)
        self.assertEqual(self.plan()['iteration'], 2)

    def test_exhausted_book_continuation_does_not_repeat_observations(self):
        self.texts[URLS[0]] = '文' * 10
        self.scan()
        first = self.packed()['evidence_refs']
        job = self.scan()
        self.assertEqual(self.packed()['evidence_refs'], first)
        self.assertEqual(job['progress']['matched_chars'], 0)
        self.assertEqual(self.result()['strategy_summary']['stop_reason'], 'scope_exhausted')

    def test_legacy_samples_are_adopted_into_shared_context(self):
        job = self.manager.start_scan(self.cid)
        self.manager._run_job(job['id'])
        original = self.result()['pages'][0]['samples']
        self.scan()
        page = self.manager.content.source(DIRECTORY, URLS[0])
        covered = intervals((s['start'], s['end']) for s in page['samples'])
        for sample in original:
            self.assertTrue(any(a <= sample['start'] and sample['end'] <= b for a, b in covered))

    def test_legacy_api_after_seeded_scan_keeps_its_own_fresh_results(self):
        self.scan()
        self.texts[URLS[0]] = '剑' * 4000
        job = self.manager.start_scan(self.cid)
        self.manager._run_job(job['id'])
        result = self.result()
        self.assertIsNone(result['strategy_summary']['content_seed'])
        self.assertEqual(result['counts']['剑'], 120)

    def test_observation_and_seed_cursor_rollback_together_on_write_failure(self):
        original = self.manager.content.save
        interrupted = False
        def fail(directory, plan, job_id, status='running'):
            nonlocal interrupted
            if consumed(plan) > 0 and not interrupted:
                interrupted = True
                raise RuntimeError('simulated interrupted persistence')
            return original(directory, plan, job_id, status)
        job = self.manager.start_scan(self.cid, content_seed='alpha')
        with patch.object(self.manager.content, 'save', fail):
            self.manager._run_job(job['id'])
        self.assertEqual(self.manager._get_job(job['id'])['status'], 'failed')
        self.assertEqual(consumed(self.plan()), 0)
        self.assertIsNone(self.manager.content.source(DIRECTORY, URLS[0]))
        # The exact uncommitted range remains pending and can be tried again.
        pending = self.plan()['pending']
        self.scan()
        self.assertEqual(self.plan()['evidence'][0]['start'], pending['start'])
        self.assertEqual(consumed(self.plan()), 120)

    def test_backup_keeps_seed_references_and_rejects_missing_context_tables(self):
        from pathlib import Path
        from downloader import Downloader
        downloads = Downloader(self.temp.name)
        downloads.close()
        self.scan()
        with tempfile.TemporaryDirectory() as temp:
            target = Path(temp) / 'backup'
            snapshot_data(self.temp.name, target)
            info = inspect_data(target)
            self.assertEqual(info['databases']['app.db']['counts']['content_searches'], 1)
            copy = Manager(target, transport_factory=self.factory, auto_start=False)
            try:
                packed = json.loads(copy.content.get(DIRECTORY, 'alpha')['state'])
                self.assertEqual(consumed(copy.content.unpack(packed)), 120)
            finally:
                copy.close()
        self.manager.db.execute('DROP TABLE content_facts')
        self.manager.db.commit()
        with self.assertRaisesRegex(DataPathError, 'content_facts'):
            inspect_data(self.temp.name)


if __name__ == '__main__':
    unittest.main()
