"""Native HTTPS transport, redirect credentials and failure bounds; no network."""
import io
import ssl
import unittest
from email.message import Message
from unittest.mock import Mock, patch
from urllib.error import HTTPError, URLError

import release_http as transport


TOKEN = 'github_pat_' + 'private_example_' * 4


class Response(io.BytesIO):
    status = 200

    def __init__(self, data=b'{}', **headers):
        super().__init__(data)
        self.headers = headers


def error(code, location=None):
    headers = Message()
    if location is not None:
        headers['Location'] = location
    return HTTPError('https://api.github.com/secret', code, TOKEN, headers, io.BytesIO(TOKEN.encode()))


class ReleaseHTTPTests(unittest.TestCase):
    def read(self, *, replies=None, **kwargs):
        opener = Mock()
        opener.open.side_effect = replies or [Response()]
        with patch.object(transport, 'build_opener', return_value=opener):
            result = transport.read_api('764s/NovelCollector-updates', **kwargs)
        return result, opener

    def test_anonymous_api_uses_https_without_credentials(self):
        result, opener = self.read()
        self.assertEqual(result, b'{}')
        request = opener.open.call_args.args[0]
        self.assertEqual(request.full_url, 'https://api.github.com/repos/764s/NovelCollector-updates/releases/latest')
        self.assertIsNone(request.get_header('Authorization'))
        self.assertEqual(request.get_header('Accept'), 'application/vnd.github+json')

    def test_https_certificate_verification_remains_enabled(self):
        with patch.object(transport, 'build_opener', return_value=Mock(open=Mock(return_value=Response()))) as build:
            transport.read_api('764s/NovelCollector-updates')
        context = build.call_args.args[1]._context
        self.assertEqual(context.verify_mode, ssl.CERT_REQUIRED)
        self.assertTrue(context.check_hostname)

    def test_asset_redirect_drops_authorization(self):
        location = 'https://release-assets.githubusercontent.com/github-production-release-asset/file?sig=temporary'
        result, opener = self.read(asset_id=456,
                                   replies=[error(302, location), Response(b'archive')])
        self.assertEqual(result, b'archive')
        first, second = [call.args[0] for call in opener.open.call_args_list]
        self.assertEqual(first.full_url, 'https://api.github.com/repos/764s/NovelCollector-updates/releases/assets/456')
        self.assertIsNone(first.get_header('Authorization'))
        self.assertEqual(second.full_url, location)
        self.assertIsNone(second.get_header('Authorization'))

    def test_redirects_cannot_leak_credentials_or_access_arbitrary_hosts(self):
        for location in ('http://release-assets.githubusercontent.com/x', 'https://evil.test/x',
                         'https://api.github.com/user', 'https://github.com/x', 'file:///etc/passwd',
                         'https://release-assets.githubusercontent.com.evil.test/x',
                         'https://user:pass@release-assets.githubusercontent.com/x',
                         'https://release-assets.githubusercontent.com:8443/x',
                         'https://release-assets.githubusercontent.com/x\nsecret', '//evil.test/x', None):
            with self.subTest(location=location), self.assertRaises(transport.ReleaseHTTPError) as raised:
                self.read(asset_id=456, replies=[error(302, location)])
            self.assertEqual(raised.exception.status, 'unsafe_redirect')
            self.assertNotIn(TOKEN, str(raised.exception))

    def test_metadata_redirect_and_redirect_loop_are_rejected(self):
        redirect = lambda: error(302, 'https://release-assets.githubusercontent.com/x')
        for kwargs in ({'replies':[redirect()]},
                       {'asset_id':456, 'replies':[redirect() for _ in range(transport.MAX_REDIRECTS + 1)]}):
            with self.assertRaises(transport.ReleaseHTTPError) as raised:
                self.read(**kwargs)
            self.assertEqual(raised.exception.status, 'unsafe_redirect')

    def test_http_errors_are_sanitized(self):
        for code, status in ((401, 'auth_required'), (404, 'access_or_missing'),
                             (403, 'access_denied'), (429, 'rate_limited'), (503, 'network_error')):
            with self.subTest(code=code), self.assertRaises(transport.ReleaseHTTPError) as raised:
                self.read(replies=[error(code)])
            self.assertEqual(str(raised.exception), status)

    def test_403_uses_rate_limit_and_sso_headers_without_exposing_server_text(self):
        for header, value, status in (('X-RateLimit-Remaining', '0', 'rate_limited'),
                                      ('Retry-After', '60', 'rate_limited'),
                                      ('X-GitHub-SSO', 'required; url=' + TOKEN, 'sso_required')):
            response = error(403)
            response.headers[header] = value
            with self.assertRaises(transport.ReleaseHTTPError) as raised:
                self.read(replies=[response])
            self.assertEqual(str(raised.exception), status)
            self.assertNotIn(TOKEN, str(raised.exception))

    def test_streaming_limit_and_content_length_are_bounded(self):
        for response in (Response(b'x' * 11), Response(b'x', **{'Content-Length':'11'})):
            with self.assertRaises(transport.ReleaseHTTPError) as raised:
                self.read(replies=[response], limit=10)
            self.assertEqual(raised.exception.status, 'response_too_large')
            self.assertTrue(response.closed)
        self.assertEqual(self.read(replies=[Response(b'x' * 10, **{'Content-Length':'10'})], limit=10)[0], b'x' * 10)

    def test_truncation_and_unexpected_encoding_are_errors(self):
        for response, status in ((Response(b'x', **{'Content-Length':'2'}), 'network_error'),
                                 (Response(b'x', **{'Content-Length':'-1'}), 'invalid_release'),
                                 (Response(b'x', **{'Content-Encoding':'gzip'}), 'invalid_release')):
            with self.assertRaises(transport.ReleaseHTTPError) as raised:
                self.read(replies=[response])
            self.assertEqual(raised.exception.status, status)

    def test_connection_errors_and_deadlines_do_not_expose_private_details(self):
        for failure, status in ((TimeoutError(TOKEN), 'timeout'), (URLError(TimeoutError(TOKEN)), 'timeout'),
                                (URLError(TOKEN), 'network_error'), (ssl.SSLError(TOKEN), 'network_error')):
            with self.assertRaises(transport.ReleaseHTTPError) as raised:
                self.read(replies=[failure])
            self.assertEqual(str(raised.exception), status)
        with patch.object(transport.time, 'monotonic', side_effect=[0, 31]), \
                self.assertRaises(transport.ReleaseHTTPError) as raised:
            self.read()
        self.assertEqual(raised.exception.status, 'timeout')

    def test_invalid_ids_never_open_a_connection(self):
        for kwargs in ({'asset_id':True}, {'asset_id':'../user'}, {'asset_id':0}):
            with self.subTest(kwargs=list(kwargs)), patch.object(transport, 'build_opener') as opener, \
                    self.assertRaises(transport.ReleaseHTTPError):
                transport.read_api('764s/NovelCollector-updates', **kwargs)
            opener.assert_not_called()


if __name__ == '__main__':
    unittest.main()
