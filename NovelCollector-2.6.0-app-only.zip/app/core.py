"""Durable, literal-keyword sampling; never persist body HTML or complete prose."""
from datetime import datetime, timezone
from hashlib import sha256
import json
import math
from pathlib import Path
import sqlite3
import threading
import uuid

from novel_crawler.adapters.shuku52 import Shuku52Adapter
from novel_crawler.models import Book, CrawlStop, UnknownTemplate
from transport import SafeTransport, PauseRequested, utcnow
from text_strategies import TextScheduler, normalize_strategies, summarize, update_samples, consumed
from content_search import ContentSearchStore, validate_seed, binding
from board_search import BoardStore, seed_config, board_id
from board_reader import BoardTransportAdapter
from data_compat import minimum_reader_version
from progressive import normalize_progressive


def _dump(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)


def validate_config(config, adapter=None):
    adapter = adapter or Shuku52Adapter()
    if not isinstance(config, dict):
        raise ValueError('collection config must be an object')
    name = config.get('name', '新建采集组')
    if not isinstance(name, str) or not name.strip() or len(name) > 120:
        raise ValueError('name must contain 1–120 characters')
    board = adapter.normalize_board(config['board']) if config.get('board') is not None else None
    discovery_seed = seed_config(config.get('discovery_seed'))
    raw_url = board['base_url'] if board else (config.get('start_url') or adapter.definition.homepage)
    # Seed normalization is adapter-owned; reject credential/query/fragment tricks.
    from urllib.parse import urlsplit
    try:
        parts = urlsplit(raw_url)
        if not board and (parts.scheme != 'https' or parts.username or parts.password or parts.query or parts.fragment
                or parts.port not in (None, 443) or '\\' in raw_url or '%' in raw_url
                or any(ord(c) <= 32 for c in raw_url) or any(segment in ('.', '..') for segment in parts.path.split('/'))):
            raise ValueError()
        url = board['base_url'] if board else adapter.seed_kind(raw_url)[1]
    except (ValueError, TypeError, AttributeError):
        raise ValueError('start_url must be a recognized HTTPS 52shuku page')
    keywords = config.get('keywords', [])
    if not isinstance(keywords, list) or not 1 <= len(keywords) <= 100:
        raise ValueError('provide 1–100 distinct keywords')
    seen, normalized = set(), []
    for row in keywords:
        if not isinstance(row, dict):
            raise ValueError('each keyword must have term and weight')
        term, weight = row.get('term'), row.get('weight', 1)
        if not isinstance(term, str) or not term or not term.strip() or len(term) > 64 or term in seen:
            raise ValueError('keywords must be distinct nonempty literals of at most 64 characters')
        if isinstance(weight, bool) or not isinstance(weight, (int, float)) or not math.isfinite(weight) or not 0 <= weight <= 100:
            raise ValueError('keyword weights must be finite numbers from 0 to 100')
        focused = row.get('focused', False)
        if type(focused) is not bool:
            raise ValueError('特别关注必须为布尔值')
        seen.add(term)
        normalized.append({'term': term, 'weight': weight, 'focused': focused})
    bounds = {}
    progressive = normalize_progressive(config.get('progressive'))
    if 'pages_per_book' in config and (type(config['pages_per_book']) is not int or not 1 <= config['pages_per_book'] <= 20):
        raise ValueError('legacy pages_per_book must be 1–20')
    for key, default, maximum in (('max_books', 1000 if progressive['enabled'] else 5, 10000 if progressive['enabled'] else 5),
            ('chars_per_book', config.get('pages_per_book', 20) * 200, 50000), ('sample_chars', 200, 2000)):
        value = config.get(key, default)
        if type(value) is not int or not 1 <= value <= maximum:
            raise ValueError(f'{key} must be 1–{maximum}')
        bounds[key] = value
    strategies = normalize_strategies(config.get('strategies'))
    if progressive['enabled']:
        strategies = [{'id': 'progressive_distributed'}, *[
            item for item in strategies if item['id'] == 'focus_neighbors']]
        if progressive['initial_samples'] * bounds['sample_chars'] > 50000:
            raise ValueError('首轮采样字数不能超过 50000')
    elif any(s['id'] == 'progressive_distributed' and s['enabled'] for s in strategies):
        raise ValueError('逐轮分布策略需要启用逐轮粗筛')
    return {'name': name.strip(), 'start_url': url, 'keywords': normalized,
            'board': board, 'discovery_seed': discovery_seed,
            'strategies': normalize_strategies(strategies), 'progressive': progressive, **bounds,
            'max_body_pages': 100, 'max_requests': 160, 'interval': 3.2}


class Manager:
    """Public API uses ordinary JSON dictionaries; auto_start=False is for tests.

    Restarted running jobs become paused and keep their cursor/request budget.
    transport_factory accepts SafeTransport's keyword arguments.
    """
    def __init__(self, data_dir, transport_factory=None, adapter=None, auto_start=True):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.adapter = adapter or Shuku52Adapter()
        self.transport_factory = transport_factory or SafeTransport
        self.auto_start = auto_start
        self.lock = threading.RLock()
        self.db = sqlite3.connect(self.data_dir / 'app.db', check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA foreign_keys=ON')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS collections(
            id TEXT PRIMARY KEY, config TEXT NOT NULL, revision INTEGER NOT NULL,
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS jobs(
            id TEXT PRIMARY KEY, collection_id TEXT NOT NULL REFERENCES collections(id),
            status TEXT NOT NULL, config TEXT NOT NULL, revision INTEGER NOT NULL,
            state TEXT NOT NULL, error TEXT, created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL, finished_at TEXT);
        CREATE TABLE IF NOT EXISTS books(
            collection_id TEXT NOT NULL, directory_url TEXT NOT NULL, data TEXT NOT NULL,
            PRIMARY KEY(collection_id,directory_url));
        CREATE TABLE IF NOT EXISTS pages(
            collection_id TEXT NOT NULL, directory_url TEXT NOT NULL, url TEXT NOT NULL,
            data TEXT NOT NULL, PRIMARY KEY(collection_id,directory_url,url));
        ''')
        self.content = ContentSearchStore(self.db)
        self.boards = BoardStore(self.db)
        self.db.execute('CREATE INDEX IF NOT EXISTS books_directory ON books(directory_url)')
        now = utcnow()
        self.db.execute("UPDATE jobs SET status='paused',error='interrupted_restart',updated_at=? WHERE status IN ('running','queued','pausing')", (now,))
        self.db.execute("UPDATE discovery_searches SET status='paused' WHERE status IN ('running','queued','pausing')")
        self.db.commit()
        self.active_job = None
        self.worker = None
        self.cancel = threading.Event()
        self.closed = False

    def _collection(self, row):
        return {**validate_config(json.loads(row['config']), self.adapter), 'id': row['id'], 'revision': row['revision'],
                'created_at': row['created_at'], 'updated_at': row['updated_at']}

    def _get_collection(self, collection_id):
        row = self.db.execute('SELECT * FROM collections WHERE id=?', (collection_id,)).fetchone()
        if row is None:
            raise KeyError('collection not found')
        return row

    def create_collection(self, config):
        config = validate_config(config, self.adapter)
        with self.lock:
            key, now = uuid.uuid4().hex, utcnow()
            self.db.execute('INSERT INTO collections VALUES(?,?,?,?,?)', (key, _dump(config), 1, now, now))
            self.db.commit()
            return self._collection(self._get_collection(key))

    def update_collection(self, collection_id, config):
        with self.lock:
            row = self._get_collection(collection_id)
            if self.db.execute("SELECT 1 FROM jobs WHERE collection_id=? AND status IN ('running','pausing','queued')", (collection_id,)).fetchone():
                raise ValueError('pause the collection job before changing its configuration')
            merged = {**json.loads(row['config']), **config}
            config = validate_config(merged, self.adapter)
            if config.get('board'):
                search = self.boards.search(board_id(config['board']))
                if search and search['config'] != config['discovery_seed']:
                    raise ValueError('此榜已有唯一种子，请沿用其开始偏移和固定间隔')
            if config['start_url'] != json.loads(row['config'])['start_url'] and self.db.execute('SELECT 1 FROM books WHERE collection_id=?', (collection_id,)).fetchone():
                raise ValueError('已有结果，请新建搜集器更换起始页面')
            old_board = json.loads(row['config']).get('board')
            if old_board and old_board != config.get('board') and self.db.execute('SELECT 1 FROM books WHERE collection_id=?', (collection_id,)).fetchone():
                raise ValueError('已有结果，请新建搜集器更换榜身份')
            old_terms = {item['term'] for item in json.loads(row['config'])['keywords']}
            new_terms = {item['term'] for item in config['keywords']}
            self.db.execute('UPDATE collections SET config=?,revision=revision+1,updated_at=? WHERE id=?', (_dump(config), utcnow(), collection_id))
            if old_terms != new_terms:
                for saved in self.db.execute('SELECT directory_url,data FROM books WHERE collection_id=?', (collection_id,)).fetchall():
                    metadata = json.loads(saved['data'])
                    metadata.update(snippets=[], snippet_sources=[])
                    self.db.execute('UPDATE books SET data=? WHERE collection_id=? AND directory_url=?', (_dump(metadata), collection_id, saved['directory_url']))
            self.db.commit()
            return self._collection(self._get_collection(collection_id))

    def _get_job(self, job_id):
        row = self.db.execute('SELECT * FROM jobs WHERE id=?', (job_id,)).fetchone()
        if row is None:
            raise KeyError('job not found')
        return row

    def _job(self, row):
        state = json.loads(row['state'])
        progress = {key: state.get(key, 0) for key in ('request_count', 'body_attempts', 'successful_body_pages', 'books_done', 'reused_304', 'reused_hash', 'recounted', 'matched_chars', 'shared_reused_chars', 'shared_reused_books')}
        progress.update(stage=state.get('stage'), current_url=state.get('current_url'),
                        discovered_books=len(state.get('directories', [])),
                        max_books=json.loads(row['config'])['max_books'], max_body_pages=100, max_requests=160)
        if state.get('progressive'):
            progress.update(progressive=True, round_index=state.get('round_index', 1),
                rounds=json.loads(row['config'])['progressive']['rounds'],
                round_done=state.get('round_cursor', 0), discovered_books=len(state.get('directories', [])),
                request_batch=state.get('request_batch', 1), batch_requests=state.get('batch_requests', 0),
                reused_directories=state.get('reused_directories', 0),
                max_body_pages=None, max_requests=None, max_requests_per_batch=160)
        return {'id': row['id'], 'collection_id': row['collection_id'], 'status': row['status'],
                'state': row['status'], 'config': json.loads(row['config']), 'revision': row['revision'],
                'content_seed': state.get('content_seed'),
                'board_id': state.get('board_id'), 'discovery_stop': state.get('discovery_stop'),
                'progress': progress, 'error': row['error'], 'created_at': row['created_at'],
                'updated_at': row['updated_at'], 'finished_at': row['finished_at']}

    def _save_state(self, job_id, state):
        with self.lock, self.db:
            self.db.execute('UPDATE jobs SET state=?,updated_at=? WHERE id=?', (_dump(self._pack_state(job_id, state)), utcnow(), job_id))
            self.db.commit()

    def _pack_state(self, job_id, state, status='running'):
        if state.get('text_plan', {}).get('content_seed'):
            directory = state['current_book']['url']
            return {**state, 'text_plan': self.content.save(directory, state['text_plan'], job_id, status)}
        return state

    def _load_state(self, row):
        state = json.loads(row['state'])
        if 'text_plan' in state:
            state['text_plan'] = self.content.unpack(state['text_plan'])
        return state

    def _book_record(self, directory, data):
        if data.get('strategy_run', {}).get('content_seed'):
            return {**data, 'strategy_run': self.content.pack(directory, data['strategy_run'])}
        return data

    def _activate(self, job_id):
        if self.closed:
            raise RuntimeError('manager is closed')
        if self.active_job is not None:
            raise ValueError('another collection job is already active')
        self.active_job = job_id
        self.cancel = threading.Event()
        self.db.execute("UPDATE jobs SET status='running',error=NULL,finished_at=NULL,updated_at=? WHERE id=?", (utcnow(), job_id))
        state = json.loads(self._get_job(job_id)['state'])
        if state.get('board_id'):
            self.boards.finish(state['board_id'], job_id, 'running')
        self.db.commit()
        if self.auto_start:
            self.worker = threading.Thread(target=self._run_job, args=(job_id, self.cancel), daemon=True, name='novel-collector')
            self.worker.start()

    def start_scan(self, collection_id, content_seed=None, directory_url=None, refresh_board=False):
        with self.lock, self.db:
            if self.active_job is not None:
                raise ValueError('another collection job is already active')
            row = self._get_collection(collection_id)
            config = validate_config(json.loads(row['config']), self.adapter)
            if type(refresh_board) is not bool:
                raise ValueError('refresh_board 须为布尔值')
            is_board = bool(config.get('board')) and directory_url is None
            kind, url = ('board', config['board']['base_url']) if is_board else (
                ('directory', directory_url) if config.get('board') else self.adapter.seed_kind(config['start_url']))
            if refresh_board and not is_board:
                raise ValueError('只有榜单搜索可以刷新榜版本')
            if (is_board or config['progressive']['enabled']) and content_seed is None:
                content_seed = 'progressive' if config['progressive']['enabled'] else 'default'
            start_body = url if kind == 'body' else None
            if directory_url is not None:
                if not content_seed or not self._book_data(collection_id, directory_url):
                    raise ValueError('只能继续此搜集器中已发现书目的内容种子')
                kind, url = 'directory', directory_url
            if content_seed is not None:
                content_seed = validate_seed(content_seed)
                for job in ([] if is_board else self.db.execute("SELECT state FROM jobs WHERE collection_id=? AND status='paused'", (collection_id,))):
                    paused = json.loads(job['state'])
                    remaining = paused.get('directories', [])[paused.get('book_index', 0):]
                    if paused.get('content_seed') == content_seed and (directory_url is None
                            or not paused.get('directories') or directory_url in remaining):
                        raise ValueError('此内容种子有暂停任务，请恢复原任务；恢复不会增加字数额度')
                directories = [url] if kind == 'directory' else [r[0] for r in self.db.execute(
                    'SELECT directory_url FROM books WHERE collection_id=?', (collection_id,))]
                for directory in ([] if is_board else directories):
                    self.content.check(self.content.get(directory, content_seed), config, start_body)
            # Snippets are deliberately scoped to this explicit scan, never an old one.
            for saved in self.db.execute('SELECT directory_url,data FROM books WHERE collection_id=?', (collection_id,)).fetchall():
                metadata = json.loads(saved['data'])
                metadata.update(snippets=[], snippet_sources=[])
                self.db.execute('UPDATE books SET data=? WHERE collection_id=? AND directory_url=?', (_dump(metadata), collection_id, saved['directory_url']))
            state = {'stage': 'seed', 'seed_kind': kind, 'seed_url': url, 'directories': [],
                     'book_index': 0, 'books_done': 0, 'body_attempts': 0,
                     'successful_body_pages': 0, 'request_count': 0, 'reused_304': 0,
                     'reused_hash': 0, 'recounted': 0, 'current_url': url, 'sampling_version': 2, 'matched_chars': 0}
            if content_seed is not None:
                state.update(content_seed=content_seed, shared_reused_chars=0)
                if start_body:
                    state['seed_body_url'] = start_body
            key, now = uuid.uuid4().hex, utcnow()
            if is_board:
                identity = self.boards.open(config['board'], config['discovery_seed'], key, refresh_board)
                state.update(stage='board', board_id=identity, shared_reused_books=0)
                # Collections reference a board's one shared search, including
                # selections made through another collection using that board.
                for selection in self.db.execute('SELECT * FROM discovery_selections WHERE board_id=?', (identity,)).fetchall():
                    if not self._book_data(collection_id, selection['directory_url']):
                        self._link_discovered_book(collection_id, selection['directory_url'], config,
                            {**dict(selection)}, key)
            if config['progressive']['enabled']:
                state.update(progressive=True, stage='discover' if is_board else 'seed',
                    round_index=1, round_cursor=0, round_queue=[], round_scores={},
                    request_batch=1, batch_requests=0, request_offset=0, reused_directories=0)
                if is_board:
                    state['directories'] = [r[0] for r in self.db.execute(
                        'SELECT directory_url FROM books WHERE collection_id=? ORDER BY rowid LIMIT ?',
                        (collection_id, config['max_books']))]
            self.db.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?,?,?,?,?)',
                            (key, collection_id, 'queued', _dump(config), row['revision'], _dump(state), None, now, now, None))
            self.db.commit()
            self._activate(key)
            return self._job(self._get_job(key))

    def pause_job(self, job_id):
        with self.lock:
            row = self._get_job(job_id)
            if row['status'] == 'paused':
                return self._job(row)
            if self.active_job != job_id or row['status'] not in ('running', 'pausing'):
                raise ValueError('only an active job can be paused')
            self.cancel.set()
            if not self.auto_start:
                self.active_job = None
                self.db.execute("UPDATE jobs SET status='paused',updated_at=? WHERE id=?", (utcnow(), job_id))
                state = json.loads(row['state'])
                if state.get('board_id'):
                    self.boards.finish(state['board_id'], job_id, 'paused')
            else:
                self.db.execute("UPDATE jobs SET status='pausing',updated_at=? WHERE id=?", (utcnow(), job_id))
            self.db.commit()
            return self._job(self._get_job(job_id))

    def resume_job(self, job_id):
        with self.lock:
            row = self._get_job(job_id)
            if row['status'] != 'paused':
                raise ValueError('only paused jobs can resume; stopped jobs require a new scan')
            collection = self._get_collection(row['collection_id'])
            if collection['revision'] != row['revision']:
                state = json.loads(row['state'])
                old = validate_config(json.loads(row['config']), self.adapter)
                current = validate_config(json.loads(collection['config']), self.adapter)
                if (not state.get('content_seed') or binding(old) != binding(current) or old['start_url'] != current['start_url']
                        or old.get('board') != current.get('board') or old.get('discovery_seed') != current.get('discovery_seed')):
                    raise ValueError('configuration changed; start a new scan with a new content seed instead')
            self._activate(job_id)
            return self._job(self._get_job(job_id))

    def _book_data(self, collection_id, directory_url):
        with self.lock:
            row = self.db.execute('SELECT data FROM books WHERE collection_id=? AND directory_url=?', (collection_id, directory_url)).fetchone()
            return self.boards.resolve(json.loads(row[0])) if row else None

    def _put_book(self, collection_id, directory_url, data):
        with self.lock, self.db:
            self.db.execute('INSERT OR REPLACE INTO books VALUES(?,?,?)', (collection_id, directory_url, _dump(self._book_record(directory_url, data))))
            self.db.commit()

    def _page_data(self, collection_id, directory_url, url):
        with self.lock:
            row = self.db.execute('SELECT data FROM pages WHERE collection_id=? AND directory_url=? AND url=?', (collection_id, directory_url, url)).fetchone()
            return json.loads(row[0]) if row else None

    def _put_page(self, collection_id, directory_url, url, data):
        with self.lock:
            self.db.execute('INSERT OR REPLACE INTO pages VALUES(?,?,?,?)', (collection_id, directory_url, url, _dump(data)))
            self.db.commit()

    def _link_discovered_book(self, cid, directory, config, source, job_id):
        """Adopt compatible completed evidence without refreshing book content."""
        reference = self.boards.reusable(directory, config)
        if not reference:
            # Lazily adopt pre-discovery content scans; migration never invents
            # list positions or advances the board seed.
            for saved in self.db.execute('SELECT data FROM books WHERE directory_url=?', (directory,)).fetchall():
                metadata = self.boards.resolve(json.loads(saved[0]))
                run = metadata.get('strategy_run', {})
                if run.get('content_seed') and run.get('status') == 'completed':
                    origin = self.db.execute('SELECT config FROM jobs WHERE id=?', (run['job_id'],)).fetchone()
                    if origin:
                        self.boards.remember(directory, json.loads(origin[0]), metadata)
            reference = self.boards.reusable(directory, config)
        if reference:
            record = {'evaluation_ref': reference, 'board_source': source,
                      'discovery_reused': True, 'discovered_job_id': job_id}
        else:
            context = self.content.context(directory) or {}
            record = self._book_data(cid, directory) or {'directory_url': directory,
                'title': context.get('title', ''), 'body_urls': [], 'snippets': [], 'snippet_sources': []}
            record.update(board_source=source, discovered_job_id=job_id)
        self.db.execute('INSERT OR REPLACE INTO books VALUES(?,?,?)', (cid, directory, _dump(record)))
        return reference

    @staticmethod
    def _covered(page, terms):
        return bool(page and page.get('body_hash') and all(term in page.get('counts', {}) for term in terms))

    def _finish(self, job_id, status, error=None):
        with self.lock, self.db:
            row = self._get_job(job_id)
            state = self._load_state(row)
            if state.get('stage') == 'body' and state.get('text_plan'):
                directory = state['current_book']['url']
                metadata = self._book_data(row['collection_id'], directory)
                planner = TextScheduler(state['text_plan'])
                metadata['latest_job_id'] = job_id
                if planner.state.get('content_seed'):
                    metadata['content_seed'] = planner.state['content_seed']
                metadata['strategy_run'] = planner.report(job_id, row['revision'], status, error)
                self.db.execute('UPDATE books SET data=? WHERE collection_id=? AND directory_url=?',
                                (_dump(self._book_record(directory, metadata)), row['collection_id'], directory))
            self.db.execute('UPDATE jobs SET status=?,state=?,error=?,updated_at=?,finished_at=? WHERE id=?',
                            (status, _dump(self._pack_state(job_id, state, status)), error, utcnow(), None if status == 'paused' else utcnow(), job_id))
            if state.get('board_id'):
                self.boards.finish(state['board_id'], job_id, status)
            self.db.commit()
            if self.active_job == job_id:
                self.active_job = None

    def _run_job(self, job_id, cancellation=None):
        cancellation = cancellation or self.cancel
        with self.lock:
            row = self._get_job(job_id)
            state, config, cid = self._load_state(row), json.loads(row['config']), row['collection_id']
        if state.get('progressive'):
            from progressive_scan import run_progressive
            return run_progressive(self, job_id, cancellation)
        terms = [item['term'] for item in config['keywords']]
        active_page = None
        active_directory = None
        bootstrap_response = None  # Memory only; never written to SQLite.

        def request_event(record):
            state['request_count'] = record['count']
            state['last_request'] = record
            self._save_state(job_id, state)

        transport_adapter = BoardTransportAdapter(self.adapter) if state.get('board_id') else self.adapter
        transport = self.transport_factory(adapter=transport_adapter, max_requests=160,
                request_count=state.get('request_count', 0), cancellation=cancellation, on_request=request_event)
        if state.get('board_id'):
            transport.adapter = transport_adapter
        try:
            content_reader = self.adapter.content_reader(transport, cancellation)
            # Loading robots is deliberately repeated after a manual resume/restart.
            transport.load_robots()
            while True:
                if cancellation.is_set():
                    raise PauseRequested()
                stage = state['stage']
                if stage == 'board':
                    if state['books_done'] >= config['max_books']:
                        state['discovery_stop'] = 'book_budget_reached'
                        self._save_state(job_id, state)
                        self._finish(job_id, 'completed')
                        return
                    with self.lock, self.db:
                        entry = self.boards.next_entry(state['board_id'])
                        if entry:
                            state.update(stage='directory', board_entry=entry,
                                         book_index=len(state['directories']))
                            state['directories'].append(entry['directory_url'])
                        self._save_state(job_id, state)
                    if entry:
                        continue
                    with self.lock:
                        search = self.boards.search(state['board_id'])
                        version = self.boards.version(search['state']['version_id'])
                    if version['state'].get('cycle'):
                        raise CrawlStop('board_pagination_cycle', config['board']['base_url'])
                    if version['state']['exhausted']:
                        state['discovery_stop'] = 'board_exhausted'
                        self._save_state(job_id, state)
                        self._finish(job_id, 'completed')
                        return
                    reader = self.adapter.board_reader(config['board'])
                    request = version['state']['request'] or reader.initial()
                    state['current_url'] = request['url']
                    self._save_state(job_id, state)
                    response = reader.fetch(transport, request)
                    books, next_request, reader_state = reader.read(response.html, response.final_url, version['state']['reader'])
                    if cancellation.is_set():
                        raise PauseRequested(request['url'])
                    with self.lock, self.db:
                        self.boards.observe(state['board_id'], request, reader_state, books, next_request, response.final_url)
                        self._save_state(job_id, state)
                elif stage == 'seed':
                    kind, url = state['seed_kind'], state['seed_url']
                    if kind == 'directory':
                        state.update(directories=[url], stage='directory')
                    elif kind == 'body':
                        if state['body_attempts'] >= 100:
                            raise CrawlStop('body_page_budget_reached', url)
                        state['body_attempts'] += 1
                        self._save_state(job_id, state)
                        response = transport.fetch(url)
                        directory = self.adapter.directory_from_body(response.html, response.final_url)
                        bootstrap_response = response
                        state.update(directories=[directory], stage='directory', seed_body_url=response.final_url)
                    else:
                        response = transport.fetch(url)
                        if kind == 'homepage':
                            state.update(stage='category', category_url=self.adapter.category_url(response.html, response.final_url))
                        else:
                            state.update(stage='directory', directories=self.adapter.book_links(response.html, response.final_url)[:config['max_books']])
                    self._save_state(job_id, state)
                elif stage == 'category':
                    state['current_url'] = state['category_url']
                    self._save_state(job_id, state)
                    response = transport.fetch(state['category_url'])
                    state.update(stage='directory', directories=self.adapter.book_links(response.html, response.final_url)[:config['max_books']])
                    self._save_state(job_id, state)
                elif stage == 'directory':
                    if state['book_index'] >= len(state['directories']):
                        self._finish(job_id, 'completed')
                        return
                    url = state['directories'][state['book_index']]
                    if state.get('board_id'):
                        with self.lock, self.db:
                            reference = self._link_discovered_book(cid, url, config, state['board_entry'], job_id)
                            if reference:
                                self.boards.complete(state['board_id'])
                                state.update(stage='board', books_done=state['books_done'] + 1,
                                             shared_reused_books=state['shared_reused_books'] + 1)
                                self._save_state(job_id, state)
                        if reference:
                            continue
                    active_directory = url
                    state['current_url'] = url
                    previous = self._book_data(cid, url) or {'title': '', 'directory_url': url, 'snippets': [], 'body_urls': []}
                    previous.pop('evaluation_ref', None)
                    previous.pop('discovery_reused', None)
                    if state.get('board_entry'):
                        previous['board_source'] = state['board_entry']
                    previous.update(last_attempt_at=utcnow(), last_attempt_status='running')
                    self._put_book(cid, url, previous)
                    self._save_state(job_id, state)
                    # Never conditionally skip directories: always discover new body URLs.
                    response = transport.fetch(url)
                    book = self.adapter.directory(response.html, response.final_url)
                    if book.url != url:
                        raise CrawlStop('directory_redirect_changed_identity', url)
                    now = utcnow()
                    previous.update(title=book.title, body_urls=list(book.body_urls), checked_at=now, snippets=[], snippet_sources=[],
                        last_attempt_status='success', source_updated_at=response.source_updated_at,
                        source_date_kind=getattr(response, 'source_date_kind', None), latest_job_id=job_id)
                    if not state.get('content_seed'):
                        previous.pop('content_seed', None)
                    self._put_book(cid, url, previous)
                    # A body seed retains its explicit starting scope. All other
                    # new scans distribute their sample across the whole directory.
                    candidates = list(book.body_urls)
                    if state.get('seed_body_url'):
                        if state['seed_body_url'] not in candidates:
                            raise UnknownTemplate('body seed is absent from the observed book directory')
                        candidates = candidates[candidates.index(state['seed_body_url']):]
                    state.update(stage='body', current_book={'url': book.url, 'title': book.title, 'body_urls': list(book.body_urls)}, page_index=0)
                    if state.get('content_seed'):
                        with self.lock, self.db:
                            self.content.put_context(url, previous)
                            # Adopt old prose-free observations lazily. Existing
                            # databases need no destructive migration, and the
                            # shared context retains earlier sampled coverage.
                            for source in candidates:
                                legacy = self._page_data(cid, url, source)
                                if (not self.content.source(url, source) and legacy
                                        and legacy.get('body_hash') and 'samples' in legacy):
                                    self.content.put_source(url, source, legacy)
                            try:
                                scheduler = self.content.open(url, state['content_seed'], candidates, config,
                                    state.get('seed_body_url'), job_id)
                            except ValueError:
                                raise CrawlStop('content_seed_conflict', url)
                            state['text_plan'] = scheduler.state
                            previous['content_seed'] = state['content_seed']
                            previous['strategy_run'] = scheduler.report(job_id, row['revision'])
                            self.db.execute('INSERT OR REPLACE INTO books VALUES(?,?,?)',
                                (cid, url, _dump(self._book_record(url, previous))))
                            self.db.execute('UPDATE jobs SET state=?,updated_at=? WHERE id=?',
                                (_dump(self._pack_state(job_id, state)), utcnow(), job_id))
                            self.db.commit()
                    elif state.get('sampling_version') == 2:
                        previous_pages = {value: self._page_data(cid, url, value) for value in candidates}
                        prior = {value: [[sample['start'], sample['end']] for sample in (page or {}).get('samples', [])
                                         if all(term in sample['counts'] for term in terms)]
                                 for value, page in previous_pages.items()}
                        scheduler = TextScheduler.create(candidates, config, prior, state.get('seed_body_url'))
                        for value, page in previous_pages.items():
                            if page and page.get('text_length'):
                                scheduler.register_source(value, page['text_length'], page['body_hash'])
                        state['text_plan'] = scheduler.state
                        previous['strategy_run'] = scheduler.report(job_id, row['revision'])
                        self._put_book(cid, url, previous)
                    else:
                        # Already-paused pre-strategy jobs finish their original
                        # queue. New strategies take effect on the next scan.
                        order = {value: index for index, value in enumerate(candidates)}
                        selected = sorted(candidates, key=lambda value: (self._covered(self._page_data(cid, url, value), terms), order[value]))[:config['pages_per_book']]
                        if state.get('seed_body_url'):
                            selected = [state['seed_body_url']] + [value for value in selected if value != state['seed_body_url']]
                            selected = selected[:config['pages_per_book']]
                        state['selected_pages'] = selected
                    self._save_state(job_id, state)
                elif stage == 'body':
                    info = state['current_book']
                    book = Book(info['url'], info['title'], tuple(info['body_urls']))
                    active_directory = book.url
                    if state.get('text_plan'):
                        scheduler = TextScheduler(state['text_plan'])
                        pending = scheduler.next()
                        if pending is None:
                            metadata = self._book_data(cid, book.url)
                            reason = scheduler.stop_reason()
                            metadata['strategy_run'] = scheduler.report(job_id, row['revision'], 'completed', reason)
                            with self.lock, self.db:
                                if scheduler.state.get('content_seed'):
                                    self.content.save(book.url, scheduler.state, job_id, 'completed')
                                self.db.execute('INSERT OR REPLACE INTO books VALUES(?,?,?)',
                                    (cid, book.url, _dump(self._book_record(book.url, metadata))))
                                self.boards.remember(book.url, config, self._book_record(book.url, metadata))
                                if state.get('board_id'):
                                    self.boards.complete(state['board_id'])
                                state.update(stage='board' if state.get('board_id') else 'directory', book_index=state['book_index'] + 1,
                                             books_done=state['books_done'] + 1, current_url=None)
                                state.pop('text_plan', None)
                                self._save_state(job_id, state)
                            content_reader.clear()
                            continue
                        active_page = pending['url']
                        used_bootstrap = self._text_step(job_id, row['revision'], cid, config, state, book,
                            scheduler, content_reader, bootstrap_response)
                        if used_bootstrap:
                            bootstrap_response = None
                        active_page = None
                        continue
                    if state['page_index'] >= len(state['selected_pages']):
                        state.update(stage='directory', book_index=state['book_index'] + 1,
                                     books_done=state['books_done'] + 1, current_url=None)
                        self._save_state(job_id, state)
                        continue
                    url = state['selected_pages'][state['page_index']]
                    active_page = url
                    cached_seed = bootstrap_response is not None and bootstrap_response.final_url == url
                    if not cached_seed and state['body_attempts'] >= 100:
                        raise CrawlStop('body_page_budget_reached', url)
                    state.update(current_url=url, body_attempts=state['body_attempts'] + (0 if cached_seed else 1))
                    page = self._page_data(cid, book.url, url) or {'url': url, 'counts': {}, 'body_hash': None}
                    covered = self._covered(page, terms)
                    page.update(last_attempt_at=utcnow(), last_attempt_status='running')
                    self._put_page(cid, book.url, url, page)
                    self._save_state(job_id, state)
                    validators = None
                    if covered and (page.get('etag') or page.get('last_modified')):
                        validators = {key: page.get(key) for key in ('etag', 'last_modified')}
                    response = bootstrap_response if cached_seed else transport.fetch(url, validators=validators)
                    bootstrap_response = None
                    if response.final_url != url:
                        raise CrawlStop('body_redirect_changed_identity', url)
                    if cancellation.is_set():
                        raise PauseRequested(url)
                    now = utcnow()
                    if response.status == 304:
                        if not covered or not validators:
                            raise CrawlStop('uncertified_304_stop', url)
                        page['status'] = 'unchanged_304'
                        state['reused_304'] += 1
                        # 304 may omit validators/source dates: retain the known values.
                        for key in ('etag', 'last_modified', 'source_updated_at', 'source_date_kind'):
                            value = getattr(response, key, None)
                            if value is not None:
                                page[key] = value
                    elif response.status == 200:
                        body = self.adapter.body(response.html, response.final_url, book)
                        digest = sha256(body.text.encode('utf-8')).hexdigest()
                        if covered and digest == page.get('body_hash'):
                            page['status'] = 'unchanged_hash'
                            state['reused_hash'] += 1
                        else:
                            page['counts'] = {term: body.text.count(term) for term in terms}
                            page['status'] = 'counted'
                            page['counted_at'] = now
                            state['recounted'] += 1
                        # Only snippets extracted in this scan are retained. A 304
                        # reuses counts, but does not manufacture a fresh excerpt.
                        metadata = self._book_data(cid, book.url)
                        snippets = metadata.get('snippets', [])[:2]
                        sources = metadata.get('snippet_sources', [])[:2]
                        for term in terms:
                            location = body.text.find(term)
                            if location >= 0 and len(snippets) < 2:
                                snippet = body.text[max(0, location - 8):max(0, location - 8) + 32]
                                if snippet not in snippets:
                                    snippets.append(snippet)
                                    sources.append({'url': url, 'checked_at': now, 'term': term})
                        metadata.update(snippets=snippets, snippet_sources=sources)
                        self._put_book(cid, book.url, metadata)
                        page.update(body_hash=digest, body_chars=sum(not char.isspace() for char in body.text),
                                    etag=response.etag, last_modified=response.last_modified,
                                    source_updated_at=response.source_updated_at,
                                    source_date_kind=getattr(response, 'source_date_kind', None),
                                    next_urls=list(body.next_urls), removed_preamble_paragraphs=body.removed_preamble_paragraphs)
                    else:
                        raise CrawlStop('unexpected_response_status', url)
                    # Preserve only observed same-book pagination links. Grow this
                    # bounded queue only while the original per-book limit allows.
                    metadata = self._book_data(cid, book.url)
                    for next_url in page.get('next_urls', []):
                        if next_url not in metadata['body_urls']:
                            metadata['body_urls'].append(next_url)
                        if next_url not in state['current_book']['body_urls']:
                            state['current_book']['body_urls'].append(next_url)
                        if next_url not in state['selected_pages'] and len(state['selected_pages']) < config['pages_per_book']:
                            state['selected_pages'].append(next_url)
                    page.update(checked_at=now, last_attempt_status='success', latest_job_id=job_id)
                    state.update(page_index=state['page_index'] + 1, successful_body_pages=state['successful_body_pages'] + 1)
                    # Commit the shared evidence, strategy progress and cursor
                    # together: a crash must not replay a completed observation.
                    with self.lock:
                        self.db.execute('INSERT OR REPLACE INTO pages VALUES(?,?,?,?)', (cid, book.url, url, _dump(page)))
                        self.db.execute('INSERT OR REPLACE INTO books VALUES(?,?,?)', (cid, book.url, _dump(metadata)))
                        self.db.execute('UPDATE jobs SET state=?,updated_at=? WHERE id=?', (_dump(state), utcnow(), job_id))
                        self.db.commit()
                    active_page = None
                else:
                    raise RuntimeError('unknown persisted job stage')
        except PauseRequested:
            self._mark_failed_attempt(cid, active_directory, active_page, 'paused')
            self._finish(job_id, 'paused')
        except (CrawlStop, UnknownTemplate) as error:
            reason = error.reason if isinstance(error, CrawlStop) else 'unknown_template: ' + str(error)
            self._mark_failed_attempt(cid, active_directory, active_page, reason)
            self._finish(job_id, 'paused' if reason in ('network_error_stop', 'dns_error_stop') else 'stopped', reason)
        except Exception as error:
            # Do not persist response bodies or arbitrary exception representations.
            reason = 'internal_error: ' + type(error).__name__
            self._mark_failed_attempt(cid, active_directory, active_page, reason)
            self._finish(job_id, 'failed', reason)
        finally:
            transport.close()

    def _mark_failed_attempt(self, cid, directory, url, reason):
        if url and directory:
            page = self._page_data(cid, directory, url)
            if page:
                page['last_attempt_status'] = reason
                self._put_page(cid, directory, url, page)
        elif directory:
            book = self._book_data(cid, directory)
            if book and book.get('last_attempt_status') == 'running':
                book['last_attempt_status'] = reason
                self._put_book(cid, directory, book)

    def _text_step(self, job_id, revision, cid, config, state, book, scheduler,
                   reader, bootstrap):
        pending = scheduler.state['pending']
        url = pending['url']
        terms = [word['term'] for word in config['keywords']]
        seeded = bool(scheduler.state.get('content_seed'))
        with self.lock:
            page = (self.content.source(book.url, url) if seeded else self._page_data(cid, book.url, url)) or {'url': url, 'counts': {}, 'body_hash': None}
        matched_cache = next((sample for sample in page.get('samples', []) if
            sample['start'] == pending['start'] and sample['end'] == pending['end'] and
            all(term in sample['counts'] for term in terms)), None)
        used_bootstrap, unchanged = False, False
        response, parsed, digest = None, None, None
        state['current_url'] = url
        # Cache hits still execute a new character-range decision. Persist it
        # before matching, just as we persist a request before network I/O.
        self._save_state(job_id, state)
        if not reader.cached(book, url):
            used_bootstrap = bootstrap is not None and bootstrap.final_url == url
            if not used_bootstrap and state['body_attempts'] >= 100 and not state.get('progressive'):
                raise CrawlStop('body_page_budget_reached', url)
            state['body_attempts'] += 0 if used_bootstrap else 1
            page.update(last_attempt_at=utcnow(), last_attempt_status='running')
            self._put_page(cid, book.url, url, page)
            self._save_state(job_id, state)
            validators = None
            if (matched_cache and pending['start'] == 0 and pending['end'] == page.get('text_length')
                    and not scheduler.state['focus_terms'] and (page.get('etag') or page.get('last_modified'))):
                validators = {key: page.get(key) for key in ('etag', 'last_modified')}
            read = reader.read(book, url, validators=validators, bootstrap=bootstrap)
            response, parsed, digest = read.response, read.body, read.digest
            if response.status == 304:
                if not validators or not matched_cache:
                    raise CrawlStop('uncertified_304_stop', url)
                # A different seed may have refreshed the shared source while
                # this job was paused. The 304 certifies the page's validator,
                # not an older hash pinned in this seed's unobserved plan.
                try:
                    scheduler.register_source(url, page['text_length'], page['body_hash'])
                except ValueError:
                    raise CrawlStop('source_changed_during_scan', url)
                unchanged = True
                state['reused_304'] += 1
            elif response.status == 200:
                try:
                    scheduler.register_source(url, len(parsed.text), digest)
                except ValueError:
                    raise CrawlStop('source_changed_during_scan', url)
            else:
                raise CrawlStop('unexpected_response_status', url)
            state['successful_body_pages'] += 1
        else:
            read = reader.read(book, url)
            parsed, response, digest = read.body, read.response, read.digest
        metadata = self._book_data(cid, book.url)
        metadata['latest_job_id'] = job_id
        if seeded:
            metadata['content_seed'] = scheduler.state['content_seed']
        else:
            metadata.pop('content_seed', None)
        if parsed:
            scheduler.discover(url, parsed.next_urls)
            for next_url in parsed.next_urls:
                if next_url not in metadata['body_urls']:
                    metadata['body_urls'].append(next_url)
                if next_url not in state['current_book']['body_urls']:
                    state['current_book']['body_urls'].append(next_url)
        # Loading a document discovers text length; strategy selection is then
        # resolved by character position, without counting its entire contents.
        if scheduler.state['pending'] is None:
            metadata['strategy_run'] = scheduler.report(job_id, revision)
            self._put_book(cid, book.url, metadata)
            self._save_state(job_id, state)
            return used_bootstrap
        now = utcnow()
        if unchanged:
            evidence = scheduler.observe_cached(matched_cache, config['keywords'], now)
            page['status'] = 'unchanged_304'
            if seeded:
                evidence['reused_from_context'] = True
                scheduler.state['shared_reused_chars'] += evidence['body_chars']
                state['shared_reused_chars'] += evidence['body_chars']
        else:
            if page.get('body_hash') != digest:
                page['samples'] = []
            with self.lock:
                shared = self.content.reusable(book.url, scheduler.state['pending'], digest,
                    config['keywords'], scheduler.state['focus_terms']) if seeded else None
            if shared:
                evidence = scheduler.observe_shared(shared, parsed.text, config['keywords'], now)
                state['shared_reused_chars'] += evidence['body_chars']
            else:
                evidence = scheduler.observe(parsed.text, config['keywords'], now)
            update_samples(page, parsed.text, evidence, config['keywords'])
            if matched_cache and digest == page.get('body_hash'):
                page['status'] = 'unchanged_hash'
                state['reused_hash'] += 1
            else:
                page['status'] = 'counted'
                state['recounted'] += 1
            page.update(body_hash=digest, text_length=len(parsed.text), body_chars=len(parsed.text),
                        counted_at=now, etag=response.etag, last_modified=response.last_modified,
                        source_updated_at=response.source_updated_at,
                        source_date_kind=getattr(response, 'source_date_kind', None), next_urls=list(parsed.next_urls))
            snippets, sources = metadata.get('snippets', [])[:2], metadata.get('snippet_sources', [])[:2]
            fragment = parsed.text[evidence['start']:evidence['end']]
            for term in terms:
                location = fragment.find(term)
                if location >= 0 and len(snippets) < 2:
                    snippet = fragment[max(0, location - 8):max(0, location - 8) + 32]
                    if snippet not in snippets:
                        snippets.append(snippet)
                        sources.append({'url': url, 'start': evidence['start'], 'end': evidence['end'], 'term': term, 'checked_at': now})
            metadata.update(snippets=snippets, snippet_sources=sources)
        page.update(checked_at=now, last_attempt_status='success', latest_job_id=job_id,
                    sampling={'job_id': job_id, 'requested_by': evidence['requested_by'],
                              'start': evidence['start'], 'end': evidence['end'], 'reasons': evidence['reasons']})
        state['matched_chars'] += evidence['end'] - evidence['start']
        metadata['strategy_run'] = scheduler.report(job_id, revision)
        with self.lock, self.db:
            if seeded:
                self.content.put_source(book.url, url, page)
                self.content.put_context(book.url, metadata)
            self.db.execute('INSERT OR REPLACE INTO pages VALUES(?,?,?,?)', (cid, book.url, url, _dump(page)))
            self.db.execute('INSERT OR REPLACE INTO books VALUES(?,?,?)', (cid, book.url, _dump(self._book_record(book.url, metadata))))
            self.db.execute('UPDATE jobs SET state=?,updated_at=? WHERE id=?', (_dump(self._pack_state(job_id, state)), utcnow(), job_id))
            self.db.commit()
        return used_bootstrap

    def _results(self, collections, detail_urls=None):
        result = []
        configs = {row['id']: row for row in collections}
        for record in self.db.execute('SELECT * FROM books').fetchall():
            cid, directory = record['collection_id'], record['directory_url']
            if cid not in configs:
                continue
            config = configs[cid]
            detailed = detail_urls is None or directory in detail_urls
            terms = [kw['term'] for kw in config['keywords']]
            weights = {kw['term']: kw['weight'] for kw in config['keywords']}
            book = self.boards.resolve(json.loads(record['data']))
            available = {row['url']: json.loads(row['data']) for row in self.db.execute('SELECT * FROM pages WHERE collection_id=? AND directory_url=?', (cid, directory))}
            if book.get('content_seed'):
                available.update({row['url']: json.loads(row['data']) for row in self.db.execute(
                    'SELECT url,data FROM content_sources WHERE directory_url=?', (directory,))})
            pages, counts, known_counts = [], dict.fromkeys(terms, 0), dict.fromkeys(terms, 0)
            scanned = matching = 0
            sampled_chars = 0
            known_char_coverage = True
            fully_sampled = True
            requires_rescan = False
            for url in book.get('body_urls', []):
                saved = available.get(url, {'url': url, 'counts': {}, 'body_hash': None, 'status': 'unscanned', 'checked_at': None, 'source_updated_at': None})
                page = dict(saved)
                page['counts'] = {term: saved.get('counts', {}).get(term) for term in terms}
                page['term_coverage'] = [term for term in terms if term in saved.get('counts', {})]
                page['requires_rescan'] = bool(saved.get('body_hash') and not self._covered(saved, terms))
                if page.get('body_hash'):
                    scanned += 1
                    sampled_chars += page.get('sampled_chars', 0)
                    known_char_coverage = known_char_coverage and 'samples' in page
                    if 'samples' in page and page.get('sampled_chars', 0) < page.get('text_length', 0):
                        fully_sampled = False
                    requires_rescan = requires_rescan or page['requires_rescan']
                    for term in terms:
                        value = page['counts'][term]
                        if value is None:
                            counts[term] = None
                        else:
                            known_counts[term] += value
                            if counts[term] is not None:
                                counts[term] += value
                    if any(value and value > 0 for value in page['counts'].values()):
                        matching += 1
                if detailed:
                    pages.append(page)
            if not scanned:
                counts = dict.fromkeys(terms, None)
            partial_score = sum(weights[term] * value for term, value in known_counts.items())
            score = None if requires_rescan or not scanned else partial_score
            source_count = len(book.get('body_urls', []))
            status = 'requires_rescan' if requires_rescan else ('unscanned' if not scanned else ('sampled' if scanned < source_count or not fully_sampled else 'counted'))
            run = self.content.unpack(book['strategy_run']) if book.get('strategy_run') else None
            if run and run.get('status') != 'completed':
                job = self.db.execute('SELECT status,error FROM jobs WHERE id=?', (run['job_id'],)).fetchone()
                if job:
                    run = {**run, 'status': job['status'], 'stop_reason': job['error']}
            strategy_summary = summarize(run, config['keywords'], config['revision'])
            if strategy_summary and run.get('content_seed'):
                stale = sorted({r['url'] for r in run['evidence'] if available.get(r['url'], {}).get('body_hash')
                    and available[r['url']]['body_hash'] != r['body_hash']})
                strategy_summary['stale_sources'] = stale
                if stale:
                    strategy_summary['ranking_score'] = None
            result.append({'collection_id': cid, 'title': book.get('title', ''), 'directory_url': directory,
                'score': score, 'partial_score': partial_score, 'counts': counts, 'known_counts': known_counts,
                'ranking_score': strategy_summary['ranking_score'] if strategy_summary else None,
                'strategy_summary': strategy_summary,
                'content_searches': self.content.searches(directory),
                'board_source': book.get('board_source'), 'discovery_reused': book.get('discovery_reused', False),
                'board_sources': [dict(r) for r in self.db.execute('''SELECT b.id,b.type,b.base_url,b.keys,
                    s.version_id,s.position,s.selected_at FROM discovery_selections s
                    JOIN discovery_boards b ON b.id=s.board_id WHERE s.directory_url=?''', (directory,))],
                'matching_pages': matching, 'scanned_pages': scanned, 'discovered_pages': source_count,
                'scanned_chars': sampled_chars if known_char_coverage else None,
                'status': status, 'requires_rescan': requires_rescan, 'source_updated_at': book.get('source_updated_at'),
                'source_date_kind': book.get('source_date_kind'), 'checked_at': book.get('checked_at'),
                'last_attempt_at': book.get('last_attempt_at'), 'last_attempt_status': book.get('last_attempt_status'),
                'snippets': book.get('snippets', [])[:2], 'snippet_sources': book.get('snippet_sources', [])[:2],
                'snippet_scope': 'current_scan_only', 'pages': pages, 'details_loaded': detailed,
                'body_urls': book.get('body_urls', []) if detailed else [], 'score_scope': 'successfully_scanned_current_directory_pages',
                'latest_job_id': book.get('latest_job_id')})
        result.sort(key=lambda row: (row['ranking_score'] is None, -(row['ranking_score'] or 0), row['title'], row['directory_url']))
        return result

    def snapshot(self, detail_urls=None):
        with self.lock:
            collections = [self._collection(row) for row in self.db.execute('SELECT * FROM collections ORDER BY created_at').fetchall()]
            jobs = [self._job(row) for row in self.db.execute('SELECT * FROM jobs ORDER BY created_at DESC').fetchall()]
            return {'collections': collections, 'jobs': jobs, 'results': self._results(collections, detail_urls), 'active_job': self.active_job,
                    'boards': self.boards.summaries(), 'board_types': self.adapter.board_types,
                    'content_capabilities': sorted(self.adapter.content_capabilities)}

    def minimum_reader_version(self):
        with self.lock:
            return minimum_reader_version(self.db)

    def close(self):
        with self.lock:
            if self.closed:
                return
            self.closed = True
            self.cancel.set()
            worker = self.worker
        if worker and worker.is_alive() and worker is not threading.current_thread():
            worker.join(timeout=35)
        with self.lock:
            if worker and worker.is_alive():
                # Keep the connection alive for the still-finishing daemon callback.
                return
            self.db.close()
