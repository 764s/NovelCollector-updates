"""Character-budgeted sampling independent of source pagination.

Offsets address parsed Unicode prose (including punctuation/paragraph breaks).
Documents are transport containers; evidence consists of disjoint text ranges.
No strategy fetches a URL or retains prose in its serializable state.
"""
from copy import deepcopy
from hashlib import sha256
import json
import math
from typing import Protocol

from content_model import ContentExecution
from content_reader import ContentSpace


class ContentStrategy(Protocol):
    id: str
    name: str
    version: int
    baseline: bool
    defaults: dict
    bounds: dict
    def initialize(self, plan) -> dict: ...
    def propose(self, plan, state, params) -> list[dict]: ...
    def observe(self, plan, state, evidence, params): ...
    def summarize(self, plan, state, params) -> dict: ...


def baseline_ids(plan):
    return {s['id'] for s in plan['specs'] if s['enabled'] and REGISTRY[s['id']].baseline}


def belongs(plan, row, strategy):
    return (strategy is None or (bool(baseline_ids(plan).intersection(row['requested_by']))
            if strategy == 'baseline' else strategy in row['requested_by']))


def intervals(ranges):
    result = []
    for start, end in sorted(ranges):
        if start >= end:
            continue
        if result and start <= result[-1][1]:
            result[-1][1] = max(end, result[-1][1])
        else:
            result.append([start, end])
    return result


def gaps(start, end, covered):
    result, cursor = [], start
    for left, right in intervals(covered):
        if right <= cursor:
            continue
        if left >= end:
            break
        if left > cursor:
            result.append([cursor, min(left, end)])
        cursor = max(cursor, right)
    if cursor < end:
        result.append([cursor, end])
    return result


def evenly(values, count):
    if not values or count <= 0:
        return []
    if count >= len(values):
        return list(values)
    if count == 1:
        return [values[len(values) // 2]]
    return [values[i * (len(values) - 1) // (count - 1)] for i in range(count)]


def coverage(plan, url, strategy=None):
    return intervals((row['start'], row['end']) for row in plan['evidence']
                     if row['url'] == url and belongs(plan, row, strategy))


def consumed(plan, strategy=None):
    return sum(row['end'] - row['start'] for row in plan['evidence']
               if belongs(plan, row, strategy))


def proposal(url, start, end, strategy, priority, **reason):
    return {'url': url, 'start': start, 'end': end, 'strategy': strategy,
            'priority': priority, 'reason': reason}


def seed_fraction(plan, *parts):
    """Stable across Python processes/releases; never use randomized hash()."""
    value = json.dumps([plan['content_seed'], plan['iteration'], *parts], ensure_ascii=False, separators=(',', ':'))
    return (int.from_bytes(sha256(value.encode('utf-8')).digest()[:8], 'big') >> 11) / 2**53


class Distributed:
    id, name, version = 'distributed', '分布采样', 2
    baseline = True
    defaults, bounds = {}, {}

    @staticmethod
    def initialize(plan):
        reserve = plan['coverage_reserve'] - consumed(plan, Distributed.id)
        count = max(1, math.ceil(reserve / plan['sample_chars']))
        sources = plan['sources']
        if plan.get('content_seed') and sources:
            # Stratify across the directory, then jitter within each stratum.
            # Another seed's coverage never moves these baseline targets.
            size = min(count, len(sources))
            selected = []
            for i in range(size):
                left, right = i * len(sources) // size, (i + 1) * len(sources) // size
                selected.append(sources[left + int(seed_fraction(plan, 'source', i) * (right - left))])
            targets = []
            for i, url in enumerate(selected):
                slots = count // size + (i < count % size)
                targets += [{'url': url, 'fraction': (j + seed_fraction(plan, url, j)) / slots}
                            for j in range(slots)]
            targets.sort(key=lambda t: seed_fraction(plan, 'order', t['url'], t['fraction']))
            if plan.get('seed') and plan['iteration'] == 1:
                targets.insert(0, {'url': plan['seed'], 'fraction': 0})
            return {'targets': targets}
        # Divide sample positions across sources, then across the text inside a
        # source. A single full-book document receives all distributed positions.
        fresh = [url for url in sources if not plan['previous'].get(url)]
        selected = evenly(fresh, count)
        selected += evenly([url for url in sources if url not in set(selected)], count - len(selected))
        targets = []
        for i, url in enumerate(selected):
            slots = count // len(selected) + (i < count % len(selected))
            targets += [{'url': url, 'fraction': j / (slots - 1) if slots > 1 else .5}
                        for j in range(slots)]
        if plan.get('seed'):
            targets = [t for t in targets if t['url'] != plan['seed']] + [
                {'url': plan['seed'], 'fraction': 0}]
            targets.sort(key=lambda t: t['url'] != plan['seed'])
        return {'targets': targets}

    @staticmethod
    def window(plan, url, fraction):
        length = plan['lengths'].get(url)
        if length is None:
            return None, None
        available = gaps(0, length, coverage(plan, url))
        if not available:
            return 0, 0
        previous = plan['previous'].get(url, [])
        fresh = [gap for start, end in available for gap in gaps(start, end, previous)]
        choices = fresh or available
        width = plan['sample_chars']
        target = int(max(0, length - width) * fraction)
        left, right = min(choices, key=lambda pair: abs(max(pair[0], min(target, pair[1] - 1)) - target))
        start = max(left, min(target, max(left, right - width)))
        return start, min(start + width, right)

    @classmethod
    def propose(cls, plan, state, params):
        priority = 50 if consumed(plan, cls.id) < plan['coverage_reserve'] else 10
        while state['targets']:
            target = state['targets'][0]
            start, end = cls.window(plan, target['url'], target['fraction'])
            if start == end == 0:
                state['targets'].pop(0)
                continue
            return [proposal(target['url'], start, end, cls.id, priority,
                             kind='distributed_position', fraction=target['fraction'])]
        # Recycle spare character budget, even when short sources exhausted
        # fewer characters than a nominal sample. Prefer yet-unread sources.
        unknown = [url for url in plan['sources'] if url not in plan['lengths']]
        if unknown:
            url = unknown[len(unknown) // 2]
            return [proposal(url, None, None, cls.id, priority, kind='distributed_fill')]
        choices = []
        for url in plan['sources']:
            for start, end in gaps(0, plan['lengths'][url], coverage(plan, url)):
                fresh = gaps(start, end, plan['previous'].get(url, []))
                for left, right in fresh or [[start, end]]:
                    choices.append((bool(fresh), right - left, url, left, right))
        if not choices:
            return []
        _, _, url, left, right = max(choices, key=lambda p: (p[0], p[1], -plan['sources'].index(p[2]), -p[3]))
        start = left + max(0, right - left - plan['sample_chars']) // 2
        return [proposal(url, start, min(right, start + plan['sample_chars']), cls.id, priority,
                         kind='distributed_fill')]

    @staticmethod
    def observe(plan, state, evidence, params):
        if any(r['strategy'] == Distributed.id and r['kind'] == 'distributed_position' for r in evidence['reasons']):
            state['targets'].pop(0)

    @staticmethod
    def summarize(plan, state, params):
        return {'reserved_chars': plan['coverage_reserve']}

    @classmethod
    def begin_execution(cls, plan, state, params):
        state['targets'] += cls.initialize(plan)['targets']


class FixedInterval:
    id, name, version = 'fixed_interval', '固定间隔采样', 1
    baseline = True
    defaults = {'offset_chars': 0, 'gap_chars': 0}
    bounds = {'offset_chars': (0, 10000000), 'gap_chars': (0, 10000000)}

    @classmethod
    def initialize(cls, plan):
        params = next(s['params'] for s in plan['specs'] if s['id'] == cls.id)
        return {'source': plan['sources'][0] if plan['sources'] else None, 'offset': 0,
                'skip_remaining': params['offset_chars'], 'window_remaining': plan['sample_chars']}

    @classmethod
    def propose(cls, plan, state, params):
        space = ContentSpace(plan)
        if state['source'] is None and space.sources:
            state['source'] = space.sources[0]
        while state['source'] is not None:
            url, offset = state['source'], state['offset']
            length = space.length(url)
            priority = 50 if consumed(plan, 'baseline') < plan['coverage_reserve'] else 10
            if length is None:
                return [proposal(url, None, None, cls.id, priority, kind='fixed_interval')]
            if offset >= length:
                following = space.next_source(url)
                if following is None:
                    return []  # Keep the last cursor: later continuation may discover a tail.
                state.update(source=following, offset=0)
                continue
            if state['skip_remaining']:
                step = min(state['skip_remaining'], length - offset)
                state['skip_remaining'] -= step
                state['offset'] += step
                continue
            if state['window_remaining'] == 0:
                state.update(skip_remaining=params['gap_chars'], window_remaining=plan['sample_chars'])
                continue
            end = min(length, offset + state['window_remaining'])
            available = gaps(offset, end, coverage(plan, url))
            start = available[0][0] if available else end
            if start > offset:
                # Another strategy in this same search already observed these
                # characters. Advance this pattern without charging them again.
                state['offset'] = start
                state['window_remaining'] -= start - offset
                continue
            return [proposal(url, start, available[0][1], cls.id, priority, kind='fixed_interval')]
        return []

    @staticmethod
    def observe(plan, state, evidence, params):
        if (FixedInterval.id in evidence['requested_by'] and evidence['url'] == state['source']
                and evidence['start'] == state['offset']):
            size = evidence['end'] - evidence['start']
            state['offset'] += size
            state['window_remaining'] -= size

    @staticmethod
    def summarize(plan, state, params):
        return {**deepcopy(state), 'window_chars': plan['sample_chars'], **params}


class FocusNeighbors:
    id, name, version = 'focus_neighbors', '关注词扩展扫描', 2
    baseline = False
    defaults = {'radius_chars': 800, 'miss_chars': 400, 'region_chars': 1200}
    bounds = {'radius_chars': (1, 20000), 'miss_chars': (1, 10000), 'region_chars': (1, 20000)}

    @staticmethod
    def initialize(plan):
        return {'regions': []}

    @classmethod
    def direction(cls, plan, region, anchor, sign, params):
        """Walk observed characters from a hit, including adjacent sources.

        Unknown source lengths produce a metadata request. Once fetched, the
        same walk resumes by offsets, without treating that source as one unit.
        """
        index = plan['sources'].index(anchor['url'])
        cursor = anchor['end'] if sign > 0 else anchor['start']
        distance = misses = 0
        while distance < params['radius_chars'] and misses < params['miss_chars']:
            url = plan['sources'][index]
            length = plan['lengths'].get(url)
            reason = {'kind': 'focus_neighbor', 'region_id': region['id'],
                      'anchor_url': anchor['url'], 'anchor_start': anchor['start'], 'direction': sign}
            if length is None:
                return proposal(url, None, None, cls.id, 100 - distance / max(1, params['radius_chars']), **reason)
            if cursor is None:
                cursor = 0 if sign > 0 else length
            if (sign > 0 and cursor >= length) or (sign < 0 and cursor <= 0):
                index += sign
                if not 0 <= index < len(plan['sources']):
                    return None
                cursor = None
                continue
            observed = next((row for row in plan['evidence'] if row['url'] == url and
                             (row['start'] <= cursor < row['end'] if sign > 0 else row['start'] < cursor <= row['end'])), None)
            room = min(plan['sample_chars'], params['radius_chars'] - distance,
                       params['miss_chars'] - misses, params['region_chars'] - region['used_chars'])
            if room <= 0:
                return None
            if observed:
                # Inspect only already-recorded match intervals, never unseen
                # prose. One-character steps keep the miss threshold exact.
                position = cursor if sign > 0 else cursor - 1
                hit = any(start <= position < end for start, end in observed['focus_intervals'])
                misses = 0 if hit else misses + 1
                distance += 1
                cursor += sign
                continue
            if sign > 0:
                next_read = min((start for start, _ in coverage(plan, url) if start > cursor), default=length)
                start, end = cursor, min(cursor + room, next_read)
            else:
                next_read = max((end for _, end in coverage(plan, url) if end < cursor), default=0)
                start, end = max(next_read, cursor - room), cursor
            return proposal(url, start, end, cls.id, 100 - distance / max(1, params['radius_chars']), **reason)
        return None

    @classmethod
    def propose(cls, plan, state, params):
        candidates = []
        for region in state['regions']:
            if region['used_chars'] >= params['region_chars']:
                continue
            for anchor in region['anchors']:
                for sign in (-1, 1):
                    candidate = cls.direction(plan, region, anchor, sign, params)
                    if candidate:
                        candidates.append(candidate)
        return candidates

    @classmethod
    def observe(cls, plan, state, evidence, params):
        region_ids = {r['region_id'] for r in evidence['reasons'] if r['strategy'] == cls.id and 'region_id' in r}
        for region in state['regions']:
            if region['id'] in region_ids:
                region['used_chars'] += evidence['end'] - evidence['start']
        if not evidence['focus_intervals'] or region_ids:
            return
        start, end = evidence['focus_intervals'][0][0], evidence['focus_intervals'][-1][1]
        anchor = {'url': evidence['url'], 'start': start, 'end': end, 'terms': evidence['focus_hits']}
        overlap = [r for r in state['regions'] if any(a['url'] == anchor['url'] and
                   a['start'] - 2 * params['radius_chars'] <= end and
                   start <= a['end'] + 2 * params['radius_chars'] for a in r['anchors'])]
        new = {'id': len(plan['evidence']), 'anchors': [anchor], 'used_chars': 0}
        if overlap:
            new['id'] = overlap[0]['id']
            context_refs = sorted({key for r in overlap for key in r.get('context_refs', [r['context_ref']] if r.get('context_ref') else [])})
            if context_refs:
                new.update(context_ref=context_refs[0], context_refs=context_refs, origin='shared_context')
            new['anchors'] += [a for r in overlap for a in r['anchors']]
            old_ids = {r['id'] for r in overlap}
            # Shared text charged once when independently found regions merge.
            new['used_chars'] = sum(row['end'] - row['start'] for row in plan['evidence'] if
                any(reason.get('region_id') in old_ids for reason in row['reasons']))
            for row in plan['evidence']:
                for reason in row['reasons']:
                    if reason.get('region_id') in old_ids:
                        reason['region_id'] = new['id']
            state['regions'] = [r for r in state['regions'] if r not in overlap]
        state['regions'].append(new)

    @classmethod
    def accept_hints(cls, plan, state, facts, params):
        if not plan['focus_terms']:
            return
        regions = state['regions']
        own = {r.get('context_ref') for r in plan['evidence']}
        seen = set(plan['seen_context_hints']) | own
        available = max(0, plan['limit'] - consumed(plan) - max(0, plan['coverage_reserve'] - consumed(plan, 'baseline')))
        limit = math.ceil(available / plan['sample_chars'])
        added = 0
        for fact in sorted(facts, key=lambda f: seed_fraction(plan, 'hint', f['context_ref'])):
            if added >= limit:
                break
            if fact['context_ref'] in seen:
                continue
            start, end = fact['focus_intervals'][0][0], fact['focus_intervals'][-1][1]
            # One shared location must not acquire a fresh region budget every
            # time a neighboring seed publishes an overlapping observation.
            if any(a['url'] == fact['url'] and a['start'] - 2 * params['radius_chars'] <= end
                   and start <= a['end'] + 2 * params['radius_chars'] for r in regions for a in r['anchors']):
                continue
            regions.append({'id': 'context:' + fact['context_ref'], 'used_chars': 0,
                'context_ref': fact['context_ref'], 'anchors': [{'url': fact['url'], 'start': start,
                    'end': end, 'terms': fact['focus_hits']}], 'origin': 'shared_context'})
            plan['seen_context_hints'].append(fact['context_ref'])
            added += 1

    @staticmethod
    def source_changed(plan, state, source):
        state['regions'] = [r for r in state['regions'] if not any(a['url'] == source for a in r['anchors'])]

    @classmethod
    def summarize(cls, plan, state, params):
        result = []
        for region in state['regions']:
            if region['used_chars'] >= params['region_chars']:
                reason = 'region_budget_reached'
            elif not cls.propose(plan, {'regions': [region]}, params):
                reason = 'neighborhood_complete'
            elif consumed(plan) >= plan['limit']:
                reason = 'char_budget_reached'
            else:
                reason = 'pending'
            result.append({**region, 'stop_reason': reason})
        return {'regions': result}


REGISTRY = {cls.id: cls for cls in (Distributed, FocusNeighbors, FixedInterval)}


def normalize_strategies(value=None):
    if value is None:
        value = [{'id': Distributed.id}, {'id': FocusNeighbors.id}]
    if not isinstance(value, list) or not 1 <= len(value) <= len(REGISTRY):
        raise ValueError('请选择有效的扫描策略组合')
    supplied = {}
    for item in value:
        if not isinstance(item, dict) or not isinstance(item.get('id'), str) or item['id'] not in REGISTRY:
            raise ValueError('未知的扫描策略')
        key, enabled = item['id'], item.get('enabled', True)
        cls = REGISTRY[key]
        if key in supplied or type(enabled) is not bool:
            raise ValueError('重复策略或无效的启用状态')
        if type(item.get('version', cls.version)) is not int or item.get('version', cls.version) != cls.version:
            raise ValueError('不支持的策略版本')
        params = item.get('params', {})
        if not isinstance(params, dict) or set(params) - set(cls.defaults):
            raise ValueError('未知的策略参数')
        params = {**cls.defaults, **params}
        for name, (low, high) in cls.bounds.items():
            if type(params[name]) is not int or not low <= params[name] <= high:
                raise ValueError(f'{name} 必须为 {low}–{high} 的整数')
        supplied[key] = {'id': key, 'version': cls.version, 'enabled': enabled, 'params': params}
    if not any(s['enabled'] and REGISTRY[key].baseline for key, s in supplied.items()):
        raise ValueError('必须保留至少一种基础采样策略')
    return [supplied.get(key, {'id': key, 'version': cls.version, 'enabled': False,
                              'params': dict(cls.defaults)}) for key, cls in REGISTRY.items()
            if key in (Distributed.id, FocusNeighbors.id) or supplied.get(key, {}).get('enabled')]


class TextScheduler:
    def __init__(self, state):
        self.state = state
        self.execution = ContentExecution(state)
        self.space = ContentSpace(state)

    @classmethod
    def create(cls, sources, config, previous=None, seed=None, content_seed=None):
        specs = normalize_strategies(config.get('strategies'))
        focus = [word['term'] for word in config['keywords'] if word.get('focused')]
        adaptive = bool(focus and any(s['id'] == FocusNeighbors.id and s['enabled'] for s in specs))
        state = {'version': 2, 'sources': list(dict.fromkeys(sources)), 'seed': seed,
                 'limit': config['chars_per_book'], 'sample_chars': config['sample_chars'],
                 'coverage_reserve': math.ceil(config['chars_per_book'] * .6) if adaptive else config['chars_per_book'],
                 'focus_terms': focus, 'specs': specs, 'evidence': [], 'pending': None, 'metrics': {},
                 'lengths': {}, 'hashes': {}, 'previous': previous or {}, 'strategy_state': {}}
        if content_seed is not None:
            state.update(content_seed=content_seed, seed_version=1, shared_reused_chars=0,
                         consumed_chars=0, seen_context_hints=[])
            ContentExecution(state).begin(config['chars_per_book'], 0, 0, 0, adaptive)
        for spec in specs:
            state['strategy_state'][spec['id']] = REGISTRY[spec['id']].initialize(state)
        return cls(state)

    def continue_search(self, allowance):
        """New execution allowance; pause/resume must never call this method."""
        state = self.state
        adaptive = bool(state['focus_terms'] and any(s['id'] == FocusNeighbors.id and s['enabled'] for s in state['specs']))
        self.execution.begin(allowance, consumed(state), consumed(state, 'baseline'), len(state['evidence']), adaptive)
        if state['pending'] and state['pending']['start'] is not None:
            state['pending']['end'] = min(state['pending']['end'], state['pending']['start'] + allowance)
        # Keep unfinished decisions and append the next deterministic set.
        for spec in state['specs']:
            hook = getattr(REGISTRY[spec['id']], 'begin_execution', None)
            if spec['enabled'] and hook:
                hook(state, state['strategy_state'][spec['id']], spec['params'])

    def add_context_hints(self, facts):
        for spec in self.state['specs']:
            hook = getattr(REGISTRY[spec['id']], 'accept_hints', None)
            if spec['enabled'] and hook:
                hook(self.state, self.state['strategy_state'][spec['id']], facts, spec['params'])

    def next(self):
        state = self.state
        if state['pending']:
            return state['pending']
        remaining = state['limit'] - consumed(state)
        if remaining <= 0:
            return None
        choices = []
        for spec in state['specs']:
            if spec['enabled']:
                choices += REGISTRY[spec['id']].propose(state, state['strategy_state'][spec['id']], spec['params'])
        baseline = baseline_ids(state)
        baseline_choices = [c for c in choices if c['strategy'] in baseline]
        reserve = max(0, state['coverage_reserve'] - consumed(state, 'baseline')) if baseline_choices else 0
        if remaining <= reserve:
            choices = baseline_choices
        if not choices:
            return None
        # Equal-priority base strategies share their reserved work. Source order
        # alone would otherwise let an early fixed window starve distribution.
        chosen = max(choices, key=lambda c: (c['priority'],
            -consumed(state, c['strategy']) if len(baseline) > 1 and c['strategy'] in baseline else 0,
            -state['sources'].index(c['url']), -(c['start'] or 0)))
        start, end = chosen['start'], chosen['end']
        if start is not None:
            end = min(end, start + remaining)
            if end <= start:
                raise ValueError('empty strategy suggestion')
        shared = [c for c in choices if c['url'] == chosen['url'] and c['start'] is not None and start is not None
                  and c['start'] <= start and end <= c['end']]
        if not shared:
            shared = [chosen]
        if start is not None and not any(c['strategy'] in baseline for c in shared):
            available = remaining - reserve
            if chosen['reason'].get('direction') == -1:
                start = max(start, end - available)
            else:
                end = min(end, start + available)
        state['pending'] = {'url': chosen['url'], 'start': start, 'end': end,
                            'requested_by': sorted({c['strategy'] for c in shared}),
                            'reasons': [{'strategy': c['strategy'], **c['reason']} for c in shared]}
        return state['pending']

    def register_source(self, url, length, digest):
        state = self.state
        if url in state['hashes'] and state['hashes'][url] != digest:
            if any(row['url'] == url for row in state['evidence']):
                raise ValueError('source_changed_during_scan')
            state['previous'][url] = []
            state['pending'] = None
            for spec in state['specs']:
                hook = getattr(REGISTRY[spec['id']], 'source_changed', None)
                if hook:
                    hook(state, state['strategy_state'][spec['id']], url)
        state['lengths'][url], state['hashes'][url] = length, digest
        if state['pending'] and state['pending']['url'] == url and state['pending']['start'] is None:
            state['pending'] = None

    def discover(self, after, urls):
        self.space.discover(after, urls)

    def execution_snapshot(self):
        state = self.state
        return self.execution.snapshot(consumed(state), sum(r['body_chars'] for r in
            state['evidence'][state.get('iteration_start', 0):]))

    def stop_reason(self):
        if consumed(self.state) >= self.state['limit']:
            return 'char_budget_reached'
        return 'sampling_pattern_exhausted' if baseline_ids(self.state) == {FixedInterval.id} else 'scope_exhausted'

    def observe(self, text, keywords, checked_at):
        state, pending = self.state, self.state['pending']
        start, end = pending['start'], pending['end']
        selected = text[start:end]
        hits, focused = [], []
        for term in state['focus_terms']:
            position = 0
            while (found := selected.find(term, position)) >= 0:
                hits.append([start + found, start + found + len(term)])
                position = found + len(term)
            if term in selected:
                focused.append(term)
        evidence = {**deepcopy(pending), 'counts': {word['term']: selected.count(word['term']) for word in keywords},
                    'body_chars': end - start, 'checked_at': checked_at,
                    'body_hash': state['hashes'][pending['url']], 'focus_intervals': intervals(hits),
                    'focus_hits': focused, 'evaluated_by': [s['id'] for s in state['specs'] if s['enabled']]}
        return self._record(evidence, text, keywords)

    def observe_cached(self, sample, keywords, checked_at):
        if self.state['focus_terms']:
            raise ValueError('focus matching requires the actual fragment')
        return self._record({**deepcopy(self.state['pending']),
            'counts': {word['term']: sample['counts'][word['term']] for word in keywords},
            'body_chars': sample['end'] - sample['start'], 'checked_at': checked_at,
            'body_hash': self.state['hashes'][self.state['pending']['url']],
            'focus_intervals': [], 'focus_hits': [],
            'evaluated_by': [s['id'] for s in self.state['specs'] if s['enabled']]})

    def observe_shared(self, fact, text, keywords, checked_at):
        # Source hash and exact offsets are checked by the context store after
        # transport validation. Reuse facts, but keep this seed's attribution.
        evidence = {**deepcopy(self.state['pending']),
            **{k: deepcopy(fact[k]) for k in ('counts', 'body_chars', 'body_hash', 'focus_intervals', 'focus_hits')},
            'checked_at': checked_at, 'reused_from_context': True,
            'evaluated_by': [s['id'] for s in self.state['specs'] if s['enabled']]}
        self.state['shared_reused_chars'] += evidence['body_chars']
        return self._record(evidence, text, keywords)

    def _record(self, evidence, text=None, keywords=None):
        state = self.state
        state['evidence'].append(evidence)
        url = evidence['url']
        # Once adjacent selected fragments join, a literal spanning their
        # boundary becomes observable. Recount only the union of read ranges;
        # never inspect an unselected gap or charge overlapping evidence twice.
        if text is not None:
            focused_hits, hit_terms = [], {}
            for start, end in coverage(state, url):
                fragment = text[start:end]
                for term in state['focus_terms']:
                    position = 0
                    while (found := fragment.find(term, position)) >= 0:
                        hit = [start + found, start + found + len(term)]
                        focused_hits.append(hit)
                        hit_terms.setdefault(term, []).append(hit)
                        position = found + len(term)
            for row in state['evidence']:
                if row['url'] == url:
                    row['focus_intervals'] = intervals([a, b] for a, b in focused_hits if a < row['end'] and row['start'] < b)
                    row['focus_hits'] = [term for term, hits in hit_terms.items() if any(a < row['end'] and row['start'] < b for a, b in hits)]
        for key in ['combined', 'baseline', *REGISTRY]:
            rows = [r for r in state['evidence'] if r['url'] == url and belongs(state, r, None if key == 'combined' else key)]
            if not rows:
                continue
            if text is not None:
                ranges = intervals((r['start'], r['end']) for r in rows)
                counts = {word['term']: sum(text[a:b].count(word['term']) for a, b in ranges) for word in keywords}
            else:
                counts = dict(evidence['counts'])  # Certified cache covers this entire source.
            state['metrics'].setdefault(key, {})[url] = counts
        for spec in state['specs']:
            if spec['enabled']:
                REGISTRY[spec['id']].observe(state, state['strategy_state'][spec['id']], evidence, spec['params'])
        state['pending'] = None
        if state.get('content_seed'):
            state['consumed_chars'] = consumed(state)
        return evidence

    def report(self, job_id, revision, status='running', reason=None):
        return {**deepcopy(self.state), 'pending': None, 'job_id': job_id, 'revision': revision,
                'status': status, 'stop_reason': reason}


def aggregate(rows, keywords, metrics=None):
    # The scheduler's intervals are disjoint. Each is included once, even if
    # multiple strategies requested it; strategy totals must not be added.
    counts = {word['term']: (sum(row['counts'][word['term']] for row in rows)
              if rows and all(word['term'] in row['counts'] for row in rows) else None) for word in keywords}
    if metrics is not None:
        sources = {row['url'] for row in rows}
        counts = {word['term']: (sum(metrics[url][word['term']] for url in sources)
                  if sources and all(word['term'] in metrics.get(url, {}) for url in sources) else None) for word in keywords}
    chars = sum(row['end'] - row['start'] for row in rows)
    weighted = (sum(counts[word['term']] * word['weight'] for word in keywords)
                if all(value is not None for value in counts.values()) else None)
    return {'scanned_chars': chars, 'matched_chars': sum(row['end'] - row['start'] for row in rows if
            any(row['counts'].get(word['term'], 0) > 0 for word in keywords)),
            'fragments': len(rows), 'source_count': len({row['url'] for row in rows}), 'counts': counts,
            'weighted_count': weighted, 'per_10k_chars': weighted * 10000 / chars if chars and weighted is not None else None}


def summarize(run, keywords, revision):
    if not run or run.get('version') != 2:
        return None
    results = []
    for spec in run['specs']:
        state = run['strategy_state'][spec['id']]
        outcome = run['status'] if spec['enabled'] else 'disabled'
        if spec['enabled'] and spec['id'] == FocusNeighbors.id:
            if not run['focus_terms']:
                outcome = 'no_focus_terms'
            elif not state['regions'] and outcome == 'completed':
                outcome = 'no_focus_hit'
        results.append({**spec, 'name': REGISTRY[spec['id']].name, 'status': outcome,
                        **aggregate([r for r in run['evidence'] if spec['id'] in r['requested_by']], keywords, run['metrics'].get(spec['id'], {})),
                        'details': REGISTRY[spec['id']].summarize(run, state, spec['params'])})
    bases = baseline_ids(run)
    metrics = {**(run['metrics'].get(Distributed.id, {}) if bases == {Distributed.id} else {}),
               **run['metrics'].get('baseline', {})}
    baseline = aggregate([r for r in run['evidence'] if belongs(run, r, 'baseline')], keywords, metrics)
    distributed = bases == {Distributed.id}
    return {'policy': 'distributed_char_density_v2' if distributed else 'baseline_char_density_v1',
            'baseline_strategies': sorted(bases), 'baseline': baseline,
            'job_id': run['job_id'], 'revision': run['revision'],
            'configuration_changed': revision != run['revision'], 'status': run['status'],
            'stop_reason': run['stop_reason'], 'char_budget': run['limit'], 'sample_chars': run['sample_chars'],
            'coverage_reserve': run['coverage_reserve'], 'focus_terms': run['focus_terms'],
            'combined': aggregate(run['evidence'], keywords, run['metrics'].get('combined', {})), 'strategies': results,
            'regions': next(r for r in results if r['id'] == FocusNeighbors.id)['details']['regions'],
            'ranking_score': baseline['per_10k_chars'],
            'ranking_scope': ('content_seed_' if run.get('content_seed') else 'latest_scan_') +
                             ('distributed_chars' if distributed else 'baseline_chars'),
            'content_seed': run.get('content_seed'), 'iteration': run.get('iteration'),
            'iteration_budget': run.get('iteration_budget', run['limit']),
            'iteration_scanned_chars': sum(r['body_chars'] for r in run['evidence'][run.get('iteration_start', 0):]),
            'shared_reused_chars': run.get('shared_reused_chars', 0),
            'evidence': run['evidence']}


def update_samples(page, text, evidence, keywords):
    """Replace overlapping evidence; preserve unknown terms outside this read."""
    start, end = evidence['start'], evidence['end']
    samples = []
    for old in page.get('samples', []):
        for left, right in gaps(old['start'], old['end'], [[start, end]]):
            samples.append({'start': left, 'end': right,
                            'counts': {term: text[left:right].count(term) for term in old['counts']}})
    samples.append({'start': start, 'end': end, 'counts': dict(evidence['counts'])})
    merged = []
    for sample in sorted(samples, key=lambda item: item['start']):
        if merged and merged[-1]['end'] == sample['start'] and set(merged[-1]['counts']) == set(sample['counts']):
            previous = merged[-1]
            previous['end'] = sample['end']
            previous['counts'] = {term: text[previous['start']:previous['end']].count(term) for term in previous['counts']}
        else:
            merged.append(sample)
    known = set.intersection(*(set(sample['counts']) for sample in merged))
    page['samples'] = merged
    page['sampled_chars'] = sum(s['end'] - s['start'] for s in merged)
    ranges = intervals((sample['start'], sample['end']) for sample in merged)
    page['counts'] = {term: sum(text[start:end].count(term) for start, end in ranges) for term in known}
