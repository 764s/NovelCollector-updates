"""Acquisition speed, breadth scheduling and durable round prefixes (no network)."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from core import Manager, validate_config
from novel_crawler.models import CrawlStop
from text_strategies import TextScheduler, ProgressiveDistributed
from transport import PauseRequested
from test_board_search import Factory, LIST, HOME, listing, book_url


class ProgressiveTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.factory = Factory()
        self.manager = Manager(self.tmp.name, transport_factory=self.factory, auto_start=False)

    def tearDown(self):
        self.manager.close()
        self.tmp.cleanup()

    def collection(self, names=('a', 'b', 'c'), rounds=3, chapters=16, samples=2, chars=40):
        self.factory.pages[LIST] = listing(names)
        for name in names:
            url = book_url(name)
            urls = [url[:-5] + '_' + str(i + 1) + '.html' for i in range(chapters)]
            self.factory.pages[url] = '<h1>书 ' + name + '</h1><article class="article-content"><p>小说简介：</p>' + ''.join(
                '<li class="mulu"><a href="' + target + '">正文</a></li>' for target in urls) + '</article>'
            for target in urls:
                self.factory.pages[target] = '<article class="article-content"><p>第一章</p><p>' + (
                    '修仙' if name == 'b' else '正文') * 1000 + '</p><div class="pagination2"></div></article>'
        return self.manager.create_collection({'name': '逐轮测试', 'board': {'type': 'category', 'base_url': LIST, 'keys': ''},
            'keywords': [{'term': '修仙', 'weight': 1}], 'max_books': len(names), 'sample_chars': chars,
            'strategies': [{'id': 'distributed'}],
            'progressive': {'enabled': True, 'rounds': rounds, 'initial_samples': samples, 'growth': 2}})

    def scan(self, collection, seed='fast'):
        job = self.manager.start_scan(collection['id'], content_seed=seed)
        self.manager._run_job(job['id'])
        return self.manager._job(self.manager._get_job(job['id']))

    def plan(self, name='a', seed='fast'):
        return self.manager.content.unpack(json.loads(self.manager.content.get(book_url(name), seed)['state']))

    def body_calls(self):
        return [url for _, url, _ in self.factory.calls if '_' in url]

    def test_all_books_get_a_coarse_round_before_any_gets_a_second(self):
        c = self.collection()
        job = self.scan(c)
        self.assertEqual(job['status'], 'completed', job)
        calls = self.body_calls()
        self.assertEqual([url.rsplit('/', 1)[-1].split('_')[0] for url in calls[:6]], ['a', 'a', 'b', 'b', 'c', 'c'])
        self.assertTrue(calls[6].startswith(book_url('b')[:-5] + '_'), 'The next round follows the previous ranking')
        for name in ('a', 'b', 'c'):
            plan = self.plan(name)
            self.assertEqual(plan['rounds_completed'], 3)
            self.assertEqual(plan['consumed_chars'], 320)
            self.assertEqual(len(plan['evidence']), 8)
            self.assertEqual(sum(url == book_url(name) for _, url, _ in self.factory.calls), 1)
        self.assertEqual(len(calls), 24)
        self.assertEqual(job['progress']['books_done'], 3)
        self.assertEqual(job['progress']['reused_directories'], 6)

    def test_new_execution_appends_rounds_instead_of_restarting(self):
        c = self.collection(names=('a',), rounds=1)
        self.assertEqual(self.scan(c)['status'], 'completed')
        before = self.plan()
        self.factory.calls.clear()
        self.assertEqual(self.scan(c)['status'], 'completed')
        after = self.plan()
        self.assertEqual(after['rounds_completed'], 2)
        self.assertEqual(after['evidence'][:2], before['evidence'])
        self.assertEqual(after['consumed_chars'], 160)
        self.assertNotIn(LIST, [r[1] for r in self.factory.calls])
        self.assertNotIn(book_url('a'), [r[1] for r in self.factory.calls])

    def test_pause_restart_preserves_pending_round_allowance_and_book_queue(self):
        c = self.collection(rounds=2)
        original, observations = TextScheduler.observe, []
        def pause(scheduler, *args):
            if len(observations) == 3:
                raise PauseRequested()
            observations.append(1)
            return original(scheduler, *args)
        with patch.object(TextScheduler, 'observe', pause):
            job = self.scan(c)
        self.assertEqual(job['status'], 'paused', job)
        pending = self.plan('b')['pending']
        self.assertEqual(self.plan('a')['rounds_completed'], 1)
        self.manager.close()
        self.manager = Manager(self.tmp.name, transport_factory=self.factory, auto_start=False)
        self.manager.resume_job(job['id'])
        self.manager._run_job(job['id'])
        self.assertEqual(self.manager._get_job(job['id'])['status'], 'completed')
        after = self.plan('b')
        self.assertEqual(after['rounds_completed'], 2)
        self.assertEqual(after['consumed_chars'], 160)
        self.assertEqual((after['evidence'][1]['url'], after['evidence'][1]['start']), (pending['url'], pending['start']))

    def test_more_than_100_body_reads_and_160_requests_continue_in_batches(self):
        c = self.collection(names=tuple('book' + str(i) for i in range(105)), rounds=1, chapters=1, samples=1)
        job = self.scan(c)
        self.assertEqual(job['status'], 'completed', job)
        self.assertEqual(job['progress']['books_done'], 105)
        self.assertEqual(job['progress']['body_attempts'], 105)
        self.assertGreater(job['progress']['request_count'], 160)
        self.assertEqual(job['progress']['request_batch'], 2)

    def test_thousand_book_target_completes_first_round(self):
        c = self.collection(names=tuple('book' + str(i) for i in range(1000)), rounds=1, chapters=1, samples=1)
        job = self.scan(c)
        self.assertEqual(job['status'], 'completed', job)
        self.assertEqual(job['progress']['discovered_books'], 1000)
        self.assertEqual(job['progress']['books_done'], 1000)
        self.assertEqual(job['progress']['request_batch'], 13)
        self.assertEqual(job['progress']['request_count'], 2014)
        self.assertEqual(self.manager.db.execute('SELECT COUNT(*) FROM content_searches').fetchone()[0], 1000)

    def test_focus_expansion_shares_round_budget_and_preserves_baseline_ranking(self):
        c = self.collection(names=('a', 'b'), rounds=2)
        c = self.manager.update_collection(c['id'], {
            'keywords': [{'term': '修仙', 'weight': 1, 'focused': True}],
            'strategies': [{'id': 'progressive_distributed'}, {'id': 'focus_neighbors'}]})
        job = self.scan(c)
        self.assertEqual(job['status'], 'completed', job)
        results = self.manager.snapshot()['results']
        match = next(row['strategy_summary'] for row in results if row['directory_url'] == book_url('b'))
        base = match['baseline']
        focus = next(s for s in match['strategies'] if s['id'] == 'focus_neighbors')
        self.assertEqual(match['completed_rounds'], 2)
        self.assertEqual(match['combined']['scanned_chars'], 160)
        self.assertGreater(focus['scanned_chars'], 0)
        self.assertGreaterEqual(base['scanned_chars'], 96)
        self.assertEqual(match['ranking_score'], base['per_10k_chars'])
        self.assertEqual(base['scanned_chars'] + focus['scanned_chars'], 160)
        self.assertEqual(self.plan('a')['rounds_completed'], 2)

    def test_resume_at_batch_boundary_keeps_request_totals(self):
        c = self.collection(names=('a',), rounds=1, chapters=1, samples=1)
        job = self.manager.start_scan(c['id'], content_seed='fast')
        state = self.manager._load_state(self.manager._get_job(job['id']))
        state.update(batch_requests=160, request_count=320, request_offset=160, request_batch=2)
        self.manager._save_state(job['id'], state)
        self.manager.pause_job(job['id'])
        self.manager.close()
        self.manager = Manager(self.tmp.name, transport_factory=self.factory, auto_start=False)
        self.manager.resume_job(job['id'])
        self.manager._run_job(job['id'])
        result = self.manager._job(self.manager._get_job(job['id']))
        self.assertEqual(result['status'], 'completed', result)
        self.assertEqual(result['progress']['request_batch'], 3)
        self.assertEqual(result['progress']['request_count'], 324)
        self.assertEqual(result['progress']['batch_requests'], 4)

    def test_all_discovered_links_are_saved_before_matching_and_target_is_unique(self):
        c = self.collection(rounds=1)
        self.factory.pages[LIST] = listing(['a', 'a', 'b', 'c'])
        with patch.object(TextScheduler, 'observe', side_effect=PauseRequested()):
            job = self.scan(c)
        self.assertEqual(job['status'], 'paused')
        self.assertEqual(job['progress']['discovered_books'], 3)
        self.assertEqual(job['progress']['books_done'], 0)
        self.assertEqual(len(self.manager.snapshot()['results']), 3)

    def test_site_refusals_do_not_start_another_batch(self):
        c = self.collection(rounds=1)
        self.factory.pages[book_url('a')] = CrawlStop('http_429_access_stop')
        job = self.scan(c)
        self.assertEqual(job['status'], 'stopped')
        self.assertEqual(job['error'], 'http_429_access_stop')
        self.assertEqual(job['progress']['request_batch'], 1)
        self.assertEqual(job['progress']['books_done'], 0)

    def test_short_books_and_other_seeds_reuse_exact_shared_facts_without_fetching(self):
        c = self.collection(names=('a',), rounds=3, chapters=1)
        self.factory.pages[book_url('a')[:-5] + '_1.html'] = '<article class="article-content"><p>第一章</p><p>修仙</p><div class="pagination2"></div></article>'
        first = self.scan(c)
        self.assertEqual(first['status'], 'completed')
        self.assertEqual(self.plan()['rounds_completed'], 1)
        self.factory.calls.clear()
        second = self.scan(c, seed='another')
        self.assertEqual(second['status'], 'completed', second)
        self.assertEqual(self.factory.calls, [])
        self.assertGreater(second['progress']['shared_reused_chars'], 0)
        self.assertEqual(self.plan(seed='another')['evidence'][0]['context_ref'], self.plan()['evidence'][0]['context_ref'])
        self.assertEqual(self.plan()['iteration'], 1, 'Another seed must not advance the original seed')

    def test_growing_target_fills_pool_without_resampling_old_rounds(self):
        c = self.collection(names=('a', 'b'), rounds=1)
        c = self.manager.update_collection(c['id'], {'max_books': 1})
        self.assertEqual(self.scan(c)['status'], 'completed')
        c = self.manager.update_collection(c['id'], {'max_books': 2})
        job = self.scan(c)
        self.assertEqual(job['status'], 'completed', job)
        self.assertEqual(self.plan('a')['rounds_completed'], 2)
        self.assertEqual(self.plan('b')['rounds_completed'], 1)
        self.assertEqual(job['progress']['discovered_books'], 2)

    def test_refresh_observes_new_board_version_with_a_full_candidate_pool(self):
        c = self.collection(names=('a',), rounds=1)
        self.assertEqual(self.scan(c)['status'], 'completed')
        previous = self.manager.boards.summaries()[0]['current_version']
        for automatic in (False, True):
            with self.subTest(automatic=automatic):
                if automatic:
                    self.manager.db.execute("UPDATE discovery_versions SET created_at='2000-01-01T00:00:00+00:00'")
                    self.manager.db.commit()
                self.factory.calls.clear()
                job = self.manager.start_scan(c['id'], content_seed='fast', refresh_board=not automatic)
                self.manager._run_job(job['id'])
                self.assertEqual(self.manager._get_job(job['id'])['status'], 'completed')
                self.assertEqual(sum(url == LIST for _, url, _ in self.factory.calls), 1)
                self.assertNotIn(book_url('a'), [r[1] for r in self.factory.calls])
                board = self.manager.boards.summaries()[0]
                self.assertNotEqual(board['current_version'], previous)
                self.assertEqual(board['observed_books'], 1)
                previous = board['current_version']

    def test_website_search_remains_a_discovery_strategy(self):
        c = self.collection(names=('a',), rounds=1)
        search = HOME + 'search/'
        self.factory.pages[search] = '<form action="/search/result.html" method="post"><input name="keyboard"><button>搜索</button></form>'
        self.factory.pages[HOME + 'search/result.html'] = listing(['a'])
        c = self.manager.update_collection(c['id'], {'board': {'type': 'site_search', 'base_url': search, 'keys': '种田'}})
        job = self.scan(c)
        self.assertEqual(job['status'], 'completed', job)
        self.assertTrue(any(method == 'POST' and dict(fields).get('keyboard') == '种田' for method, _, fields in self.factory.calls if fields))
        self.assertEqual(job['progress']['books_done'], 1)

    def test_first_pass_requests_are_lower_than_full_per_book_scanning(self):
        names = tuple('book' + str(i) for i in range(5))
        c = self.collection(names=names, rounds=1, chapters=32, chars=200)
        fast = self.scan(c)
        old = self.manager.create_collection({**c, 'name': '对照', 'progressive': {'enabled': False},
            'strategies': [{'id': 'distributed'}], 'chars_per_book': 4000})
        self.assertEqual(fast['status'], 'completed', fast)
        # A different board context is unnecessary: this compares body work directly.
        self.assertEqual(fast['progress']['body_attempts'], 10)
        # Legacy discovery has already selected these books: use a fresh store for a fair comparison.
        with tempfile.TemporaryDirectory() as temp:
            manager = Manager(temp, transport_factory=self.factory, auto_start=False)
            try:
                old = manager.create_collection({**old, 'board': c['board']})
                job = manager.start_scan(old['id'], content_seed='baseline')
                manager._run_job(job['id'])
                slow = manager._job(manager._get_job(job['id']))
                self.assertEqual(slow['status'], 'completed', slow)
                self.assertEqual(slow['progress']['body_attempts'], 100)
                self.assertEqual((fast['progress']['request_count'], slow['progress']['request_count']), (17, 107))
            finally:
                manager.close()

    def test_progressive_data_cannot_be_opened_by_old_releases(self):
        self.collection()
        self.assertEqual(self.manager.minimum_reader_version(), '2.6.0')

    def test_result_summaries_keep_scores_without_loading_all_source_details(self):
        c = self.collection(rounds=1, chapters=128)
        self.assertEqual(self.scan(c)['status'], 'completed')
        full = self.manager.snapshot()
        compact = self.manager.snapshot(detail_urls=set())
        self.assertLess(len(json.dumps(compact)), len(json.dumps(full)) / 2)
        keys = ('directory_url', 'scanned_chars', 'discovered_pages', 'counts', 'ranking_score', 'status')
        for brief, complete in zip(compact['results'], full['results']):
            self.assertEqual({k: brief[k] for k in keys}, {k: complete[k] for k in keys})
            self.assertFalse(brief['details_loaded'])
            self.assertEqual(brief['pages'], [])
        selected = self.manager.snapshot(detail_urls={book_url('b')})['results']
        self.assertEqual(next(r for r in selected if r['directory_url'] == book_url('b'))['pages'], full['results'][0]['pages'])
        self.assertTrue(all(not r['pages'] for r in selected if r['directory_url'] != book_url('b')))

    def test_failed_round_commit_does_not_skip_a_round_or_charge_an_extra_budget(self):
        c = self.collection(names=('a',), rounds=1)
        self.manager.db.execute("""CREATE TRIGGER fail_round BEFORE UPDATE ON jobs
            WHEN json_extract(NEW.state,'$.stage')='round' AND json_extract(NEW.state,'$.round_cursor')=1
            BEGIN SELECT RAISE(ABORT,'fixture'); END""")
        job = self.scan(c)
        self.assertEqual(job['status'], 'failed')
        self.assertEqual(self.plan().get('rounds_completed', 0), 0)
        self.manager.db.execute('DROP TRIGGER fail_round')
        self.manager.db.commit()
        self.factory.calls.clear()
        job = self.scan(c)
        self.assertEqual(job['status'], 'completed', job)
        self.assertEqual(self.plan()['rounds_completed'], 1)
        self.assertEqual(self.plan()['consumed_chars'], 80)
        self.assertEqual(self.factory.calls, [])

    def test_seed_prefix_has_one_position_in_each_dyadic_stratum(self):
        first = ProgressiveDistributed.initialize({'content_seed': 'a'})
        self.assertEqual(first, ProgressiveDistributed.initialize({'content_seed': 'a'}))
        self.assertNotEqual(first, ProgressiveDistributed.initialize({'content_seed': 'b'}))
        for count in (2, 4, 8, 16, 32):
            cells = [int(ProgressiveDistributed.fraction(i, first['shift']) * count) for i in range(count)]
            self.assertEqual(sorted(cells), list(range(count)))

    def test_default_target_1000_and_invalid_budgets(self):
        cfg = {'keywords': [{'term': '修仙'}], 'progressive': {'enabled': True}}
        self.assertEqual(validate_config(cfg)['max_books'], 1000)
        for value in ({'rounds': 0}, {'rounds': True}, {'growth': 1}, {'initial_samples': -1}, {'enabled': 1}):
            with self.subTest(value=value), self.assertRaises(ValueError):
                validate_config({**cfg, 'progressive': {'enabled': True, **value}})


if __name__ == '__main__':
    unittest.main()
