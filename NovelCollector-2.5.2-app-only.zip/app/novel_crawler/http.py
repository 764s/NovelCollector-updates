"""One-request-at-a-time HTTP with robots rules and non-bypass stop behavior."""
import email.utils
from http.client import HTTPException
import re
import time
from datetime import datetime, timezone
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlsplit, unquote
from urllib.request import HTTPRedirectHandler, Request, build_opener
from .models import CrawlStop


def utcnow():
    return datetime.now(timezone.utc).isoformat()

class Robots:
    """Allow/Disallow including '*' and terminal '$'; longest rule, Allow ties."""
    def __init__(self, text, agent):
        groups, agents, rules, delays = [], [], [], []
        in_rules = False
        for raw in text.splitlines():
            line = raw.split('#', 1)[0].strip()
            if not line or ':' not in line:
                continue
            key, value = (v.strip() for v in line.split(':', 1))
            key = key.lower()
            if key == 'user-agent':
                if in_rules:
                    groups.append((agents, rules, delays))
                    agents, rules, delays, in_rules = [], [], [], False
                agents.append(value.lower())
            elif agents:
                in_rules = True
                if key in ('allow', 'disallow') and value:
                    rules.append((key == 'allow', value))
                elif key == 'crawl-delay':
                    try: delays.append(max(0, float(value)))
                    except ValueError: pass
        if agents:
            groups.append((agents, rules, delays))
        matched = []
        for names, rs, ds in groups:
            score = max((0 if n == '*' else len(n) for n in names if n == '*' or n in agent.lower()), default=-1)
            if score >= 0:
                matched.append((score, rs, ds))
        best = max((g[0] for g in matched), default=-1)
        self.rules = [r for score, rs, _ in matched if score == best for r in rs]
        self.delay = max([d for score, _, ds in matched if score == best for d in ds] or [0])

    def allows(self, url):
        parts = urlsplit(url)
        path = unquote(parts.path) + (('?' + parts.query) if parts.query else '')
        matches = []
        for allow, pattern in self.rules:
            end = pattern.endswith('$')
            raw = pattern[:-1] if end else pattern
            regex = '^' + re.escape(unquote(raw)).replace(r'\*', '.*') + ('$' if end else '')
            if re.search(regex, path):
                matches.append((len(raw.replace('*', '')), allow))
        return max(matches, default=(0, True))[1]

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def retry_after_seconds(value, now=None):
    if not value:
        return None
    try:
        return max(0, float(value))
    except ValueError:
        try:
            date = email.utils.parsedate_to_datetime(value)
            return max(0, date.timestamp() - (time.time() if now is None else now))
        except (ValueError, TypeError, OverflowError):
            return None


def looks_like_challenge(html):
    title = re.search(r'<title[^>]*>(.*?)</title>', html, re.I | re.S)
    if title and re.search(r'captcha|just a moment|access denied|verify (?:you are|you.re) human|robot check|attention required|人机验证|安全验证|访问验证', title[1], re.I):
        return True
    return bool(re.search(r'(?:id|class)=[\"\'][^\"\']*(?:cf-chl|cf-turnstile|g-recaptcha|h-captcha|challenge-form)|/cdn-cgi/challenge-platform/', html, re.I))

class HttpClient:
    def __init__(self, definition, config, state, save, opener=None, sleep=time.sleep, monotonic=time.monotonic):
        self.definition, self.config, self.state, self.save = definition, config, state, save
        self.opener = opener or build_opener(NoRedirect())
        self.sleep, self.monotonic = sleep, monotonic
        self.last_end, self.robots = None, None

    def _validate(self, url):
        try:
            parts = urlsplit(url)
            home = urlsplit(self.definition.homepage)
            valid = parts.scheme == 'https' and parts.hostname in self.definition.allowed_hosts and parts.hostname == home.hostname and parts.port in (None, 443) and not parts.username and not parts.password
        except ValueError:
            valid = False
        if not valid:
            raise CrawlStop('external_or_unsafe_url', url)

    def load_robots(self):
        url = urljoin(self.definition.homepage, '/robots.txt')
        text, _ = self.fetch(url, robots_request=True)
        self.robots = Robots(text, self.definition.user_agent)
        self.state['robots'] = {'url': url, 'checked_at': utcnow(), 'rules': self.robots.rules, 'crawl_delay': self.robots.delay}
        self.save()

    def fetch(self, url, robots_request=False):
        for redirects in range(6):
            self._validate(url)
            if robots_request and urlsplit(url).path != '/robots.txt':
                raise CrawlStop('robots_redirect_changed_path', url)
            if not robots_request and (self.robots is None or not self.robots.allows(url)):
                raise CrawlStop('robots_denied_or_unavailable', url)
            if self.state.get('request_count', 0) >= self.config.max_requests:
                raise CrawlStop('request_budget_reached', url)
            interval = max(self.config.interval, self.robots.delay if self.robots else 0)
            if self.last_end is not None:
                self.sleep(max(0, interval - (self.monotonic() - self.last_end)))
            self.state['request_count'] = self.state.get('request_count', 0) + 1
            record = {'url': url, 'started_at': utcnow(), 'kind': 'robots' if robots_request else 'html'}
            self.state.setdefault('requests', []).append(record)
            self.save()  # Count attempted requests even if interrupted.
            response = None
            try:
                req = Request(url, headers={'User-Agent': self.definition.user_agent, 'Accept': 'text/html,text/plain;q=0.9'})
                try:
                    response = self.opener.open(req, timeout=self.config.timeout)
                except HTTPError as error:
                    response = error
                status = response.code
                record['status'] = status
                wait = retry_after_seconds(response.headers.get('Retry-After'))
                if wait is not None:
                    record['retry_after_seconds'] = wait
                if status in (403, 429):
                    raise CrawlStop(f'http_{status}_access_stop', url, wait)
                if wait is not None:
                    raise CrawlStop('retry_after_stop', url, wait)
                if status in (301, 302, 303, 307, 308):
                    target = urljoin(url, response.headers.get('Location', ''))
                    self._validate(target)  # Never follow external redirects automatically.
                    if not robots_request and not self.robots.allows(target):
                        raise CrawlStop('robots_denied_redirect', target)
                    if redirects >= 5 or not response.headers.get('Location'):
                        raise CrawlStop('redirect_limit_or_missing_location', url)
                    record['redirect_to'] = target
                    url = target
                    continue
                if status != 200:
                    raise CrawlStop(f'http_{status}_stop', url, wait)
                content_type = response.headers.get_content_type()
                allowed = ('text/plain',) if robots_request else ('text/html', 'application/xhtml+xml')
                if content_type not in allowed:
                    raise CrawlStop('unexpected_content_type', url)
                data = response.read(self.config.max_response_bytes + 1)
                record['response_bytes'] = len(data)
                if len(data) > self.config.max_response_bytes:
                    raise CrawlStop('response_size_limit', url)
                charset = response.headers.get_content_charset() or 'utf-8'
                try:
                    html = data.decode(charset)
                except (UnicodeError, LookupError):
                    raise CrawlStop('unsupported_or_invalid_encoding', url)
                if looks_like_challenge(html):
                    raise CrawlStop('captcha_or_challenge_stop', url)
                if robots_request and re.search(r'<(?:!doctype|html|head|body|title|form)\b', html, re.I):
                    raise CrawlStop('invalid_robots_html', url)
                substantive = '\n'.join(line.split('#', 1)[0].strip() for line in html.splitlines()).strip()
                if robots_request and substantive and not re.search(r'^(?:user-agent|sitemap)\s*:', substantive, re.I | re.M):
                    raise CrawlStop('invalid_robots_content', url)
                return html, url
            except (URLError, TimeoutError, OSError, HTTPException) as error:
                record['error'] = type(error).__name__
                raise CrawlStop('network_error_stop', url) from error
            finally:
                if response is not None:
                    response.close()
                self.last_end = self.monotonic()
                record['finished_at'] = utcnow()
                self.save()
        raise CrawlStop('redirect_limit', url)
