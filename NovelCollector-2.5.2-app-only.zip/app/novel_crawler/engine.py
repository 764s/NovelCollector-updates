"""Reusable deterministic orchestration, separate from site-specific extraction."""
import csv
import copy
import hashlib
import json
from dataclasses import asdict
from pathlib import Path
from .http import HttpClient, utcnow
from .models import Book, CrawlStop, UnknownTemplate


def atomic_json(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)


def match_text(text, keyword, max_snippets, snippet_chars):
    """Literal, case-sensitive, non-overlapping counts; no regular expressions or LLM."""
    count, snippets, start = 0, [], 0
    while True:
        index = text.find(keyword, start)
        if index < 0:
            break
        count += 1
        if len(snippets) < max_snippets and snippet_chars >= len(keyword):
            left = max(0, index - (snippet_chars - len(keyword)) // 2)
            snippets.append(text[left:left + snippet_chars].replace('\n', ' '))
        start = index + len(keyword)
    return count, snippets

def match_keywords(text, terms, max_snippets, snippet_chars):
    """ANY eligibility; exact per-term counts, with one shared excerpt budget."""
    counts, events = {}, []
    for order, term in enumerate(terms):
        counts[term], _ = match_text(text, term, 0, 0)
        start = 0
        # Only the first budget-sized matches for each term can win global order.
        for _ in range(max_snippets):
            index = text.find(term, start)
            if index < 0:
                break
            if len(term) <= snippet_chars:
                events.append((index, order, term))
            start = index + len(term)
    snippets = []
    for index, _, term in sorted(events)[:max_snippets]:
        left = max(0, index - (snippet_chars - len(term)) // 2)
        snippets.append({'keyword': term, 'context': text[left:left + snippet_chars].replace('\n', ' ')})
    return counts, snippets


def migrate_state_v1(state):
    """Lossless single-term v1→v2 metadata upgrade; never invent other-term counts."""
    state = copy.deepcopy(state)
    if state.get('schema_version') == 2:
        return state
    if state.get('schema_version') != 1:
        raise ValueError('unsupported state schema version')
    config = state['identity']['config']
    config.setdefault('keywords', [])
    config.setdefault('start_url', None)
    term = config['keyword']
    for book in state['books']:
        for page in book['pages']:
            page['keyword_counts'] = {term: page['keyword_count']}
            page['matched_any'] = page['keyword_count'] > 0
        for snippet in book['snippets']:
            snippet.setdefault('keyword', term)
    if state['status'] == 'pilot_complete':
        state.setdefault('completed_at', state['updated_at'])
    state['schema_version'] = 2
    return state


def csv_safe(row):
    # Prevent untrusted metadata/keywords being executed as spreadsheet formulas.
    return {key: ("'" + value if isinstance(value, str) and value.lstrip().startswith(('=', '+', '-', '@')) else value) for key, value in row.items()}


class Crawler:
    def __init__(self, adapter, config, output, resume=False, client_factory=HttpClient):
        self.adapter, self.config, self.output = adapter, config, Path(output)
        self.output.mkdir(parents=True, exist_ok=True)
        self.state_path = self.output / 'state.json'
        self.seed = adapter.seed_kind(config.start_url) if config.start_url is not None else None
        self.bootstrap_body = None
        migrated = False
        identity = {'adapter': asdict(adapter.definition), 'config': asdict(config)}
        if self.state_path.exists():
            if not resume:
                raise ValueError('state.json already exists; use --resume or another --output directory')
            loaded = json.loads(self.state_path.read_text(encoding='utf-8'))
            self.state = migrate_state_v1(loaded)
            migrated = loaded.get('schema_version') != self.state['schema_version']
            if self.state['identity'] != json.loads(json.dumps(identity)):
                raise ValueError('resume requires exactly the same adapter version and run configuration')
        else:
            if resume:
                raise ValueError('cannot resume: no state.json')
            self.state = {'schema_version': 2, 'identity': identity, 'started_at': utcnow(), 'status': 'new', 'request_count': 0, 'requests': [], 'books': [], 'scanned_body_pages': 0, 'attempted_body_pages': 0}
        self.client = client_factory(adapter.definition, config, self.state, self.save)
        if migrated:
            atomic_json(self.state_path, self.state)

    def save(self):
        self.state['updated_at'] = utcnow()
        atomic_json(self.state_path, self.state)

    def discover(self):
        if self.seed and not self.state.get('seed_ready'):
            kind, url = self.seed
            self.state['seed_kind'], self.state['seed_url'] = kind, url
            if kind == 'category':
                self.state['category_url'] = url
            elif kind == 'directory':
                self.state['discovered_book_urls'] = [url]
                self.state['selected_book_urls'] = [url]
            elif kind == 'body':
                if self.state['attempted_body_pages'] >= self.config.max_body_pages:
                    raise CrawlStop('body_request_budget_reached', url)
                self.state['attempted_body_pages'] += 1
                self.save()
                html, final_url = self.client.fetch(url)
                directory_url = self.adapter.directory_from_body(html, final_url)
                self.state['seed_body_url'] = final_url
                self.state['discovered_book_urls'] = [directory_url]
                self.state['selected_book_urls'] = [directory_url]
                self.bootstrap_body = (final_url, html)
            self.state['seed_ready'] = True
            self.save()
        if 'discovered_book_urls' not in self.state:
            if not self.state.get('category_url'):
                home = self.state.get('seed_url', self.adapter.definition.homepage)
                html, url = self.client.fetch(home)
                self.state['category_url'] = self.adapter.category_url(html, url)
                self.save()
            html, url = self.client.fetch(self.state['category_url'])
            all_urls = self.adapter.book_links(html, url)
            self.state['discovered_book_urls'] = all_urls
            self.state['selected_book_urls'] = all_urls[:self.config.max_books]
            self.save()
        known = {b['url'] for b in self.state['books']}
        processed = self.state.setdefault('processed_directory_urls', [b.get('requested_url', b['url']) for b in self.state['books']])
        for url in self.state['selected_book_urls']:
            if url in processed:
                continue
            html, final_url = self.client.fetch(url)
            if final_url in known:
                processed.append(url)
                self.save()
                continue
            try:
                book = self.adapter.directory(html, final_url)
            except UnknownTemplate as error:
                self.state['books'].append({'url': url, 'requested_url': url, 'title': '(目录模板未识别)', 'body_urls': [], 'pending': [], 'pages': [], 'status': 'unknown_directory_template', 'error': str(error), 'snippets': []})
                processed.append(url)
                self.save()
                continue
            pending = list(book.body_urls)
            not_queued = []
            if self.state.get('seed_body_url'):
                if self.state['seed_body_url'] not in pending:
                    raise UnknownTemplate('body seed is absent from the observed book directory')
                index = pending.index(self.state['seed_body_url'])
                not_queued, pending = pending[:index], pending[index:]
            self.state['books'].append({'requested_url': url, 'url': book.url, 'title': book.title, 'body_urls': list(book.body_urls), 'pending': pending, 'not_queued_before_seed': not_queued, 'pages': [], 'status': 'pending', 'snippets': []})
            processed.append(url)
            known.add(book.url)
            self.save()

    def run(self):
        # A completed bounded pilot is terminal: resume is a no-op, not expansion.
        if self.state['status'] == 'pilot_complete':
            self.export()
            return self.state
        if self.state.get('stop', {}).get('reason') in ('http_403_access_stop', 'http_429_access_stop', 'captcha_or_challenge_stop'):
            raise ValueError('access stop is terminal for this run; do not automatically retry or bypass')
        not_before = self.state.get('stop', {}).get('not_before_epoch')
        if not_before is not None:
            import time
            if time.time() < not_before:
                raise ValueError('Retry-After has not expired; resume refused')
        self.state['status'] = 'running'
        self.state.pop('stop', None)
        self.save()
        try:
            self.client.load_robots()
            self.discover()
            for record in self.state['books']:
                if record['status'].startswith('unknown'):
                    continue
                book = Book(record['url'], record['title'], tuple(record['body_urls']))
                while record['pending'] and len(record['pages']) < self.config.pages_per_book:
                    url = record['pending'][0]
                    cached_seed = bool(self.bootstrap_body and self.bootstrap_body[0] == url)
                    if not cached_seed:
                        if self.state['attempted_body_pages'] >= self.config.max_body_pages:
                            break
                        self.state['attempted_body_pages'] += 1
                        self.save()
                    if cached_seed:
                        final_url, html = self.bootstrap_body
                        self.bootstrap_body = None
                    else:
                        html, final_url = self.client.fetch(url)
                    seen = {p['url'] for p in record['pages']} | {p['final_url'] for p in record['pages']} | set(record.get('duplicate_alias_urls', {})) | set(record.get('duplicate_alias_urls', {}).values()) | set(record.get('not_queued_before_seed', []))
                    if final_url in seen:
                        record.setdefault('duplicate_alias_urls', {})[url] = final_url
                        record['pending'].pop(0)
                        self.save()
                        continue
                    extraction_book = book
                    if url == book.body_urls[0] and final_url != url:
                        extraction_book = Book(book.url, book.title, (final_url,) + book.body_urls[1:])
                    try:
                        body = self.adapter.body(html, final_url, extraction_book)
                    except UnknownTemplate as error:
                        record['status'] = 'unknown_body_template'
                        record['error'] = str(error)
                        record['failed_url'] = final_url
                        self.save()
                        break
                    counts, snippets = match_keywords(body.text, self.config.terms, self.config.max_snippets_per_book - len(record['snippets']), self.config.snippet_chars)
                    count = counts[self.config.keyword]
                    page = {'url': url, 'final_url': final_url, 'fetched_at': utcnow(), 'body_characters': len(body.text), 'body_sha256': hashlib.sha256(body.text.encode()).hexdigest(), 'keyword_count': count, 'keyword_counts': counts, 'matched_any': any(counts.values()), 'removed_preamble_paragraphs': body.removed_preamble_paragraphs}
                    record['pages'].append(page)
                    record['pending'].pop(0)
                    for snippet in snippets:
                        record['snippets'].append({'url': final_url, **snippet})
                    seen = {p['url'] for p in record['pages']} | {p['final_url'] for p in record['pages']} | set(record.get('duplicate_alias_urls', {})) | set(record.get('duplicate_alias_urls', {}).values()) | set(record.get('not_queued_before_seed', []))
                    record['pending'] = [u for u in record['pending'] if u not in seen]
                    # Only observed next-page links, never synthesized suffixes.
                    for next_url in body.next_urls:
                        if next_url not in record['body_urls']:
                            record['body_urls'].append(next_url)
                        if next_url not in seen and next_url not in record['pending']:
                            record['pending'].append(next_url)
                    self.state['scanned_body_pages'] += 1
                    record['status'] = 'scanning'
                    self.save()
                    print(f"{self.state['scanned_body_pages']:03d} | {record['title']} | {url} | {json.dumps(counts, ensure_ascii=False)}", flush=True)
                if not record['status'].startswith('unknown'):
                    record['status'] = 'sample_limit_reached' if record['pending'] else ('seed_range_scanned' if record.get('not_queued_before_seed') else 'all_discovered_pages_scanned')
                self.save()
            self.state['status'] = 'pilot_complete'
            self.state['completed_at'] = utcnow()
        except CrawlStop as stop:
            self.state['status'] = 'stopped'
            self.state['stop'] = {'reason': stop.reason, 'url': stop.url, 'at': utcnow(), 'retry_after_seconds': stop.retry_after}
            if stop.retry_after is not None:
                import time
                self.state['stop']['not_before_epoch'] = time.time() + stop.retry_after
        except UnknownTemplate as error:
            self.state['status'] = 'stopped'
            self.state['stop'] = {'reason': 'unknown_discovery_template', 'detail': str(error), 'at': utcnow()}
        except KeyboardInterrupt:
            self.state['status'] = 'interrupted'
        finally:
            self.save()
            self.export()
        return self.state

    def export(self):
        terms, rows = self.config.terms, []
        for b in self.state['books']:
            counts = {term: sum(p['keyword_counts'][term] for p in b['pages']) for term in terms}
            match_pages = {term: sum(p['keyword_counts'][term] > 0 for p in b['pages']) for term in terms}
            rows.append({'title': b['title'], 'directory_url': b['url'], 'keyword': self.config.keyword,
                'keywords': list(terms), 'scanned_pages': len(b['pages']), 'discovered_body_pages': len(b['body_urls']),
                'unscanned_known_pages': len(b['pending']) + len(b.get('not_queued_before_seed', [])),
                'not_queued_before_seed': len(b.get('not_queued_before_seed', [])),
                'duplicate_alias_urls': len(b.get('duplicate_alias_urls', {})),
                'matching_pages': sum(p['matched_any'] for p in b['pages']),
                'keyword_occurrences': counts[self.config.keyword], 'total_keyword_occurrences': sum(counts.values()),
                'keyword_counts': counts, 'keyword_matching_pages': match_pages,
                'status': b['status'], 'snippets': b['snippets']})
        scope = getattr(self.adapter, 'scope_description', '从适配器发现入口选择书目；仅扫描正文样本，非全站或全书结论')
        if self.seed:
            scope = f"指定起始页 {self.state.get('seed_url', self.seed[1])}（{self.seed[0]}）；按适配器已观察到的目录链接扫描，正文种子从该页开始；有界样本"
        summary = {'schema_version': 2, 'started_at': self.state['started_at'], 'completed_at': self.state.get('completed_at'),
            'updated_at': self.state['updated_at'], 'status': self.state['status'], 'scope': scope,
            'matching_mode': 'ANY', 'keywords': list(terms), 'config': asdict(self.config),
            'category_url': self.state.get('category_url'),
            'discovered_book_count_on_category_page': len(self.state.get('discovered_book_urls', [])) if self.state.get('category_url') else None,
            'unselected_book_count_on_category_page': max(0, len(self.state.get('discovered_book_urls', [])) - len(self.state.get('selected_book_urls', []))) if self.state.get('category_url') else None,
            'request_count': self.state['request_count'], 'attempted_body_pages': self.state['attempted_body_pages'],
            'scanned_body_pages': self.state['scanned_body_pages'], 'stop': self.state.get('stop'), 'books': rows}
        atomic_json(self.output / 'summary.json', summary)
        with (self.output / 'books.csv').open('w', encoding='utf-8-sig', newline='') as f:
            fields = ['title', 'directory_url', 'scanned_pages', 'discovered_body_pages', 'unscanned_known_pages', 'matching_pages', 'total_keyword_occurrences', 'status']
            fields += [f'count:{term}' for term in terms] + [f'matching_pages:{term}' for term in terms]
            writer = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
            writer.writeheader()
            for row in rows:
                writer.writerow(csv_safe({**row, **{f'count:{t}': row['keyword_counts'][t] for t in terms}, **{f'matching_pages:{t}': row['keyword_matching_pages'][t] for t in terms}}))
        with (self.output / 'pages.csv').open('w', encoding='utf-8-sig', newline='') as f:
            fields = ['book_title', 'url', 'final_url', 'fetched_at', 'body_characters', 'body_sha256', 'keyword_count', 'matched_any', 'removed_preamble_paragraphs']
            fields += [f'count:{term}' for term in terms]
            writer = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
            writer.writeheader()
            for b in self.state['books']:
                for page in b['pages']:
                    writer.writerow(csv_safe({'book_title': b['title'], **page, **{f'count:{t}': page['keyword_counts'][t] for t in terms}}))
        text = ['# 正文关键词试跑结果', '', f"- 开始：{summary['started_at']}", f"- 完成：{summary['completed_at']}",
            f"- 状态：{summary['status']}",
            f"- 实际成功提取正文：{summary['scanned_body_pages']} 页；正文尝试：{summary['attempted_body_pages']} 次；全部 HTTP 请求：{summary['request_count']} 次",
            f"- 关键词：{'、'.join(terms)}；ANY 匹配，任一词命中即可（字面量、区分大小写、每词非重叠计数；不同词可以重叠）",
            f"- 范围：{summary['scope']}；正文网页不等同于章节数",
            '- 未命中只表示已扫描样本无这些字面关键词；其余正文、分类分页和全站未扫描，不能判定整本没有',
            '- 简介、目录、书名、章节标题、推荐、推广和导航不计入；未知模板直接停止该书提取',
            '- 每本所有关键词合计最多2条短上下文；没有摘录不代表该词没命中，以逐词计数为准。不保存正文全文', '']
        if summary['stop']:
            text += [f"停止原因：{summary['stop']}", '']
        for row in rows:
            text += [f"## {row['title']}", f"- 目录：{row['directory_url']}",
                f"- 已扫描 {row['scanned_pages']} 页 / 已发现 {row['discovered_body_pages']} 页；已知未扫描 {row['unscanned_known_pages']} 页",
                f"- ANY 命中 {row['matching_pages']} 页；状态 {row['status']}"]
            for term in terms:
                text += [f"- {term}：{row['keyword_counts'][term]} 次，{row['keyword_matching_pages'][term]} 页"]
            for snippet in row['snippets']:
                text += [f"- {snippet['keyword']} 短上下文：{snippet['context']}（{snippet['url']}）"]
            text.append('')
        (self.output / 'REPORT.md').write_text('\n'.join(text), encoding='utf-8')
