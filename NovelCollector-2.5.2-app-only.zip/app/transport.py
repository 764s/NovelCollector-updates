"""Conservative, bounded transport shared by collection and download jobs.

All network requests (including robots and redirects) use GLOBAL_GATE. DNS answers
are checked and the TLS connection is pinned to a checked public address. No
urllib opener, environment proxy, cookies, or ambient credentials are used.
"""
from dataclasses import dataclass
from datetime import datetime, timezone
from html.parser import HTMLParser
from http.client import HTTPSConnection, HTTPException
from urllib.parse import urlsplit, urljoin, urlencode
import email.utils
import ipaddress
import math
import re
import socket
import ssl
import threading
import time

from novel_crawler.adapters.shuku52 import Shuku52Adapter
from novel_crawler.http import Robots, looks_like_challenge, retry_after_seconds
from novel_crawler.models import CrawlStop


def utcnow():
    return datetime.now(timezone.utc).isoformat()


class PauseRequested(CrawlStop):
    def __init__(self, url=''):
        super().__init__('paused', url)


@dataclass(frozen=True)
class FetchResult:
    html: str
    final_url: str
    status: int
    etag: str | None = None
    last_modified: str | None = None
    source_updated_at: str | None = None
    source_date_kind: str | None = None


class RateGate:
    """Hold this gate from before request start until the response is closed."""
    def __init__(self, interval=3.2):
        self.interval = max(3.2, interval)
        self.lock = threading.Lock()
        # Also leaves a conservative gap on a process restart.
        self.last_end = time.monotonic()

    def acquire(self, cancellation, delay=0):
        while not self.lock.acquire(timeout=0.1):
            if cancellation.is_set():
                raise PauseRequested()
        try:
            wait = max(self.interval, delay) - (time.monotonic() - self.last_end)
            if cancellation.wait(max(0, wait)):
                raise PauseRequested()
        except BaseException:
            self.lock.release()
            raise

    def release(self):
        self.last_end = time.monotonic()
        self.lock.release()


GLOBAL_GATE = RateGate()


def _date(value):
    if not value or len(value) > 100:
        return None
    value = value.strip()
    try:
        result = datetime.fromisoformat(value.replace('Z', '+00:00'))
        return result.isoformat()
    except ValueError:
        try:
            return email.utils.parsedate_to_datetime(value).isoformat()
        except (ValueError, TypeError, OverflowError):
            return None


class _Dates(HTMLParser):
    def __init__(self):
        super().__init__()
        self.updated = None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        key = (attrs.get('property') or attrs.get('name') or attrs.get('itemprop') or '').lower()
        if tag == 'meta' and key in ('article:modified_time', 'og:updated_time', 'datemodified', 'last-modified', 'dc.modified', 'dcterms.modified'):
            self.updated = self.updated or _date(attrs.get('content'))
        if tag == 'time' and ('datemodified' in key or attrs.get('class', '').lower() in ('updated', 'modified', 'update-time')):
            self.updated = self.updated or _date(attrs.get('datetime'))


def source_date(html, last_modified=None):
    parser = _Dates()
    parser.feed(html)
    if parser.updated:
        return parser.updated, 'explicit_modified_metadata'
    value = _date(last_modified)
    return (value, 'last_modified_header') if value else (None, None)


class _PinnedHTTPSConnection(HTTPSConnection):
    def __init__(self, hostname, address, timeout):
        super().__init__(hostname, 443, timeout=timeout, context=ssl.create_default_context())
        self.address = address

    def connect(self):
        deadline = getattr(self, 'deadline', time.monotonic() + self.timeout)
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError('request deadline exceeded')
        self.sock = socket.create_connection((self.address, 443), min(self.timeout, remaining))
        try:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError('request deadline exceeded')
            self.sock.settimeout(remaining)
            self.sock = self._context.wrap_socket(self.sock, server_hostname=self.host)
        except BaseException:
            self.sock.close()
            raise


class _SocketWatchdog:
    """Interrupt slow header/body reads without touching application state."""
    def __init__(self, connection, cancellation, deadline):
        self.connection, self.cancellation, self.deadline = connection, cancellation, deadline
        self.done = threading.Event()
        self.retained_socket = None
        self.thread = threading.Thread(target=self._run, daemon=True, name='novel-request-deadline')
        self.thread.start()

    def _run(self):
        while not self.done.is_set():
            sock = getattr(self.connection, 'sock', None)
            if sock is not None:
                self.retained_socket = sock
            remaining = self.deadline - time.monotonic()
            if self.cancellation.is_set() or remaining <= 0:
                # HTTPConnection can clear .sock after handing it to a response.
                for sock in (getattr(self.connection, 'sock', None), self.retained_socket):
                    if sock is not None:
                        try:
                            sock.shutdown(socket.SHUT_RDWR)
                        except (OSError, ValueError):
                            pass
                        try:
                            sock.close()
                        except (OSError, ValueError):
                            pass
                return
            self.done.wait(min(0.025, remaining))

    def stop(self):
        self.done.set()
        self.thread.join(timeout=0.5)


class SafeTransport:
    def __init__(self, adapter=None, max_requests=160, cancellation=None,
                 on_request=None, gate=None, request_count=0, timeout=30,
                 max_response_bytes=4_000_000, resolver=None):
        self.adapter = adapter or Shuku52Adapter()
        self.definition = self.adapter.definition
        if type(max_requests) is not int or not 1 <= max_requests <= 160:
            raise ValueError('max_requests must be 1–160')
        if type(request_count) is not int or request_count < 0:
            raise ValueError('invalid request count')
        self.max_requests = max_requests
        self.request_count = request_count
        self.cancellation = cancellation or threading.Event()
        self.on_request = on_request or (lambda record: None)
        self.gate = gate or GLOBAL_GATE
        self.timeout = min(30, max(1, timeout))
        self.max_response_bytes = min(4_000_000, max_response_bytes)
        self.resolver = resolver or socket.getaddrinfo
        self.robots = None

    def _check_cancel(self, url=''):
        if self.cancellation.is_set():
            raise PauseRequested(url)

    def _validate(self, url, robots=False):
        try:
            p = urlsplit(url)
            if (p.scheme != 'https' or p.hostname not in self.definition.allowed_hosts
                    or p.port not in (None, 443) or p.username or p.password
                    or p.fragment or '\\' in url
                    or ('%' in p.path and not hasattr(self.adapter, 'validate_request_url'))
                    or any(ord(c) <= 32 for c in url) or any(segment in ('.', '..') for segment in p.path.split('/'))):
                raise ValueError()
            if robots:
                if p.path != '/robots.txt' or p.query:
                    raise ValueError()
                return urljoin(self.definition.homepage, '/robots.txt')
            if hasattr(self.adapter, 'validate_request_url'):
                return self.adapter.validate_request_url(url)
            if p.query:
                raise ValueError()
            _, canonical = self.adapter.seed_kind(url)
            return canonical
        except (ValueError, TypeError, AttributeError):
            raise CrawlStop('external_or_unsafe_url', url)

    def _resolve_public(self, hostname, deadline=None):
        try:
            if deadline is None:
                answer = self.resolver(hostname, 443, type=socket.SOCK_STREAM)
            else:
                # OS DNS calls cannot be killed safely. The daemon can only
                # return a DNS answer; it cannot access files or callbacks.
                resolver, outcome, done = self.resolver, [], threading.Event()
                def resolve():
                    try:
                        outcome.append((True, resolver(hostname, 443, type=socket.SOCK_STREAM)))
                    except Exception as error:
                        outcome.append((False, error))
                    finally:
                        done.set()
                threading.Thread(target=resolve, daemon=True, name='novel-dns-resolver').start()
                while True:
                    self._check_cancel(hostname)
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        raise TimeoutError('DNS deadline exceeded')
                    if done.wait(min(0.025, remaining)):
                        break
                success, answer = outcome[0]
                if not success:
                    raise answer
            addresses = list(dict.fromkeys(info[4][0] for info in answer))
        except OSError as error:
            raise CrawlStop('dns_error_stop', hostname) from error
        if not addresses:
            raise CrawlStop('dns_no_addresses', hostname)
        for address in addresses:
            try:
                ip = ipaddress.ip_address(address)
            except ValueError:
                raise CrawlStop('unsafe_dns_address', hostname)
            # Reject mixed public/private answers, not merely the selected address.
            if not ip.is_global or ip.is_multicast or ip.is_reserved or ip.is_unspecified:
                raise CrawlStop('unsafe_dns_address', hostname)
        return addresses[0]

    def _request(self, url, validators, kind, method='GET', data=None):
        self._check_cancel(url)
        if self.request_count >= self.max_requests:
            raise CrawlStop('request_budget_reached', url)
        self.gate.acquire(self.cancellation, self.robots.delay if self.robots else 0)
        connection = response = watchdog = None
        record = None
        deadline = time.monotonic() + self.timeout
        try:
            self._check_cancel(url)
            p = urlsplit(url)
            address = self._resolve_public(p.hostname, deadline=deadline)
            self.request_count += 1
            record = {'event': 'started', 'count': self.request_count, 'url': url,
                      'kind': kind, 'started_at': utcnow()}
            self.on_request(dict(record))
            headers = {'User-Agent': self.definition.user_agent,
                       'Accept': 'text/plain' if kind == 'robots' else 'text/html,application/xhtml+xml',
                       'Accept-Encoding': 'identity', 'Connection': 'close'}
            if validators and kind != 'robots':
                for key, header in (('etag', 'If-None-Match'), ('last_modified', 'If-Modified-Since')):
                    value = validators.get(key)
                    if value and isinstance(value, str) and len(value) <= 512 and '\r' not in value and '\n' not in value:
                        headers[header] = value
            self._check_cancel(url)
            if time.monotonic() >= deadline:
                raise TimeoutError('request deadline exceeded')
            connection = _PinnedHTTPSConnection(p.hostname, address, self.timeout)
            connection.deadline = deadline
            connection.timeout = max(0.001, deadline - time.monotonic())
            watchdog = _SocketWatchdog(connection, self.cancellation, deadline)
            if method == 'POST':
                headers['Content-Type'] = 'application/x-www-form-urlencoded'
            target = (p.path or '/') + ('?' + p.query if p.query else '')
            if data is None:
                connection.request(method, target, headers=headers)
            else:
                connection.request(method, target, body=data, headers=headers)
            watchdog.retained_socket = getattr(connection, 'sock', None)
            self._check_cancel(url)
            if time.monotonic() >= deadline:
                raise TimeoutError('request deadline exceeded')
            response = connection.getresponse()
            self._check_cancel(url)
            if time.monotonic() >= deadline:
                raise TimeoutError('request deadline exceeded')
            status = response.status
            record['status'] = status
            hs = response.headers
            retry = retry_after_seconds(hs.get('Retry-After'))
            if status in (403, 429):
                raise CrawlStop(f'http_{status}_access_stop', url, retry)
            if retry is not None:
                raise CrawlStop('retry_after_stop', url, retry)
            if status in (301, 302, 303, 307, 308):
                return status, hs, ''
            sent_conditional = 'If-None-Match' in headers or 'If-Modified-Since' in headers
            if status == 304 and sent_conditional and kind != 'robots':
                return status, hs, ''
            if status != 200:
                raise CrawlStop(f'http_{status}_stop', url, retry)
            allowed = ('text/plain',) if kind == 'robots' else ('text/html', 'application/xhtml+xml')
            if hs.get_content_type() not in allowed:
                raise CrawlStop('unexpected_content_type', url)
            if hs.get('Content-Encoding', 'identity').lower() not in ('', 'identity'):
                raise CrawlStop('unexpected_content_encoding', url)
            # read1 performs at most one socket read: check cancellation and a
            # whole-request deadline between chunks, rather than accepting an
            # endless slow trickle under a per-read inactivity timeout.
            chunks, total = [], 0
            while total <= self.max_response_bytes:
                self._check_cancel(url)
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError('response deadline exceeded')
                raw = getattr(getattr(response, 'fp', None), 'raw', None)
                sock = getattr(raw, '_sock', None)
                if sock is not None:
                    sock.settimeout(remaining)
                chunk = response.read1(min(65_536, self.max_response_bytes + 1 - total))
                self._check_cancel(url)
                if time.monotonic() >= deadline:
                    raise TimeoutError('request deadline exceeded')
                if not chunk:
                    break
                chunks.append(chunk)
                total += len(chunk)
            data = b''.join(chunks)
            record['response_bytes'] = len(data)
            if len(data) > self.max_response_bytes:
                raise CrawlStop('response_size_limit', url)
            try:
                html = data.decode(hs.get_content_charset() or 'utf-8')
            except (UnicodeError, LookupError) as error:
                raise CrawlStop('unsupported_or_invalid_encoding', url) from error
            if looks_like_challenge(html):
                raise CrawlStop('captcha_or_challenge_stop', url)
            self._check_cancel(url)
            return status, hs, html
        except (OSError, HTTPException) as error:
            self._check_cancel(url)
            raise CrawlStop('network_error_stop', url) from error
        finally:
            if watchdog is not None:
                watchdog.stop()
            if response is not None:
                response.close()
            if connection is not None:
                connection.close()
            self.gate.release()
            if record is not None:
                record.update(event='finished', finished_at=utcnow())
                self.on_request(dict(record))

    def _fetch(self, url, validators=None, robots=False, method='GET', data=None):
        url = self._validate(url, robots)
        for redirects in range(6):
            self._check_cancel(url)
            if not robots and (self.robots is None or not self.robots.allows(url)):
                raise CrawlStop('robots_denied_or_unavailable', url)
            if method == 'GET':
                status, headers, html = self._request(url, validators, 'robots' if robots else 'html')
            else:
                status, headers, html = self._request(url, validators, 'html', method=method, data=data)
            if status in (301, 302, 303, 307, 308):
                location = headers.get('Location')
                if not location or redirects == 5:
                    raise CrawlStop('redirect_limit_or_missing_location', url)
                url = self._validate(urljoin(url, location), robots)
                # A validator is only certified for the precise original resource.
                validators = None
                if status in (301, 302, 303):
                    method, data = 'GET', None
                continue
            if robots:
                if re.search(r'<(?:!doctype|html|head|body|title|form)\b', html, re.I):
                    raise CrawlStop('invalid_robots_html', url)
                substantive = '\n'.join(line.split('#', 1)[0].strip() for line in html.splitlines()).strip()
                if substantive and not re.search(r'^(?:user-agent|sitemap)\s*:', substantive, re.I | re.M):
                    raise CrawlStop('invalid_robots_content', url)
            etag = headers.get('ETag')
            modified = headers.get('Last-Modified')
            updated, source = source_date(html, modified)
            return FetchResult(html, url, status, etag, modified, updated, source)
        raise CrawlStop('redirect_limit', url)

    def load_robots(self):
        response = self._fetch(urljoin(self.definition.homepage, '/robots.txt'), robots=True)
        self.robots = Robots(response.html, self.definition.user_agent)
        if not math.isfinite(self.robots.delay) or self.robots.delay > 300:
            raise CrawlStop('robots_delay_requires_manual_review', response.final_url)

    def fetch(self, url, validators=None):
        self._check_cancel(url)
        if self.robots is None:
            self.load_robots()
        return self._fetch(url, validators)

    def fetch_form(self, url, fields):
        # Only the observed native-search form is allowed to submit a POST.
        request = getattr(self.adapter, 'request', None)
        if not request or request.get('method') != 'POST' or request.get('url') != url or request.get('fields') != fields:
            raise CrawlStop('unobserved_search_form', url)
        data = urlencode([tuple(pair) for pair in fields]).encode('utf-8')
        if len(data) > 65536:
            raise CrawlStop('search_form_size_limit', url)
        self._check_cancel(url)
        if self.robots is None:
            self.load_robots()
        return self._fetch(url, method='POST', data=data)

    def close(self):
        pass
