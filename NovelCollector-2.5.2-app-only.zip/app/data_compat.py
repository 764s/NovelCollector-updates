"""Data capabilities that constrain switching back to an older application."""
import json


def minimum_reader_version(db):
    """Inspect actual configurations and retained history without changing data.

    A configuration reset does not remove searches or reports that an old app
    would still try to deserialize. Keyword/name strings are not capabilities.
    The caller holds the manager lock and has stopped background writers.
    """
    def uses_fixed(value):
        if isinstance(value, list):
            return any(uses_fixed(item) for item in value)
        if not isinstance(value, dict):
            return False
        for name in ('strategies', 'specs'):
            specs = value.get(name)
            if isinstance(specs, list) and any(isinstance(s, dict) and s.get('id') == 'fixed_interval' for s in specs):
                return True
        return any(uses_fixed(item) for item in value.values() if isinstance(item, (dict, list)))

    for table, columns in (
            ('collections', ('config',)), ('jobs', ('config', 'state')), ('books', ('data',)),
            ('content_searches', ('binding', 'state')), ('discovery_evaluations', ('data',))):
        for row in db.execute(f'SELECT {",".join(columns)} FROM {table}'):
            if any(uses_fixed(json.loads(value)) for value in row):
                return '2.5.0'
    return None
