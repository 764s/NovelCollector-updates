from .shuku52 import Shuku52Adapter
ADAPTERS = {'52shuku': Shuku52Adapter}
