"""Anonymous public release transport and integrity checks; no network."""
import copy
import hashlib
import io
import json
import os
import subprocess
import unittest
from unittest.mock import patch
import zipfile

import github_updates as gh
from updater import UpdateError


def archive(version='2.2.1', raw_manifest=None):
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', zipfile.ZIP_DEFLATED) as bundle:
        bundle.writestr('manifest.json', json.dumps({'version': version}) if raw_manifest is None else raw_manifest)
        bundle.writestr('app/main.py', 'raise AssertionError("must not execute")\n')
    return stream.getvalue()


def release(version='2.2.1', data=None, digest=True):
    data = archive(version) if data is None else data
    return {'id': 123, 'tag_name': 'v' + version, 'draft': False, 'prerelease': False,
            'assets': [{'id': 456, 'name': 'NovelCollector-' + version + '-app-only.zip',
                        'size': len(data), 'state': 'uploaded',
                        'digest': 'sha256:' + hashlib.sha256(data).hexdigest() if digest else None}]}


def raw(value):
    return json.dumps(value).encode()


class GitHubUpdatesTests(unittest.TestCase):
    def setUp(self):
        self.client = gh.GitHubUpdates('2.2.0')

    def test_valid_check_returns_safe_metadata_only(self):
        value = release()
        value.update({'name': '\x1b[31msecret', 'body': 'secret release notes',
                      'html_url': 'https://evil.example/path?token=secret'})
        value['assets'][0]['browser_download_url'] = 'https://evil.example/secret'
        with patch.object(gh, '_api', return_value=raw(value)) as api:
            result = self.client.check()
        api.assert_called_once_with()
        self.assertTrue(result['ok'])
        self.assertEqual(result['status'], 'available')
        self.assertEqual(result['checksum_source'], 'github_digest')
        self.assertEqual(result['release_url'], gh.RELEASES_URL + '/tag/v2.2.1')
        self.assertNotIn('secret', json.dumps(result))
        self.assertNotIn('archive', result)
        self.assertNotIn('id', result)

    def test_newer_semantic_version_not_lexical(self):
        with patch.object(gh, '_api', return_value=raw(release('2.10.0'))):
            self.assertEqual(gh.GitHubUpdates('2.9.9').check()['status'], 'available')

    def test_current_and_older_versions_never_download(self):
        for version in ('2.2.0', '2.1.99'):
            value = release(version)
            value['assets'] = []
            for method in (self.client.check, self.client.download):
                with self.subTest(version=version, method=method.__name__):
                    with patch.object(gh, '_api', return_value=raw(value)) as api:
                        result = method()
                    self.assertEqual(result['status'], 'current')
                    self.assertNotIn('archive', result)
                    api.assert_called_once_with()

    def test_current_version_is_strict(self):
        for value in ('v2.2.0', '2.2', '02.2.0', '2.2.0-beta', '../version', None, True):
            with self.subTest(value=value), self.assertRaises(UpdateError):
                gh.GitHubUpdates(value)

    def test_anonymous_release_check_and_download_never_uses_cli_or_ambient_tokens(self):
        data = archive()
        with patch.dict(os.environ, {'GH_TOKEN': 'expired-secret', 'GITHUB_TOKEN': 'wrong-scope'}), \
                patch.object(gh, 'read_api', side_effect=[raw(release(data=data)), data]) as native, \
                patch('subprocess.Popen', side_effect=AssertionError('must not launch gh')) as process:
            result = self.client.download()
        self.assertEqual(result['status'], 'downloaded')
        self.assertEqual(result['archive'], data)
        self.assertEqual(native.call_count, 2)
        for call in native.call_args_list:
            self.assertEqual(call.args[0], '764s/NovelCollector-updates')
            self.assertNotIn('token', call.kwargs)
        process.assert_not_called()

    def test_unavailable_public_source_never_requests_authorization(self):
        for failure in ('auth_required', 'access_or_missing', 'access_denied', 'sso_required'):
            with self.subTest(failure=failure), patch.object(gh, 'read_api', side_effect=gh.ReleaseHTTPError(failure)) as network, \
                    patch('subprocess.Popen', side_effect=AssertionError('must not launch gh')):
                result = self.client.check()
            self.assertEqual(result['status'], 'release_unavailable')
            self.assertFalse(result['ok'])
            self.assertNotIn('requires_authorization', result)
            self.assertIn('无需登录', result['message'])
            network.assert_called_once()

    def test_network_failure_and_limits_are_not_current_or_authorization(self):
        for failure in ('network_error', 'timeout', 'rate_limited', 'response_too_large'):
            with self.subTest(failure=failure), patch.object(gh, 'read_api', side_effect=gh.ReleaseHTTPError(failure)):
                result = self.client.check()
            self.assertEqual(result['status'], failure)
            self.assertFalse(result['ok'])
            self.assertNotIn('requires_authorization', result)

    def test_client_has_no_credential_input(self):
        with self.assertRaises(TypeError):
            gh.GitHubUpdates('2.5.2', token='unused-secret')

    def test_rejects_malformed_json_duplicates_and_oversize(self):
        for value in (b'not json', b'{"draft":false,"draft":false}', b'null', b'[]', b'\xff',
                      b'[' * 2000 + b']' * 2000):
            with self.subTest(value=value[:30]), patch.object(gh, '_api', return_value=value):
                self.assertEqual(self.client.check()['status'], 'invalid_release')
        with patch.object(gh, '_api', return_value=b' ' * (gh.MAX_METADATA_BYTES + 1)):
            self.assertEqual(self.client.check()['status'], 'response_too_large')

    def test_rejects_nonstable_tags_and_flags(self):
        for tag in ('2.2.1', 'v02.2.1', 'v2.2.1-beta', 'v2.2.1+build', 'v2.2.1\n',
                    'v2.2.1/../../x', 'v2.2', 'V2.2.1', 'v9999999999.0.0', None, True):
            value = release()
            value['tag_name'] = tag
            with self.subTest(tag=tag), patch.object(gh, '_api', return_value=raw(value)):
                self.assertEqual(self.client.check()['status'], 'invalid_release')
        for field in ('draft', 'prerelease'):
            for flag in (True, 'false', 0, None):
                value = release()
                value[field] = flag
                with self.subTest(field=field, flag=flag), patch.object(gh, '_api', return_value=raw(value)):
                    self.assertEqual(self.client.check()['status'], 'invalid_release')

    def test_exact_asset_name_required(self):
        for name in ('NovelCollector-2.2.1-windows.zip', 'NovelCollector-2.2.1-app-only.zip.exe',
                     'novelcollector-2.2.1-app-only.zip', 'NovelCollector-2.2.0-app-only.zip'):
            value = release()
            value['assets'][0]['name'] = name
            with self.subTest(name=name), patch.object(gh, '_api', return_value=raw(value)):
                self.assertEqual(self.client.check()['status'], 'missing_asset')

    def test_asset_metadata_limits_and_types(self):
        for field, bad in [('id', True), ('id', -1), ('id', '456'), ('id', 1 << 63),
                           ('size', True), ('size', 0), ('size', -1), ('size', gh.MAX_ARCHIVE_BYTES + 1),
                           ('state', 'new')]:
            value = release()
            value['assets'][0][field] = bad
            with self.subTest(field=field, bad=bad), patch.object(gh, '_api', return_value=raw(value)):
                self.assertEqual(self.client.check()['status'], 'invalid_release')
        for assets in ({}, [None], [{'name': 123}], [{}], [{}] * (gh.MAX_ASSETS + 1)):
            value = release()
            value['assets'] = assets
            with self.subTest(assets=str(assets)[:50]), patch.object(gh, '_api', return_value=raw(value)):
                self.assertEqual(self.client.check()['status'], 'invalid_release')

    def test_duplicate_asset_rejected(self):
        value = release()
        value['assets'] *= 2
        with patch.object(gh, '_api', return_value=raw(value)):
            self.assertEqual(self.client.check()['status'], 'invalid_release')

    def test_missing_or_malformed_digest_fails_closed(self):
        value = release(digest=False)
        with patch.object(gh, '_api', return_value=raw(value)):
            self.assertEqual(self.client.check()['status'], 'missing_checksum')
        for digest in ('', 'sha256:' + '0' * 63, 'sha256:' + 'g' * 64, 'sha512:' + 'a' * 64, True):
            value['assets'][0]['digest'] = digest
            with self.subTest(digest=digest), patch.object(gh, '_api', return_value=raw(value)):
                self.assertEqual(self.client.check()['status'], 'invalid_checksum')

    def test_successful_download_rechecks_and_uses_asset_id(self):
        data = archive()
        with patch.object(gh, '_api', side_effect=[raw(release(data=data)), data]) as api:
            result = self.client.download()
        self.assertEqual(result['status'], 'downloaded')
        self.assertEqual(result['archive'], data)
        self.assertEqual(result['archive_sha256'], hashlib.sha256(data).hexdigest())
        self.assertEqual(api.call_args_list[0].args, ())
        self.assertEqual(api.call_args_list[1].args, (456,))
        self.assertEqual(api.call_args_list[1].kwargs,
                         {'limit': gh.MAX_ARCHIVE_BYTES, 'timeout': gh.DOWNLOAD_TIMEOUT})

    def test_download_rejects_changed_checksum_and_size(self):
        data = archive()
        for bad_data in (data[:-1], data + b'X', b'X' + data[1:], b''):
            with self.subTest(length=len(bad_data)), patch.object(gh, '_api', side_effect=[raw(release(data=data)), bad_data]):
                result = self.client.download()
                self.assertEqual(result['status'], 'checksum_mismatch')
                self.assertNotIn('archive', result)

    def test_download_rejects_wrong_manifest_version_and_nonzip(self):
        for data in (archive('2.3.0'), b'<html>not a ZIP</html>', archive(raw_manifest='not json'),
                     archive(raw_manifest='{"version":"2.2.1","version":"2.2.1"}'),
                     archive(raw_manifest='[]')):
            with self.subTest(data=data[:10]), patch.object(gh, '_api', side_effect=[raw(release(data=data)), data]):
                self.assertEqual(self.client.download()['status'], 'invalid_archive')

    def test_manifest_read_is_bounded(self):
        data = archive(raw_manifest='X' * (gh.MAX_MANIFEST_BYTES + 1))
        with patch.object(gh, '_api', side_effect=[raw(release(data=data)), data]):
            self.assertEqual(self.client.download()['status'], 'invalid_archive')

    def test_companion_checksum_success_and_exact_filename(self):
        data = archive()
        value = release(data=data, digest=False)
        name = value['assets'][0]['name']
        for separator in ('  ', ' *'):
            checksum = (hashlib.sha256(data).hexdigest().upper() + separator + name + '\r\n').encode()
            value['assets'].append({'id': 789, 'name': name + '.sha256', 'state': 'uploaded', 'size': len(checksum)})
            with patch.object(gh, '_api', side_effect=[raw(value), checksum, data]) as api:
                result = self.client.download()
            self.assertEqual(result['status'], 'downloaded')
            self.assertEqual(result['checksum_source'], 'companion_asset')
            self.assertEqual(api.call_args_list[1].args, (789,))
            value['assets'].pop()

    def test_companion_checksum_bad_content_prevents_zip_download(self):
        data = archive()
        for checksum in (b'bad', b'\xff', (hashlib.sha256(data).hexdigest() + '  wrong.zip\n').encode(),
                         (hashlib.sha256(data).hexdigest() + '  NovelCollector-2.2.1-app-only.zip\nother').encode()):
            value = release(data=data, digest=False)
            value['assets'].append({'id': 789, 'name': value['assets'][0]['name'] + '.sha256',
                                    'state': 'uploaded', 'size': len(checksum)})
            with patch.object(gh, '_api', side_effect=[raw(value), checksum]) as api:
                self.assertEqual(self.client.download()['status'], 'invalid_checksum')
                self.assertEqual(api.call_count, 2)

    def test_companion_checksum_size_duplicate_id_and_duplicate_name(self):
        value = release(digest=False)
        checksum = {'id': 789, 'name': value['assets'][0]['name'] + '.sha256', 'state': 'uploaded', 'size': 90}
        for assets in ([{**checksum, 'size': gh.MAX_CHECKSUM_BYTES + 1}],
                       [{**checksum, 'id': 456}], [checksum, checksum]):
            case = copy.deepcopy(value)
            case['assets'].extend(assets)
            with patch.object(gh, '_api', return_value=raw(case)):
                self.assertFalse(self.client.check()['ok'])

    def test_github_digest_takes_precedence_over_companion(self):
        value = release()
        value['assets'].append({'name': value['assets'][0]['name'] + '.sha256'})
        with patch.object(gh, '_api', return_value=raw(value)):
            self.assertEqual(self.client.check()['checksum_source'], 'github_digest')


if __name__ == '__main__':
    unittest.main()
