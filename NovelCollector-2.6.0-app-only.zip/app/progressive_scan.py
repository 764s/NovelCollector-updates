"""Durable breadth-first book acquisition and progressively denser content rounds."""
import json

from board_reader import BoardTransportAdapter
from content_search import encode
from novel_crawler.models import Book, CrawlStop, UnknownTemplate
from progressive import round_budget
from text_strategies import TextScheduler, summarize
from transport import PauseRequested, utcnow


class BatchedTransport:
    """Rotate bounded execution batches, retaining cumulative progress/rate gates.

    Only our own request-budget boundary starts another batch. Site refusals,
    challenges, network errors and cancellation propagate without retries.
    """
    def __init__(self, manager, job_id, state, adapter, cancellation):
        self.manager, self.job_id, self.state = manager, job_id, state
        self.adapter, self.cancellation = adapter, cancellation
        self.backend = self._create()

    def _event(self, record):
        self.state['batch_requests'] = record['count']
        self.state['request_count'] = self.state['request_offset'] + record['count']
        self.state['last_request'] = {**record, 'count': self.state['request_count']}
        self.manager._save_state(self.job_id, self.state)

    def _create(self):
        return self.manager.transport_factory(adapter=self.adapter, max_requests=160,
            request_count=self.state['batch_requests'], cancellation=self.cancellation, on_request=self._event)

    def _call(self, method, *args, **kwargs):
        try:
            return getattr(self.backend, method)(*args, **kwargs)
        except CrawlStop as error:
            if error.reason != 'request_budget_reached' or self.state['batch_requests'] < 160:
                raise
        self.backend.close()
        self.state.update(request_offset=self.state['request_count'], batch_requests=0,
                          request_batch=self.state['request_batch'] + 1)
        self.manager._save_state(self.job_id, self.state)
        self.backend = self._create()
        self.backend.load_robots()
        if method != 'load_robots':
            return getattr(self.backend, method)(*args, **kwargs)

    def fetch(self, *args, **kwargs):
        return self._call('fetch', *args, **kwargs)

    def fetch_form(self, *args, **kwargs):
        return self._call('fetch_form', *args, **kwargs)

    def load_robots(self):
        return self._call('load_robots')

    def close(self):
        self.backend.close()


def run_progressive(manager, job_id, cancellation):
    with manager.lock:
        row = manager._get_job(job_id)
        state, config, cid = manager._load_state(row), json.loads(row['config']), row['collection_id']
    adapter = BoardTransportAdapter(manager.adapter) if state.get('board_id') else manager.adapter
    transport = BatchedTransport(manager, job_id, state, adapter, cancellation)
    reader = manager.adapter.content_reader(transport, cancellation)
    if hasattr(reader, 'max_cached_sources'):
        reader.max_cached_sources = 16
    bootstrap = None
    active_directory = active_page = None

    def save():
        manager._save_state(job_id, state)

    def start_rounds():
        state['directories'] = list(dict.fromkeys(state['directories']))[:config['max_books']]
        state.update(stage='round', round_queue=list(state['directories']), round_cursor=0)
        save()

    def finish_book(scheduler, metadata, exhausted=False):
        url = state['current_book']['url']
        reason = scheduler.stop_reason()
        if not exhausted:
            scheduler.state['rounds_completed'] = scheduler.state['iteration']
        scheduler.state['scope_exhausted'] = exhausted or reason in ('scope_exhausted', 'sampling_pattern_exhausted')
        report = scheduler.report(job_id, row['revision'], 'completed', reason)
        metadata.update(strategy_run=report, content_seed=state['content_seed'], latest_job_id=job_id)
        state['round_scores'][url] = summarize(report, config['keywords'], row['revision'])['ranking_score']
        with manager.lock, manager.db:
            manager.content.save(url, scheduler.state, job_id, 'completed')
            manager.db.execute('INSERT OR REPLACE INTO books VALUES(?,?,?)',
                (cid, url, encode(manager._book_record(url, metadata))))
            manager.boards.remember(url, config, manager._book_record(url, metadata))
            state.update(stage='round', round_cursor=state['round_cursor'] + 1, current_url=None)
            if state['round_index'] == 1:
                state['books_done'] += 1
            state.pop('text_plan', None)
            save()
        reader.clear()

    def reuse_fragment(book, scheduler):
        pending = scheduler.state['pending']
        # Without prose, joining adjacent fragments cannot recount boundary words.
        # Reuse a source's first exact observation; other cases retain normal reads.
        if pending['start'] is None or any(r['url'] == pending['url'] for r in scheduler.state['evidence']):
            return False
        page = manager.content.source(book.url, pending['url'])
        if not page or page['body_hash'] != scheduler.state['hashes'].get(pending['url']):
            return False
        fact = manager.content.reusable(book.url, pending, page['body_hash'], config['keywords'], scheduler.state['focus_terms'])
        if not fact:
            return False
        save()
        evidence = scheduler.observe_shared(fact, None, config['keywords'], utcnow())
        state['matched_chars'] += evidence['body_chars']
        state['shared_reused_chars'] += evidence['body_chars']
        metadata = manager._book_data(cid, book.url)
        metadata.update(strategy_run=scheduler.report(job_id, row['revision']), latest_job_id=job_id)
        with manager.lock, manager.db:
            manager.db.execute('INSERT OR REPLACE INTO pages VALUES(?,?,?,?)', (cid, book.url, pending['url'], encode(page)))
            manager.db.execute('INSERT OR REPLACE INTO books VALUES(?,?,?)', (cid, book.url, encode(manager._book_record(book.url, metadata))))
            save()
        return True

    try:
        transport.load_robots()
        while True:
            if cancellation.is_set():
                raise PauseRequested()
            stage = state['stage']
            if stage == 'discover':
                with manager.lock:
                    search = manager.boards.search(state['board_id'])
                    version = manager.boards.version(search['state']['version_id'])
                # A replacement list must actually be observed, even when the
                # retained candidate pool already meets its target.
                observed = version['state']['count'] or version['state']['exhausted']
                if len(state['directories']) >= config['max_books'] and observed:
                    state['discovery_stop'] = 'book_budget_reached'
                    start_rounds()
                    continue
                with manager.lock, manager.db:
                    entry = manager.boards.next_entry(state['board_id'])
                    if entry:
                        url = entry['directory_url']
                        manager._link_discovered_book(cid, url, config, entry, job_id)
                        manager.boards.complete(state['board_id'])
                        if url not in state['directories']:
                            state['directories'].append(url)
                    save()
                if entry:
                    continue
                if version['state'].get('cycle'):
                    raise CrawlStop('board_pagination_cycle', config['start_url'])
                if version['state']['exhausted']:
                    state['discovery_stop'] = 'board_exhausted'
                    start_rounds()
                    continue
                board_reader = manager.adapter.board_reader(config['board'])
                request = version['state']['request'] or board_reader.initial()
                state['current_url'] = request['url']
                save()
                response = board_reader.fetch(transport, request)
                books, following, cursor = board_reader.read(response.html, response.final_url, version['state']['reader'])
                if cancellation.is_set():
                    raise PauseRequested()
                with manager.lock, manager.db:
                    manager.boards.observe(state['board_id'], request, cursor, books, following, response.final_url)
                    save()
            elif stage == 'seed':
                kind, url = state['seed_kind'], state['seed_url']
                if kind == 'directory':
                    state['directories'] = [url]
                else:
                    response = transport.fetch(url)
                    if kind == 'body':
                        state['body_attempts'] += 1
                        state['directories'] = [manager.adapter.directory_from_body(response.html, response.final_url)]
                        bootstrap = response
                    else:
                        if kind == 'homepage':
                            category = manager.adapter.category_url(response.html, response.final_url)
                            response = transport.fetch(category)
                        state['directories'] = manager.adapter.book_links(response.html, response.final_url)
                start_rounds()
            elif stage == 'round':
                if state['round_cursor'] >= len(state['round_queue']):
                    if state['round_index'] >= config['progressive']['rounds'] or not state['directories']:
                        manager._finish(job_id, 'completed')
                        return
                    state['round_index'] += 1
                    state['round_cursor'] = 0
                    state['round_queue'] = sorted(state['directories'], key=lambda url:
                        -(state['round_scores'].get(url) if state['round_scores'].get(url) is not None else -1))
                    save()
                    continue
                url = state['round_queue'][state['round_cursor']]
                active_directory, active_page = url, None
                state['current_url'] = url
                save()
                metadata = manager._book_data(cid, url) or {'directory_url': url, 'title': '', 'body_urls': [], 'snippets': []}
                metadata.pop('evaluation_ref', None)
                metadata.pop('discovery_reused', None)
                known = manager.content.context(url)
                if known and known.get('body_urls'):
                    book = Book(url, known['title'], tuple(known['body_urls']))
                    state['reused_directories'] += 1
                else:
                    response = transport.fetch(url)
                    book = manager.adapter.directory(response.html, response.final_url)
                    if book.url != url:
                        raise CrawlStop('directory_redirect_changed_identity', url)
                    metadata.update(checked_at=utcnow(), source_updated_at=response.source_updated_at,
                                    source_date_kind=getattr(response, 'source_date_kind', None))
                metadata.update(title=book.title, body_urls=list(book.body_urls), last_attempt_status='success')
                sources = list(book.body_urls)
                start_body = state.get('seed_body_url')
                if start_body:
                    if start_body not in sources:
                        raise UnknownTemplate('body seed is absent from the observed book directory')
                    sources = sources[sources.index(start_body):]
                with manager.lock, manager.db:
                    prior = manager.content.get(url, state['content_seed'])
                    manager.content.check(prior, config, start_body, job_id)
                    packed = json.loads(prior['state']) if prior else {}
                    state['current_book'] = {'url': url, 'title': book.title, 'body_urls': list(book.body_urls)}
                    if packed.get('scope_exhausted'):
                        finish_book(TextScheduler(manager.content.unpack(packed)), metadata, exhausted=True)
                        continue
                    effective = {**config, 'chars_per_book': round_budget(config, packed.get('iteration', 0) + 1)}
                    scheduler = manager.content.open(url, state['content_seed'], sources, effective, start_body, job_id,
                                                     advance=True, resume_incomplete=True)
                    state.update(stage='body', text_plan=scheduler.state)
                    metadata.update(content_seed=state['content_seed'], latest_job_id=job_id,
                                    strategy_run=scheduler.report(job_id, row['revision']))
                    manager.content.put_context(url, metadata)
                    manager.db.execute('INSERT OR REPLACE INTO books VALUES(?,?,?)',
                        (cid, url, encode(manager._book_record(url, metadata))))
                    save()
            elif stage == 'body':
                info = state['current_book']
                book = Book(info['url'], info['title'], tuple(info['body_urls']))
                active_directory = book.url
                scheduler = TextScheduler(state['text_plan'])
                pending = scheduler.next()
                if pending is None:
                    finish_book(scheduler, manager._book_data(cid, book.url))
                    active_directory = active_page = None
                    continue
                active_page = pending['url']
                if not reuse_fragment(book, scheduler):
                    if manager._text_step(job_id, row['revision'], cid, config, state, book, scheduler, reader, bootstrap):
                        bootstrap = None
                active_page = None
            else:
                raise ValueError('Unknown progressive stage')
    except PauseRequested:
        manager._mark_failed_attempt(cid, active_directory, active_page, 'paused')
        manager._finish(job_id, 'paused')
    except (CrawlStop, UnknownTemplate, ValueError) as error:
        reason = error.reason if isinstance(error, CrawlStop) else ('unknown_template' if isinstance(error, UnknownTemplate) else 'content_seed_conflict')
        manager._mark_failed_attempt(cid, active_directory, active_page, reason)
        manager._finish(job_id, 'paused' if reason in ('network_error_stop', 'dns_error_stop') else 'stopped', reason)
    except Exception as error:
        manager._finish(job_id, 'failed', 'internal_error: ' + type(error).__name__)
    finally:
        transport.close()
