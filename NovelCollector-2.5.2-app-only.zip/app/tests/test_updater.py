"""Offline update validation, immutable promotion and atomic rollback tests."""
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tempfile
import unittest
from unittest.mock import patch
import warnings
import zipfile

from updater import Updater, UpdateError, RUNTIME, resolve_active_release, _rename_absent


PLATFORM = 'linux-x64'


def archive(version='2.1.1', files=None, overrides=None, extras=None, manifest_raw=None):
    files = {'app/main.py': b'raise RuntimeError("must not execute during update")\n',
             'app/static/index.html': b'<p>update</p>'} if files is None else files
    manifest = {'schema': 1, 'version': version, 'runtime': RUNTIME, 'data_format': 1,
                'platforms': [PLATFORM, 'windows-x64'],
                'files': {name: hashlib.sha256(data).hexdigest() for name, data in files.items()}}
    manifest.update(overrides or {})
    output = io.BytesIO()
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', UserWarning)
        with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as bundle:
            bundle.writestr('manifest.json', manifest_raw if manifest_raw is not None else json.dumps(manifest))
            for name, data in files.items():
                bundle.writestr(name, data)
            for name, data in extras or []:
                bundle.writestr(name, data)
    return output.getvalue()


class UpdaterTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='update 中文 ')
        self.home = Path(self.temp.name)
        baseline = self.home / 'releases/2.1.0/app'
        baseline.mkdir(parents=True)
        (baseline / 'main.py').write_text('VERSION = "2.1.0"\n')
        (self.home / 'app').mkdir()
        (self.home / 'app/main.py').write_text('# permanent bootstrap\n')
        (self.home / 'runtime').mkdir()
        (self.home / 'runtime/python.exe').write_bytes(b'UNCHANGED RUNTIME')
        (self.home / 'data').mkdir()
        (self.home / 'data/library.sqlite3').write_bytes(b'UNCHANGED DATA')
        (self.home / 'runtime-compat.json').write_text(json.dumps(
            {'schema': 1, 'runtime': RUNTIME, 'data_format': 1, 'platform': PLATFORM}))
        self.initial = {'schema': 1, 'version': '2.1.0', 'path': 'releases/2.1.0/app', 'previous': None}
        self.pointer = self.home / 'active-release.json'
        self.pointer.write_text(json.dumps(self.initial))
        self.updater = Updater(self.home, '2.1.0', platform=PLATFORM)

    def tearDown(self):
        self.temp.cleanup()

    def assert_rejected(self, raw):
        with self.assertRaises(UpdateError):
            self.updater.inspect(raw)
        self.assertEqual(json.loads(self.pointer.read_text()), self.initial)

    def test_inspect_is_read_only_and_does_not_execute(self):
        snapshot = {p.relative_to(self.home).as_posix(): p.read_bytes()
                    for p in self.home.rglob('*') if p.is_file()}
        marker = self.home / 'must-not-execute'
        raw = archive(files={'app/main.py': f'open({str(marker)!r}, "w").write("executed")'.encode()})
        preview = self.updater.inspect(raw)
        self.assertFalse(preview['publisher_verified'])
        self.assertEqual(preview['file_count'], 1)
        self.assertEqual(preview['archive_sha256'], hashlib.sha256(raw).hexdigest())
        self.assertEqual(snapshot, {p.relative_to(self.home).as_posix(): p.read_bytes()
                                  for p in self.home.rglob('*') if p.is_file()})
        self.assertFalse(marker.exists())

    def test_stage_install_and_rollback_preserve_bootstrap_runtime_and_data(self):
        protected = [self.home / p for p in ('app/main.py', 'runtime/python.exe',
                                             'data/library.sqlite3', 'releases/2.1.0/app/main.py')]
        originals = {p: p.read_bytes() for p in protected}
        staged = self.updater.stage(archive())
        self.assertEqual(json.loads(self.pointer.read_text()), self.initial)
        self.assertFalse((self.home / 'releases/2.1.1').exists())
        result = self.updater.install(staged['stage_id'])
        self.assertTrue(result['restart_required'])
        self.assertEqual(result['version'], '2.1.1')
        self.assertEqual(json.loads(self.pointer.read_text())['previous'],
                         {'version': '2.1.0', 'path': 'releases/2.1.0/app'})
        self.assertEqual(resolve_active_release(self.home, '2.1.0'), self.home / 'releases/2.1.1/app')
        self.assertTrue(self.updater.status()['pending_restart'])
        self.assertTrue(self.updater.status()['can_rollback'])
        result = self.updater.rollback()
        self.assertFalse(result['data_restored'])
        self.assertEqual(result['version'], '2.1.0')
        self.assertEqual(resolve_active_release(self.home, '2.1.0'), self.home / 'releases/2.1.0/app')
        self.assertEqual(originals, {p: p.read_bytes() for p in protected})
        self.assertTrue((self.home / 'releases/2.1.1/app/main.py').exists())
        # Rollback is reversible; already installed update manifest rechecked.
        self.assertEqual(self.updater.rollback()['version'], '2.1.1')

    def test_no_previous_release(self):
        self.assertFalse(self.updater.status()['can_rollback'])
        with self.assertRaises(UpdateError):
            self.updater.rollback()

    def test_data_minimum_blocks_rollback_before_pointer_change(self):
        staged = self.updater.stage(archive())
        self.updater.install(staged['stage_id'])
        before = self.pointer.read_bytes()
        with self.assertRaisesRegex(UpdateError, '当前数据'):
            self.updater.rollback(minimum_version='2.5.0')
        self.assertEqual(self.pointer.read_bytes(), before)
        self.assertEqual((self.home / 'data/library.sqlite3').read_bytes(), b'UNCHANGED DATA')

    def test_data_minimum_allows_a_compatible_predecessor(self):
        staged = self.updater.stage(archive())
        self.updater.install(staged['stage_id'])
        self.assertEqual(self.updater.rollback(minimum_version='2.1.0')['version'], '2.1.0')

    def test_pointer_absent_only_uses_existing_versioned_baseline(self):
        self.pointer.unlink()
        self.assertEqual(resolve_active_release(self.home, '2.1.0'), self.home / 'releases/2.1.0/app')
        with self.assertRaises(UpdateError):
            resolve_active_release(self.home, '2.0.0')

    def test_version_runtime_platform_and_schema_compatibility(self):
        cases = [{'version': '2.1.0'}, {'version': '2.0.99'}, {'version': '2.1.1-beta'},
                 {'version': '../x'}, {'version': '02.1.1'}, {'version': '2.1.1.0'},
                 {'schema': 2}, {'schema': True}, {'runtime': 'cpython314'},
                 {'data_format': 2}, {'data_format': True}, {'platforms': ['windows-x64']},
                 {'platforms': ['linux-x64', 'linux-x64']}, {'platforms': ['linux-arm64']},
                 {'platforms': 'linux-x64'}, {'unexpected': 'field'}]
        for value in cases:
            with self.subTest(value=value):
                self.assert_rejected(archive(overrides=value))
        self.assertEqual(self.updater.inspect(archive(version='2.10.0'))['version'], '2.10.0')

    def test_manifest_requires_exact_files_and_valid_hashes(self):
        for raw in [archive(extras=[('app/hidden.py', b'evil')]),
                    archive(overrides={'files': {'app/main.py': '0' * 64}}),
                    archive(overrides={'files': {'app/main.py': 'x' * 64}}),
                    archive(files={'app/static/test.txt': b'missing main'}),
                    archive(overrides={'files': {}})]:
            self.assert_rejected(raw)
        raw = archive()
        with zipfile.ZipFile(io.BytesIO(raw)) as bundle:
            metadata = json.loads(bundle.read('manifest.json'))
        metadata['files']['app/missing.py'] = '0' * 64
        self.assert_rejected(archive(overrides={'files': metadata['files']}))

    def test_duplicate_json_fields_rejected(self):
        self.assert_rejected(archive(manifest_raw=b'{"schema":1,"schema":1}'))
        self.pointer.write_text('{"schema":1,"schema":1}')
        with self.assertRaises(UpdateError):
            self.updater.status()

    def test_duplicate_zip_names_casefold_and_file_directory_conflicts(self):
        self.assert_rejected(archive(extras=[('app/main.py', b'duplicate')]))
        self.assert_rejected(archive(files={'app/main.py': b'a', 'app/MAIN.py': b'b'}))
        self.assert_rejected(archive(files={'app/main.py': b'a', 'app/foo': b'b', 'app/foo/bar': b'c'}))
        self.assert_rejected(archive(extras=[('app/MAIN.py', b'duplicate')]))

    def test_unsafe_and_windows_reserved_paths_rejected(self):
        bad = ['../evil.py', '/app/evil.py', 'C:/app/evil.py', 'app/../evil.py',
               'app//evil.py', 'app/./evil.py', 'app\\evil.py', '//server/evil',
               'runtime/evil.py', 'active-release.json', 'app/CON.py', 'app/nul',
               'app/COM1.txt', 'app/lpt9.txt', 'app/a.', 'app/a ', 'app/a:b',
               'app/file:stream', 'app/évil.py', 'app/.hidden', 'app/foo\x00evil',
               'app/main.pyc', 'app/evil.exe', 'app/evil.dll', 'app/evil.pyd',
               'app/__pycache__/evil.py', 'app/' + 'a' * 101]
        for name in bad:
            with self.subTest(name=name):
                self.assert_rejected(archive(files={'app/main.py': b'a', name: b'b'}))

    def test_zip_symlinks_and_special_files_rejected(self):
        for mode in (stat.S_IFLNK | 0o777, stat.S_IFIFO | 0o600, stat.S_IFCHR | 0o600):
            info = zipfile.ZipInfo('app/evil')
            info.create_system = 3
            info.external_attr = mode << 16
            self.assert_rejected(archive(extras=[(info, b'/tmp/target')]))

    def test_only_required_directory_entries_are_allowed(self):
        preview = self.updater.inspect(archive(extras=[('app/', b''), ('app/static/', b'')]))
        self.assertEqual(preview['file_count'], 2)
        self.assert_rejected(archive(extras=[('app/empty/', b'')]))

    def test_truncated_and_non_zip_archives_rejected(self):
        for raw in (b'', b'not zip', archive()[:-30], bytearray(archive()), None):
            self.assert_rejected(raw)

    def test_size_and_file_count_limits(self):
        with patch('updater.MAX_ARCHIVE_BYTES', 20):
            self.assert_rejected(archive())
        with patch('updater.MAX_UNPACKED_BYTES', 100):
            self.assert_rejected(archive(files={'app/main.py': b'x' * 101}))
            self.assert_rejected(archive(files={'app/main.py': b'x' * 70, 'app/other.py': b'y' * 70}))
        with patch('updater.MAX_MANIFEST_BYTES', 10):
            self.assert_rejected(archive())
        files = {'app/main.py': b'base', **{'app/f' + str(n): b'x' for n in range(100)}}
        self.assert_rejected(archive(files=files))

    def test_stage_tampering_missing_or_extra_files_cannot_commit(self):
        for action in ('modify', 'missing', 'extra', 'manifest'):
            with self.subTest(action=action):
                staged = self.updater.stage(archive())
                root = self.home / '.update-staging' / staged['stage_id']
                if action == 'modify':
                    (root / 'app/main.py').write_bytes(b'changed')
                elif action == 'missing':
                    (root / 'app/main.py').unlink()
                elif action == 'extra':
                    (root / 'app/extra.py').write_bytes(b'extra')
                else:
                    value = json.loads((root / 'manifest.json').read_text())
                    (root / 'app/main.py').write_bytes(b'changed')
                    value['files']['app/main.py'] = hashlib.sha256(b'changed').hexdigest()
                    (root / 'manifest.json').write_text(json.dumps(value))
                with self.assertRaises(UpdateError):
                    self.updater.install(staged['stage_id'])
                self.assertEqual(json.loads(self.pointer.read_text()), self.initial)
                self.updater.discard(staged['stage_id'])

    @unittest.skipUnless(hasattr(os, 'symlink'), 'requires symlinks')
    def test_stage_symlink_and_directory_symlink_rejected(self):
        staged = self.updater.stage(archive())
        root = self.home / '.update-staging' / staged['stage_id']
        target = root / 'app/main.py'
        target.unlink()
        target.symlink_to(self.home / 'releases/2.1.0/app/main.py')
        with self.assertRaises(UpdateError):
            self.updater.install(staged['stage_id'])
        self.assertEqual(json.loads(self.pointer.read_text()), self.initial)
        self.updater.discard(staged['stage_id'])
        (self.home / '.update-staging').rmdir()
        outside = self.home / 'other'
        outside.mkdir()
        (self.home / '.update-staging').symlink_to(outside, target_is_directory=True)
        with self.assertRaises(UpdateError):
            self.updater.stage(archive())
        self.assertEqual(list(outside.iterdir()), [])

    @unittest.skipUnless(hasattr(os, 'symlink'), 'requires symlinks')
    def test_pointer_and_release_symlink_rejected(self):
        self.pointer.unlink()
        outside = self.home / 'other.json'
        outside.write_text(json.dumps(self.initial))
        self.pointer.symlink_to(outside)
        with self.assertRaises(UpdateError):
            self.updater.status()
        self.pointer.unlink()
        self.pointer.write_text(json.dumps(self.initial))
        baseline = self.home / 'releases/2.1.0/app/main.py'
        baseline.unlink()
        baseline.symlink_to(self.home / 'app/main.py')
        with self.assertRaises(UpdateError):
            resolve_active_release(self.home, '2.1.0')

    @unittest.skipUnless(hasattr(os, 'link'), 'requires hard links')
    def test_staged_hardlink_cannot_bind_release_to_mutable_external_file(self):
        staged = self.updater.stage(archive())
        root = self.home / '.update-staging' / staged['stage_id']
        original = root / 'app/main.py'
        outside = self.home / 'mutable-file'
        outside.write_bytes(original.read_bytes())
        original.unlink()
        os.link(outside, original)
        with self.assertRaises(UpdateError):
            self.updater.install(staged['stage_id'])
        self.assertEqual(json.loads(self.pointer.read_text()), self.initial)

    def test_pointer_path_cannot_leave_release_or_target_bootstrap(self):
        for path in ('app', '../outside', '/tmp/evil', 'releases/2.1.0/../2.1.0/app',
                     'releases/2.0.0/app', 'releases\\2.1.0\\app'):
            with self.subTest(path=path):
                self.pointer.write_text(json.dumps({**self.initial, 'path': path}))
                with self.assertRaises(UpdateError):
                    resolve_active_release(self.home, '2.1.0')

    def test_stale_preview_and_unknown_stage_rejected(self):
        first = self.updater.stage(archive())
        second = self.updater.stage(archive(version='2.1.2'))
        self.updater.install(first['stage_id'])
        with self.assertRaises(UpdateError):
            self.updater.install(second['stage_id'])
        for token in (first['stage_id'], '../bad', 'f' * 32, None):
            with self.subTest(token=token):
                with self.assertRaises(UpdateError):
                    self.updater.install(token)
        restarted = Updater(self.home, '2.1.1', platform=PLATFORM)
        with self.assertRaises(UpdateError):
            restarted.install(second['stage_id'])

    def test_pointer_replacement_failure_keeps_old_version_and_retry_recovers(self):
        staged = self.updater.stage(archive())
        with patch('updater.os.replace', side_effect=PermissionError('locked pointer')):
            with self.assertRaises(PermissionError):
                self.updater.install(staged['stage_id'])
        self.assertEqual(json.loads(self.pointer.read_text()), self.initial)
        self.assertEqual(resolve_active_release(self.home, '2.1.0'), self.home / 'releases/2.1.0/app')
        self.assertFalse(list(self.home.glob('.active-release-*.tmp')))
        self.assertEqual(self.updater.install(staged['stage_id'])['version'], '2.1.1')

    def test_new_process_recovers_identical_orphan_without_overwrite(self):
        staged = self.updater.stage(archive())
        with patch('updater.os.replace', side_effect=PermissionError('interrupted')):
            with self.assertRaises(PermissionError):
                self.updater.install(staged['stage_id'])
        release = self.home / 'releases/2.1.1'
        identity = (release / 'app/main.py').stat().st_ino
        restarted = Updater(self.home, '2.1.0', platform=PLATFORM)
        preview = restarted.stage(archive())
        self.assertEqual(restarted.install(preview['stage_id'])['version'], '2.1.1')
        self.assertEqual((release / 'app/main.py').stat().st_ino, identity)
        self.assertFalse((self.home / '.update-staging' / preview['stage_id']).exists())

    def test_competing_empty_release_directory_never_replaced(self):
        staged = self.updater.stage(archive())
        target = self.home / 'releases/2.1.1'
        def competing_rename(source, destination):
            destination.mkdir()
            return _rename_absent(source, destination)
        with patch('updater._rename_absent', side_effect=competing_rename):
            with self.assertRaises(FileExistsError):
                self.updater.install(staged['stage_id'])
        self.assertEqual(list(target.iterdir()), [])
        self.assertEqual(json.loads(self.pointer.read_text()), self.initial)
        self.assertTrue((self.home / '.update-staging' / staged['stage_id'] / 'app/main.py').is_file())

    def test_process_wide_update_lock_rejects_second_updater(self):
        another = Updater(self.home, '2.1.0', platform=PLATFORM)
        with self.updater._transaction():
            with self.assertRaises(UpdateError):
                another.stage(archive())

    def test_existing_release_never_overwritten(self):
        existing = self.home / 'releases/2.1.1/app'
        existing.mkdir(parents=True)
        (existing / 'main.py').write_bytes(b'old immutable code')
        staged = self.updater.stage(archive())
        with self.assertRaises(UpdateError):
            self.updater.install(staged['stage_id'])
        self.assertEqual((existing / 'main.py').read_bytes(), b'old immutable code')
        self.assertEqual(json.loads(self.pointer.read_text()), self.initial)

    def test_rollback_rechecks_update_integrity(self):
        staged = self.updater.stage(archive())
        self.updater.install(staged['stage_id'])
        self.updater.rollback()
        (self.home / 'releases/2.1.1/app/main.py').write_bytes(b'corrupt')
        with self.assertRaises(UpdateError):
            self.updater.rollback()
        self.assertEqual(json.loads(self.pointer.read_text())['version'], '2.1.0')

    def test_preview_limit_and_discard(self):
        stages = [self.updater.stage(archive()) for _ in range(3)]
        with self.assertRaises(UpdateError):
            self.updater.stage(archive())
        self.updater.discard(stages[0]['stage_id'])
        self.assertFalse((self.home / '.update-staging' / stages[0]['stage_id']).exists())
        self.assertIn('stage_id', self.updater.stage(archive()))

    def test_runtime_compat_metadata_cannot_override_declared_platform(self):
        compatibility = self.home / 'runtime-compat.json'
        value = json.loads(compatibility.read_text())
        value['runtime'] = 'cpython-3.15.0'
        compatibility.write_text(json.dumps(value))
        with self.assertRaises(UpdateError):
            Updater(self.home, '2.1.0', platform=PLATFORM)


if __name__ == '__main__':
    unittest.main()


class MinimumUpdaterTests(unittest.TestCase):
    def test_minimum_updater_is_enforced(self):
        with tempfile.TemporaryDirectory() as directory:
            home = Path(directory)
            (home/'releases'/'2.2.0'/'app').mkdir(parents=True)
            (home/'releases'/'2.2.0'/'app'/'main.py').write_text('pass')
            updater = Updater(home, '2.2.0', platform=PLATFORM)
            self.assertEqual(updater.inspect(archive(version='2.2.1', overrides={'minimum_updater':'2.2.0'}))['version'], '2.2.1')
            with self.assertRaises(UpdateError):
                updater.inspect(archive(version='2.2.1', overrides={'minimum_updater':'2.3.0'}))
            with self.assertRaises(UpdateError):
                updater.inspect(archive(version='2.2.1', overrides={'minimum_updater':'bad'}))
