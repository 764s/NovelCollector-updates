"""Offline fixtures only. Run: python -m unittest discover -s tests -v."""
import json
from email.message import Message
from pathlib import Path
import socket
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core import Manager, validate_config
from transport import SafeTransport, FetchResult, RateGate, PauseRequested, source_date
from novel_crawler.models import CrawlStop
from novel_crawler.http import Robots

HOME = 'https://www.52shuku.net/'
DIRECTORY = HOME + 'wuxia/abc.html'
PAGE1 = HOME + 'wuxia/abc_1.html'
PAGE2 = HOME + 'wuxia/abc_2.html'


def directory(urls=(PAGE1,), title='Example'):
    links = ''.join(f'<li class="mulu"><a href="{url}">正文</a></li>' for url in urls)
    return f'<h1>{title}</h1><article class="article-content"><p>小说简介：</p><p>Ignored 修仙 metadata</p><ul>{links}</ul></article>'


def body(text='修仙修仙 aa aaa', first=True):
    chapter = '<p>Author 修仙 intro</p><p>第一章 开始</p>' if first else ''
    return f'<h1>Ignored 修仙 title</h1><article class="article-content">{chapter}<p>{text}</p><div class="pagination2"><a href="{DIRECTORY}">目录</a></div></article><footer>修仙</footer>'


def response(url, html='', status=200, etag=None, modified=None):
    return FetchResult(html, url, status, etag, modified, source_date(html, modified)[0])


class ScriptedTransport:
    """Per-factory fixtures and count callbacks; never creates a socket."""
    def __init__(self, factory, **kwargs):
        self.factory = factory
        self.count = kwargs.get('request_count', 0)
        self.callback = kwargs['on_request']
        self.cancel = kwargs['cancellation']

    def bump(self, url):
        self.count += 1
        self.callback({'event': 'started', 'count': self.count, 'url': url, 'kind': 'html'})

    def load_robots(self):
        self.bump(HOME + 'robots.txt')

    def fetch(self, url, validators=None):
        self.bump(url)
        self.factory.calls.append((url, validators))
        answer = self.factory.script.pop(0)
        if isinstance(answer, Exception):
            raise answer
        if callable(answer):
            return answer(self, url, validators)
        if answer.final_url != url:
            raise AssertionError(f'Unexpected URL {url}; expected {answer.final_url}')
        return answer

    def close(self):
        pass


class Factory:
    def __init__(self):
        self.script, self.calls = [], []

    def __call__(self, **kwargs):
        return ScriptedTransport(self, **kwargs)


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.factory = Factory()
        self.manager = Manager(self.tmp.name, transport_factory=self.factory, auto_start=False)
        self.collection = self.manager.create_collection({'name': 'Fixture', 'start_url': DIRECTORY,
            'keywords': [{'term': '修仙', 'weight': 2}, {'term': 'aa', 'weight': 0.5}], 'max_books': 1, 'pages_per_book': 2})

    def tearDown(self):
        self.manager.close()
        self.tmp.cleanup()

    def scan(self, script):
        self.factory.script = list(script)
        job = self.manager.start_scan(self.collection['id'])
        self.manager._run_job(job['id'])
        self.assertEqual(self.factory.script, [])
        return self.manager.snapshot()

    def first_scan(self, **kwargs):
        return self.scan([response(DIRECTORY, directory()), response(PAGE1, body(), **kwargs)])

    def test_literal_weighted_counts_no_metadata_or_fulltext(self):
        snapshot = self.first_scan(etag='"one"')
        row = snapshot['results'][0]
        self.assertEqual(row['counts'], {'修仙': 2, 'aa': 2})
        self.assertEqual(row['score'], 5)
        self.assertEqual(row['matching_pages'], 1)
        self.assertEqual(row['scanned_pages'], 1)
        self.assertEqual(snapshot['jobs'][0]['status'], 'completed')
        self.assertEqual(snapshot['jobs'][0]['progress']['request_count'], 3)
        self.assertLessEqual(len(row['snippets']), 2)
        self.assertTrue(all(len(snippet) <= 32 for snippet in row['snippets']))
        persisted = self.manager.db.execute('SELECT data FROM pages').fetchone()[0]
        self.assertNotIn('<article', persisted)
        self.assertNotIn('text', json.loads(persisted))
        self.assertNotIn('html', json.loads(persisted))

    def test_persistence_reweight_and_subset_reuse(self):
        self.first_scan(etag='"one"')
        cid = self.collection['id']
        self.manager.update_collection(cid, {'keywords': [{'term': '修仙', 'weight': 10}]})
        self.assertEqual(self.manager.snapshot()['results'][0]['score'], 20)
        snapshot = self.scan([response(DIRECTORY, directory()), response(PAGE1, status=304)])
        self.assertEqual(self.factory.calls[-1][1], {'etag': '"one"', 'last_modified': None})
        self.assertEqual(snapshot['results'][0]['score'], 20)
        self.assertEqual(snapshot['jobs'][0]['progress']['reused_304'], 1)
        self.manager.close()
        self.manager = Manager(self.tmp.name, transport_factory=self.factory, auto_start=False)
        self.assertEqual(self.manager.snapshot()['results'][0]['score'], 20)

    def test_new_terms_are_unknown_until_recounted_not_zeros(self):
        self.first_scan(etag='"one"')
        self.manager.update_collection(self.collection['id'], {'keywords': [{'term': '修仙', 'weight': 2}, {'term': 'aaa', 'weight': 9}]})
        row = self.manager.snapshot()['results'][0]
        self.assertIsNone(row['score'])
        self.assertEqual(row['partial_score'], 4)
        self.assertIsNone(row['counts']['aaa'])
        self.assertTrue(row['requires_rescan'])
        snapshot = self.scan([response(DIRECTORY, directory()), response(PAGE1, body(), etag='"one"')])
        self.assertIsNone(self.factory.calls[-1][1])
        self.assertEqual(snapshot['results'][0]['score'], 13)
        self.assertFalse(snapshot['results'][0]['requires_rescan'])
        self.assertEqual(snapshot['jobs'][0]['progress']['recounted'], 1)

    def test_uncertified_304_stops_without_invented_counts(self):
        self.first_scan(etag='"one"')
        self.manager.update_collection(self.collection['id'], {'keywords': [{'term': 'new', 'weight': 1}]})
        snapshot = self.scan([response(DIRECTORY, directory()), response(PAGE1, status=304)])
        self.assertEqual(snapshot['jobs'][0]['error'], 'uncertified_304_stop')
        self.assertIsNone(snapshot['results'][0]['counts']['new'])
        self.assertIsNone(snapshot['results'][0]['score'])

    def test_unknown_dates_fetch_again_and_hash_reuse(self):
        self.first_scan()
        old = self.manager.snapshot()['results'][0]['pages'][0]
        self.assertIsNone(old['source_updated_at'])
        snapshot = self.scan([response(DIRECTORY, directory()), response(PAGE1, body())])
        new = snapshot['results'][0]['pages'][0]
        self.assertIsNone(self.factory.calls[-1][1])
        self.assertEqual(new['status'], 'unchanged_hash')
        self.assertEqual(new['body_hash'], old['body_hash'])
        self.assertNotEqual(new['checked_at'], old['checked_at'])
        self.assertEqual(snapshot['jobs'][0]['progress']['reused_hash'], 1)

    def test_same_source_date_still_recounts_changed_body(self):
        date = 'Wed, 01 Jan 2025 00:00:00 GMT'
        self.first_scan(modified=date)
        snapshot = self.scan([response(DIRECTORY, directory()), response(PAGE1, body('修仙'), modified=date)])
        self.assertEqual(snapshot['results'][0]['score'], 2)
        self.assertEqual(snapshot['results'][0]['pages'][0]['source_updated_at'], '2025-01-01T00:00:00+00:00')
        self.assertEqual(snapshot['jobs'][0]['progress']['recounted'], 1)

    def test_directory_refresh_discovers_new_pages_and_prioritizes(self):
        self.manager.update_collection(self.collection['id'], {'chars_per_book': 12})
        self.first_scan(etag='"one"')
        snapshot = self.scan([response(DIRECTORY, directory((PAGE1, PAGE2))), response(PAGE2, body('修仙' + '文' * 10, False))])
        row = snapshot['results'][0]
        self.assertEqual(row['discovered_pages'], 2)
        self.assertEqual(row['scanned_pages'], 2)
        self.assertEqual(row['score'], 7)
        self.assertEqual(self.factory.calls[-1][0], PAGE2)
        self.assertIsNone(self.factory.calls[-2][1])

    def test_pause_resume_preserves_cursor_and_budget(self):
        def pause(transport, url, validators):
            transport.cancel.set()
            raise PauseRequested(url)
        snapshot = self.scan([response(DIRECTORY, directory((PAGE1, PAGE2))), response(PAGE1, body(), etag='"one"'), pause])
        job = snapshot['jobs'][0]
        self.assertEqual(job['status'], 'paused')
        self.assertEqual(job['progress']['successful_body_pages'], 1)
        self.assertEqual(job['progress']['request_count'], 4)
        self.manager.close()
        self.manager = Manager(self.tmp.name, transport_factory=self.factory, auto_start=False)
        self.factory.script = [response(PAGE2, body('修仙', False))]
        self.manager.resume_job(job['id'])
        self.manager._run_job(job['id'])
        final = self.manager.snapshot()
        self.assertEqual(final['jobs'][0]['status'], 'completed')
        self.assertEqual(final['jobs'][0]['progress']['request_count'], 6)
        self.assertEqual(final['jobs'][0]['progress']['successful_body_pages'], 2)
        self.assertEqual(final['results'][0]['score'], 7)
        self.assertEqual(sum(url == PAGE1 for url, _ in self.factory.calls), 1)

    def test_crashed_running_job_becomes_paused(self):
        job = self.manager.start_scan(self.collection['id'])
        self.manager.close()
        self.manager = Manager(self.tmp.name, transport_factory=self.factory, auto_start=False)
        snapshot = self.manager.snapshot()
        self.assertIsNone(snapshot['active_job'])
        self.assertEqual(snapshot['jobs'][0]['status'], 'paused')
        self.assertEqual(snapshot['jobs'][0]['error'], 'interrupted_restart')
        self.manager.resume_job(job['id'])
        self.assertEqual(self.manager.snapshot()['active_job'], job['id'])

    def test_one_active_job_and_changed_config_blocks_resume(self):
        job = self.manager.start_scan(self.collection['id'])
        with self.assertRaises(ValueError):
            self.manager.start_scan(self.collection['id'])
        with self.assertRaises(ValueError):
            self.manager.update_collection(self.collection['id'], {'name': 'Changed'})
        self.manager.pause_job(job['id'])
        self.manager.update_collection(self.collection['id'], {'name': 'Changed'})
        with self.assertRaises(ValueError):
            self.manager.resume_job(job['id'])

    def test_failed_update_keeps_old_success_timestamp_and_counts(self):
        self.first_scan()
        before = self.manager.snapshot()['results'][0]['pages'][0]
        snapshot = self.scan([response(DIRECTORY, directory()), CrawlStop('http_403_access_stop', PAGE1)])
        after = snapshot['results'][0]['pages'][0]
        self.assertEqual(after['checked_at'], before['checked_at'])
        self.assertEqual(after['counts'], before['counts'])
        self.assertEqual(after['last_attempt_status'], 'http_403_access_stop')
        self.assertNotEqual(after['last_attempt_at'], before['last_attempt_at'])
        self.assertEqual(snapshot['jobs'][0]['status'], 'stopped')
        with self.assertRaises(ValueError):
            self.manager.resume_job(snapshot['jobs'][0]['id'])

    def test_snippets_are_current_and_clear_after_keyword_change(self):
        self.first_scan()
        before = self.manager.snapshot()['results'][0]
        self.assertTrue(before['snippets'])
        self.assertEqual(before['snippet_sources'][0]['url'], PAGE1)
        snapshot = self.scan([response(DIRECTORY, directory()), response(PAGE1, body('No matching words'))])
        self.assertEqual(snapshot['results'][0]['snippets'], [])
        self.first_scan()
        self.manager.update_collection(self.collection['id'], {'keywords': [{'term': 'new', 'weight': 1}]})
        self.assertEqual(self.manager.snapshot()['results'][0]['snippets'], [])

    def test_network_interruption_is_resumable(self):
        snapshot = self.scan([response(DIRECTORY, directory()), CrawlStop('network_error_stop', PAGE1)])
        job = snapshot['jobs'][0]
        self.assertEqual(job['status'], 'paused')
        self.assertEqual(job['error'], 'network_error_stop')
        self.factory.script = [response(PAGE1, body())]
        self.manager.resume_job(job['id'])
        self.manager._run_job(job['id'])
        self.assertEqual(self.manager.snapshot()['jobs'][0]['status'], 'completed')
        self.assertEqual(self.manager.snapshot()['results'][0]['score'], 5)

    def test_cannot_change_source_after_results_exist(self):
        self.first_scan()
        with self.assertRaisesRegex(ValueError, '已有结果'):
            self.manager.update_collection(self.collection['id'], {'start_url': HOME})
        self.manager.update_collection(self.collection['id'], {'max_books': 2, 'pages_per_book': 1})

    def test_body_seed_starts_there_and_uses_transient_response_once(self):
        self.manager.update_collection(self.collection['id'], {'start_url': PAGE2})
        snapshot = self.scan([response(PAGE2, body('修仙', False)), response(DIRECTORY, directory((PAGE1, PAGE2)))])
        self.assertEqual(snapshot['results'][0]['score'], 2)
        self.assertEqual(snapshot['results'][0]['pages'][0]['status'], 'unscanned')
        self.assertEqual(snapshot['jobs'][0]['progress']['body_attempts'], 1)
        self.assertEqual(sum(url == PAGE2 for url, _ in self.factory.calls), 1)

    def test_only_observed_pagination_is_followed_within_bound(self):
        first = body().replace('</div>', f'<a href="{PAGE2}">下一页</a></div>')
        snapshot = self.scan([response(DIRECTORY, directory()), response(PAGE1, first), response(PAGE2, body('修仙', False))])
        self.assertEqual(snapshot['results'][0]['discovered_pages'], 2)
        self.assertEqual(snapshot['results'][0]['score'], 7)

    def test_close_cancels_dns_worker_before_closing_database(self):
        self.manager.close()
        entered, release = threading.Event(), threading.Event()
        def resolver(*args, **kwargs):
            entered.set()
            release.wait(2)
            return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', ('93.184.216.34', 443))]
        self.manager = Manager(self.tmp.name, transport_factory=lambda **kw: SafeTransport(gate=ImmediateGate(), resolver=resolver, **kw))
        try:
            self.manager.start_scan(self.collection['id'])
            self.assertTrue(entered.wait(1))
            started = time.monotonic()
            self.manager.close()
            self.assertLess(time.monotonic() - started, 0.5)
            self.assertFalse(self.manager.worker.is_alive())
        finally:
            release.set()
        self.manager = Manager(self.tmp.name, transport_factory=self.factory, auto_start=False)
        self.assertEqual(self.manager.snapshot()['jobs'][0]['status'], 'paused')

    def test_config_hard_caps_and_finite_weights(self):
        base = {'keywords': [{'term': 'x', 'weight': 1}]}
        for change in ({'max_books': 6}, {'pages_per_book': 21}, {'keywords': [{'term': 'x', 'weight': float('nan')}]},
                       {'keywords': [{'term': 'x', 'weight': float('inf')}]}, {'keywords': [{'term': 'x', 'weight': -1}]},
                       {'keywords': [{'term': 'x'}, {'term': 'x'}]}, {'start_url': 'https://127.0.0.1/'},
                       {'start_url': HOME + '?x=1'}, {'start_url': 'https://www.52shuku.net:80/wuxia/abc.html'},
                       {'start_url': HOME + 'wuxia/../admin/test.html'},
                       {'start_url': HOME + 'wuxia/%2e%2e/%2e%2e/admin/test.html'},
                       {'start_url': HOME + 'wuxia/%252e%252e/admin/test.html'},
                       {'start_url': HOME + 'wuxia/a%2fb/test.html'}):
            with self.assertRaises(ValueError):
                validate_config({**base, **change})
        self.assertEqual(validate_config({**base, 'max_requests': 10000})['max_requests'], 160)


class ImmediateGate:
    def acquire(self, cancel, delay=0):
        if cancel.is_set():
            raise PauseRequested()
    def release(self):
        pass


class FakeResponse:
    def __init__(self, status=200, html='', headers=None):
        self.status = status
        self.headers = Message()
        for key, value in {'Content-Type': 'text/html; charset=utf-8', **(headers or {})}.items():
            self.headers[key] = value
        self.data = html.encode()
        self.closed = False
    def read1(self, limit):
        result, self.data = self.data[:limit], self.data[limit:]
        return result
    def close(self):
        self.closed = True


class TransportTests(unittest.TestCase):
    def make(self, **kwargs):
        return SafeTransport(gate=ImmediateGate(), resolver=lambda *a, **k: [(socket.AF_INET, socket.SOCK_STREAM, 6, '', ('93.184.216.34', 443))], **kwargs)

    def invoke_response(self, result, url=PAGE1, **kwargs):
        transport = self.make(**kwargs)
        transport.robots = Robots('User-agent: *\nAllow: /', 'crawler')
        with patch('transport._PinnedHTTPSConnection') as connection:
            connection.return_value.getresponse.return_value = result
            value = transport.fetch(url)
            self.assertEqual(connection.call_args.args[1], '93.184.216.34')
        return value

    def test_dns_rejects_private_or_mixed_answers(self):
        for address in ('127.0.0.1', '10.0.0.1', '169.254.169.254', '::1', 'fc00::1', '224.0.0.1'):
            transport = self.make()
            transport.resolver = lambda *a, **k: [(2, 1, 6, '', ('93.184.216.34', 443)), (2, 1, 6, '', (address, 443))]
            with self.assertRaises(CrawlStop):
                transport._resolve_public('www.52shuku.net')

    def test_rejects_external_or_unrecognized_urls(self):
        transport = self.make()
        for url in ('http://www.52shuku.net/', 'https://evil.example/', 'https://www.52shuku.net/admin', HOME + '?a=b', 'https://u:p@www.52shuku.net/', HOME + '#fragment',
                    HOME + 'wuxia/../admin/test.html', HOME + 'wuxia/%2e%2e/%2e%2e/admin/test.html',
                    HOME + 'wuxia/%252e%252e/admin/test.html', HOME + 'wuxia/a%2fb/test.html',
                    HOME + 'wuxia/a\\b/test.html', 'https://www.52shuku.net:80/wuxia/abc.html'):
            with self.assertRaises(CrawlStop):
                transport._validate(url)

    def test_403_429_challenge_and_retry_after_stop(self):
        for item, reason in ((FakeResponse(403), 'http_403_access_stop'), (FakeResponse(429), 'http_429_access_stop'),
                            (FakeResponse(html='<title>Just a moment</title>'), 'captcha_or_challenge_stop'),
                            (FakeResponse(headers={'Retry-After': '60'}), 'retry_after_stop')):
            with self.assertRaises(CrawlStop) as error:
                self.invoke_response(item)
            self.assertEqual(error.exception.reason, reason)
            self.assertTrue(item.closed)

    def test_budget_counts_attempt_before_error(self):
        records = []
        transport = self.make(max_requests=1, on_request=records.append)
        transport.robots = Robots('User-agent: *\nAllow: /', 'crawler')
        with patch('transport._PinnedHTTPSConnection') as connection:
            connection.return_value.getresponse.return_value = FakeResponse(403)
            with self.assertRaises(CrawlStop):
                transport.fetch(PAGE1)
            self.assertEqual(transport.request_count, 1)
            with self.assertRaises(CrawlStop) as error:
                transport.fetch(PAGE1)
            self.assertEqual(error.exception.reason, 'request_budget_reached')
            self.assertEqual(connection.call_count, 1)
        self.assertEqual([r['event'] for r in records], ['started', 'finished'])

    def test_robots_denied_before_http(self):
        transport = self.make()
        transport.robots = Robots('User-agent: *\nDisallow: /wuxia/', 'crawler')
        with self.assertRaises(CrawlStop) as error:
            transport.fetch(PAGE1)
        self.assertEqual(error.exception.reason, 'robots_denied_or_unavailable')
        self.assertEqual(transport.request_count, 0)

    def test_conditional_304_and_headers(self):
        transport = self.make()
        transport.robots = Robots('User-agent: *\nAllow: /', 'crawler')
        with patch('transport._PinnedHTTPSConnection') as connection:
            connection.return_value.getresponse.return_value = FakeResponse(304)
            result = transport.fetch(PAGE1, {'etag': '"certified"'})
            headers = connection.return_value.request.call_args.kwargs['headers']
            self.assertEqual(headers['If-None-Match'], '"certified"')
        self.assertEqual(result.status, 304)
        self.assertEqual(result.html, '')

    def test_304_requires_a_valid_conditional_header_actually_sent(self):
        for validators in ({'etag': None, 'last_modified': None}, {'etag': 'bad\r\nHeader: value'}, {'etag': 'x' * 513}):
            transport = self.make()
            transport.robots = Robots('User-agent: *\nAllow: /', 'crawler')
            with patch('transport._PinnedHTTPSConnection') as connection:
                connection.return_value.getresponse.return_value = FakeResponse(304)
                with self.assertRaises(CrawlStop):
                    transport.fetch(PAGE1, validators)

    def test_dns_wait_is_bounded_and_daemon_cannot_write_after_return(self):
        entered, release = threading.Event(), threading.Event()
        callbacks = []
        transport = self.make(on_request=callbacks.append)
        def resolver(*args, **kwargs):
            entered.set()
            release.wait(2)
            return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', ('93.184.216.34', 443))]
        transport.resolver = resolver
        try:
            started = time.monotonic()
            with self.assertRaises(CrawlStop) as error:
                transport._resolve_public('www.52shuku.net', deadline=started + 0.05)
            self.assertEqual(error.exception.reason, 'dns_error_stop')
            self.assertTrue(entered.is_set())
            self.assertLess(time.monotonic() - started, 0.5)
            self.assertEqual(callbacks, [])
        finally:
            release.set()

    def test_cancel_interrupts_dns_wait(self):
        release, entered = threading.Event(), threading.Event()
        transport = self.make()
        def resolver(*args, **kwargs):
            entered.set()
            release.wait(2)
            return []
        transport.resolver = resolver
        timer = threading.Timer(0.05, transport.cancellation.set)
        timer.start()
        try:
            started = time.monotonic()
            with self.assertRaises(PauseRequested):
                transport._resolve_public('www.52shuku.net', deadline=started + 30)
            self.assertLess(time.monotonic() - started, 0.5)
        finally:
            release.set()
            timer.cancel()
            timer.join()

    def test_whole_request_watchdog_interrupts_headers(self):
        from http.client import HTTPResponse
        class HangingHeaders:
            def __init__(self, *args):
                self.sock, self.peer = socket.socketpair()
            def request(self, *args, **kwargs):
                self.sock.settimeout(5)
                self.peer.sendall(b'HTTP/1.1 200 OK\r\nX-Slow: incomplete')
            def getresponse(self):
                result = HTTPResponse(self.sock)
                result.begin()
                return result
            def close(self):
                self.sock.close()
                self.peer.close()
        transport = self.make()
        transport.timeout = 0.08
        transport.robots = Robots('User-agent: *\nAllow: /', 'crawler')
        started = time.monotonic()
        with patch('transport._PinnedHTTPSConnection', HangingHeaders), self.assertRaises(CrawlStop):
            transport.fetch(PAGE1)
        self.assertLess(time.monotonic() - started, 0.7)
        self.assertFalse(any(t.name == 'novel-request-deadline' and t.is_alive() for t in threading.enumerate()))

    def test_whole_request_watchdog_interrupts_body(self):
        from http.client import HTTPResponse
        class HangingBody:
            def __init__(self, *args):
                self.sock, self.peer = socket.socketpair()
            def request(self, *args, **kwargs):
                self.sock.settimeout(5)
                self.peer.sendall(b'HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: 999999\r\n\r\n<p>partial')
            def getresponse(self):
                result = HTTPResponse(self.sock)
                result.begin()
                return result
            def close(self):
                self.sock.close()
                self.peer.close()
        transport = self.make()
        transport.timeout = 0.08
        transport.robots = Robots('User-agent: *\nAllow: /', 'crawler')
        started = time.monotonic()
        with patch('transport._PinnedHTTPSConnection', HangingBody), self.assertRaises(CrawlStop) as error:
            transport.fetch(PAGE1)
        self.assertEqual(error.exception.reason, 'network_error_stop')
        self.assertLess(time.monotonic() - started, 0.7)

    def test_date_metadata_and_unknown(self):
        self.assertEqual(source_date('<meta property="article:modified_time" content="2025-01-02T12:00:00Z">')[0], '2025-01-02T12:00:00+00:00')
        self.assertEqual(source_date('<time itemprop="dateModified" datetime="2025-01-02"></time>')[0], '2025-01-02T00:00:00')
        self.assertEqual(source_date('<meta property="article:published_time" content="2025-01-02">'), (None, None))
        self.assertEqual(source_date('<p>2025-01-02</p>', 'nonsense'), (None, None))

    def test_shared_gate_post_response_gap_and_cancellation(self):
        with patch('transport.time.monotonic', return_value=100):
            gate = RateGate()
        event = threading.Event()
        with patch.object(event, 'wait', return_value=False) as wait, patch('transport.time.monotonic', return_value=101):
            gate.acquire(event)
            self.assertAlmostEqual(wait.call_args.args[0], 2.2)
            gate.release()
        with patch.object(event, 'wait', return_value=True), patch('transport.time.monotonic', return_value=101):
            with self.assertRaises(PauseRequested):
                gate.acquire(event)
        self.assertTrue(gate.lock.acquire(blocking=False))
        gate.lock.release()


if __name__ == '__main__':
    unittest.main()
