"""Explicit, rights-confirmed, bounded page downloader. Separate from collection."""
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import threading
from datetime import datetime, timezone
import uuid

from novel_crawler.adapters.shuku52 import Shuku52Adapter
from novel_crawler.models import CrawlStop, UnknownTemplate
from transport import SafeTransport


def now():
    return datetime.now(timezone.utc).isoformat()


class Downloader:
    def __init__(self, data_dir):
        self.root = Path(data_dir).resolve()
        self.folder = self.root / 'downloads'
        self.folder.mkdir(parents=True, exist_ok=True)
        self.db_path = self.root / 'downloads.db'
        self.lock = threading.RLock()
        self.cancel = threading.Event()
        self.thread = None
        with self._db() as db:
            db.execute('CREATE TABLE IF NOT EXISTS downloads (id TEXT PRIMARY KEY, url TEXT UNIQUE NOT NULL, data TEXT NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS download_jobs (id TEXT PRIMARY KEY, data TEXT NOT NULL)')
            for row in db.execute('SELECT id,data FROM download_jobs').fetchall():
                job = json.loads(row['data'])
                if job['status'] == 'running':
                    job.update(status='paused', message='上次程序关闭，已保存进度，可继续')
                    db.execute('UPDATE download_jobs SET data=? WHERE id=?', (json.dumps(job, ensure_ascii=False), job['id']))

    @contextmanager
    def _db(self):
        db = sqlite3.connect(self.db_path, timeout=20)
        try:
            db.row_factory = sqlite3.Row
            with db:
                yield db
        finally:
            db.close()

    def _save_job(self, job):
        with self.lock, self._db() as db:
            db.execute('INSERT OR REPLACE INTO download_jobs VALUES (?,?)', (job['id'], json.dumps(job, ensure_ascii=False)))

    def snapshot(self):
        with self.lock, self._db() as db:
            records = [json.loads(r['data']) for r in db.execute('SELECT data FROM downloads')]
            jobs = [json.loads(r['data']) for r in db.execute('SELECT data FROM download_jobs')]
        records.sort(key=lambda r: r['checked_at'], reverse=True)
        jobs.sort(key=lambda j: j['created_at'], reverse=True)
        return {'records': records, 'jobs': jobs, 'active_job': next((j['id'] for j in jobs if j['status']=='running'), None)}

    def _record(self, url):
        with self._db() as db:
            row = db.execute('SELECT data FROM downloads WHERE url=?', (url,)).fetchone()
        return json.loads(row['data']) if row else None

    def start(self, items, rights_confirmed, trusted_pages=None):
        if rights_confirmed is not True:
            raise ValueError('请确认所选正文属于自有、公共领域或已获下载许可的内容')
        if not isinstance(items, list) or not 1 <= len(items) <= 20:
            raise ValueError('每次请选择 1–20 个已收集的正文网页')
        adapter = Shuku52Adapter()
        unique = []
        trusted_pages = trusted_pages or set()
        for item in items:
            if not isinstance(item, dict):
                raise ValueError('下载条目无效')
            kind, url = adapter.seed_kind(item.get('url', ''))
            book_kind, directory_url = adapter.seed_kind(item.get('directory_url', ''))
            if kind != 'body' or book_kind != 'directory':
                raise ValueError('仅允许已识别的正文页与目录')
            clean = {'url': url, 'directory_url': directory_url, 'title': str(item.get('title', '正文'))[:300],
                     'observed_in_collection': (url, directory_url) in trusted_pages}
            if url not in [r['url'] for r in unique]:
                unique.append(clean)
        with self.lock:
            if self.thread and self.thread.is_alive():
                raise ValueError('已有下载任务运行中')
            job = {'id': uuid.uuid4().hex, 'status': 'running', 'created_at': now(), 'updated_at': now(),
                   'items': unique, 'completed': [], 'request_count': 0, 'downloaded': 0, 'unchanged': 0,
                   'rights_confirmed': True, 'message': '准备检查来源规则', 'error': None}
            self._save_job(job)
            self._launch(job)
            return job

    def _launch(self, job):
        self.cancel.clear()
        self.thread = threading.Thread(target=self._run, args=(job,), name='permitted-download', daemon=True)
        self.thread.start()

    def resume(self, job_id, rights_confirmed):
        if rights_confirmed is not True:
            raise ValueError('继续前请确认内容下载许可仍有效')
        with self.lock, self._db() as db:
            row = db.execute('SELECT data FROM download_jobs WHERE id=?', (job_id,)).fetchone()
            if not row:
                raise ValueError('找不到下载任务')
            if self.thread and self.thread.is_alive():
                raise ValueError('已有下载任务运行中')
            job = json.loads(row['data'])
            if job['status'] not in ('paused', 'interrupted'):
                raise ValueError('只有暂停或中断任务可以继续；访问拒绝任务不会自动重试')
            job.update(status='running', error=None, message='继续已保存的进度', updated_at=now())
            self._save_job(job)
            self._launch(job)
            return job

    def pause(self, job_id):
        snapshot = self.snapshot()
        if snapshot['active_job'] != job_id:
            raise ValueError('该下载任务未运行')
        self.cancel.set()
        return {'ok': True}

    def _run(self, job):
        adapter = Shuku52Adapter()
        def on_request(record):
            job['request_count'] = record['count']
            job['updated_at'] = now()
            self._save_job(job)
        try:
            remaining = 64 - int(job.get('request_count', 0))
            if remaining <= 0:
                raise CrawlStop('request_budget_reached')
            transport = SafeTransport(adapter=adapter, max_requests=64, request_count=job['request_count'], cancellation=self.cancel, on_request=on_request)
            transport.load_robots()
            books = {}
            for item in job['items']:
                if item['url'] in job['completed']:
                    continue
                if self.cancel.is_set():
                    job.update(status='paused', message='已暂停；可继续剩余页')
                    break
                job['message'] = '检查：' + item['url']
                self._save_job(job)
                directory = item['directory_url']
                if directory not in books:
                    res = transport.fetch(directory)
                    if res.final_url != directory:
                        raise ValueError('目录重定向改变了内容身份，已停止')
                    books[directory] = adapter.directory(res.html, res.final_url)
                book = books[directory]
                if item['url'] not in book.body_urls and not item.get('observed_in_collection'):
                    raise ValueError('所选页不在真实目录或已搜集的分页链接中；拒绝猜测或跨书下载')
                old = self._record(item['url'])
                validators = None
                if old and (self.folder / old['filename']).is_file() and (old.get('etag') or old.get('last_modified')):
                    validators = {'etag': old.get('etag'), 'last_modified': old.get('last_modified')}
                result = transport.fetch(item['url'], validators=validators)
                checked = now()
                if result.final_url != item['url']:
                    raise ValueError('正文重定向改变了页面身份，已停止')
                if result.status == 304:
                    if not validators:
                        raise ValueError('来源返回未修改，但未发送可用校验头，已停止')
                    if not old or not (self.folder / old['filename']).is_file():
                        raise ValueError('来源返回未修改，但本地正文缺失；请新建下载检查')
                    record = dict(old, checked_at=checked, status='unchanged_304')
                    job['unchanged'] += 1
                else:
                    if result.status != 200:
                        raise ValueError('来源返回非正文响应，已停止')
                    body = adapter.body(result.html, result.final_url, book)
                    digest = hashlib.sha256(body.text.encode('utf-8')).hexdigest()
                    unchanged = old and old['body_hash'] == digest and (self.folder / old['filename']).is_file()
                    record = dict(old or {})
                    record.update(id=(old or {}).get('id', uuid.uuid4().hex), url=item['url'], directory_url=directory,
                        title=book.title, checked_at=checked, body_hash=digest,
                        source_updated_at=result.source_updated_at, etag=result.etag, last_modified=result.last_modified)
                    if unchanged:
                        record['status'] = 'unchanged_hash'
                        job['unchanged'] += 1
                    else:
                        stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
                        name = record['id'] + '_' + stamp + '.txt'
                        path = self.folder / name
                        temp = path.with_suffix('.tmp')
                        text = book.title + '\n' + item['url'] + '\n来源更新：' + (result.source_updated_at or '未知') + '\n下载时间：' + checked + '\n\n' + body.text
                        with open(temp, 'w', encoding='utf-8-sig', newline='\n') as f:
                            f.write(text)
                            f.flush()
                            os.fsync(f.fileno())
                        os.replace(temp, path)
                        versions = list((old or {}).get('versions', []))
                        if old and old.get('filename'):
                            versions.append({'filename': old['filename'], 'downloaded_at': old['downloaded_at'], 'body_hash': old['body_hash']})
                        record.update(filename=name, downloaded_at=checked, status='updated' if old else 'downloaded', versions=versions, bytes=path.stat().st_size)
                        job['downloaded'] += 1
                with self._db() as db:
                    db.execute('INSERT OR REPLACE INTO downloads VALUES (?,?,?)', (record['id'], record['url'], json.dumps(record, ensure_ascii=False)))
                job['completed'].append(item['url'])
                self._save_job(job)
            else:
                job.update(status='completed', message='下载检查已完成')
        except CrawlStop as error:
            reason = str(getattr(error, 'reason', error))
            if self.cancel.is_set() or 'cancel' in reason or 'pause' in reason:
                job.update(status='paused', message='已暂停；进度已保存')
            else:
                access_block = any(s in reason for s in ('403', '429', 'challenge', 'robots', 'retry_after'))
                job.update(status='blocked' if access_block else 'interrupted', message='已停止：' + reason, error=reason)
        except (ValueError, UnknownTemplate) as error:
            job.update(status='blocked', message='已停止：' + str(error), error=str(error))
        except Exception as error:
            job.update(status='interrupted', message='下载中断：' + type(error).__name__, error=str(error)[:300])
        finally:
            job['updated_at'] = now()
            self._save_job(job)

    def file(self, record_id, version=None):
        with self._db() as db:
            row = db.execute('SELECT data FROM downloads WHERE id=?', (record_id,)).fetchone()
        if not row:
            raise ValueError('找不到下载记录')
        record = json.loads(row['data'])
        filename = record['filename']
        if version is not None:
            versions = record.get('versions', [])
            if not isinstance(version, int) or not 0 <= version < len(versions):
                raise ValueError('版本不存在')
            filename = versions[version]['filename']
        path = (self.folder / filename).resolve()
        if path.parent != self.folder or not path.is_file():
            raise ValueError('本地文件不存在')
        return path

    def close(self):
        self.cancel.set()
        if self.thread:
            self.thread.join(timeout=35)
