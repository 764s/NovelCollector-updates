"""Book-scoped content searches and shared, prose-free observations.

The context identity is the adapter's canonical directory URL. A (book, seed)
has exactly one search state, independently of collection or execution jobs.
All methods participate in the caller's SQLite transaction and lock.
"""
from copy import deepcopy
from hashlib import sha256
import json

from text_strategies import TextScheduler, coverage
from content_model import ContentExecution, ContentMode
from transport import utcnow


def encode(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def validate_seed(seed):
    if not isinstance(seed, str) or not seed.strip() or len(seed) > 128 or any(ord(c) < 32 for c in seed):
        raise ValueError('内容种子须为 1–128 个字符')
    return seed.strip()


def binding(config, start_body=None):
    return ContentMode.from_config(config, start_body).binding()


class ContentSearchStore:
    def __init__(self, db):
        self.db = db
        db.executescript('''
        CREATE TABLE IF NOT EXISTS content_contexts(
            directory_url TEXT PRIMARY KEY, data TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS content_sources(
            directory_url TEXT NOT NULL, url TEXT NOT NULL, data TEXT NOT NULL,
            PRIMARY KEY(directory_url,url));
        CREATE TABLE IF NOT EXISTS content_facts(
            id TEXT PRIMARY KEY, directory_url TEXT NOT NULL, kind TEXT NOT NULL,
            url TEXT NOT NULL, body_hash TEXT NOT NULL, start INTEGER, end INTEGER,
            data TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS content_fact_ranges ON content_facts(
            directory_url,kind,url,body_hash,start,end);
        CREATE TABLE IF NOT EXISTS content_searches(
            directory_url TEXT NOT NULL, seed TEXT NOT NULL, binding TEXT NOT NULL,
            state TEXT NOT NULL, job_id TEXT NOT NULL, status TEXT NOT NULL,
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
            PRIMARY KEY(directory_url,seed));
        ''')

    def context(self, directory):
        row = self.db.execute('SELECT data FROM content_contexts WHERE directory_url=?', (directory,)).fetchone()
        return json.loads(row[0]) if row else None

    def put_context(self, directory, metadata):
        self.db.execute('INSERT OR REPLACE INTO content_contexts VALUES(?,?)', (directory, encode({
            'directory_url': directory, 'title': metadata['title'], 'body_urls': metadata['body_urls']})))

    def source(self, directory, url):
        row = self.db.execute('SELECT data FROM content_sources WHERE directory_url=? AND url=?', (directory, url)).fetchone()
        return json.loads(row[0]) if row else None

    def put_source(self, directory, url, page):
        self.db.execute('INSERT OR REPLACE INTO content_sources VALUES(?,?,?)', (directory, url, encode(page)))

    def get(self, directory, seed):
        return self.db.execute('SELECT * FROM content_searches WHERE directory_url=? AND seed=?', (directory, seed)).fetchone()

    def check(self, row, config, start_body, job_id=None):
        if not row:
            return
        if ContentMode.from_binding(json.loads(row['binding'])) != ContentMode.from_config(config, start_body):
            raise ValueError('此内容种子已绑定另一组关键词或策略，请换用新种子；权重和本次字数额度可单独调整')
        job = self.db.execute('SELECT status,error FROM jobs WHERE id=?', (row['job_id'],)).fetchone()
        if job and row['job_id'] != job_id:
            if row['status'] != 'completed' and job['status'] in ('paused', 'running', 'queued', 'pausing'):
                raise ValueError('此内容种子有未完成任务，请恢复原任务；恢复不会增加字数额度')
            if row['status'] != 'completed' and job['error'] == 'source_changed_during_scan':
                raise ValueError('此内容种子的正文版本已改变，请换用新种子')

    def open(self, directory, seed, sources, config, start_body, job_id, *, advance=False, resume_incomplete=False):
        row = self.get(directory, seed)
        self.check(row, config, start_body, job_id)
        if row and row['job_id'] == job_id and not advance:
            # Re-entering after a crash between directory parsing and saving the
            # job cursor must not allocate a second allowance.
            return TextScheduler(self.unpack(json.loads(row['state'])))
        if row:
            scheduler = TextScheduler(self.unpack(json.loads(row['state'])))
            for url in sources:
                if url not in scheduler.state['sources']:
                    scheduler.state['sources'].append(url)
            if not (resume_incomplete and scheduler.state.get('rounds_completed', 0) < scheduler.state.get('iteration', 1)):
                scheduler.continue_search(config['chars_per_book'])
        else:
            scheduler = TextScheduler.create(sources, config, seed=start_body, content_seed=seed)
        for url in scheduler.state['sources']:
            page = self.source(directory, url)
            if page and page.get('text_length') is not None and url not in scheduler.state['hashes']:
                scheduler.register_source(url, page['text_length'], page['body_hash'])
        scheduler.add_context_hints(self.hints(directory, scheduler.state))
        packed = self.pack(directory, scheduler.state)
        now = utcnow()
        self.db.execute('''INSERT INTO content_searches VALUES(?,?,?,?,?,?,?,?)
            ON CONFLICT(directory_url,seed) DO UPDATE SET
            state=excluded.state,job_id=excluded.job_id,status=excluded.status,updated_at=excluded.updated_at''',
            (directory, seed, encode(binding(config, start_body)), encode(packed), job_id, 'running',
             row['created_at'] if row else now, now))
        return scheduler

    def _fact(self, directory, kind, data):
        key = sha256(encode([directory, kind, data]).encode('utf-8')).hexdigest()
        self.db.execute('INSERT OR IGNORE INTO content_facts VALUES(?,?,?,?,?,?,?,?)',
            (key, directory, kind, data['url'], data['body_hash'], data.get('start'), data.get('end'), encode(data)))
        return key

    def fact(self, key):
        row = self.db.execute('SELECT data FROM content_facts WHERE id=?', (key,)).fetchone()
        if row is None:
            raise ValueError('共享证据引用缺失')
        return json.loads(row[0])

    def pack(self, directory, plan):
        if not plan.get('content_seed') or 'evidence_refs' in plan:
            return deepcopy(plan)
        packed = {k: deepcopy(v) for k, v in plan.items() if k not in ('evidence', 'metrics')}
        refs = []
        for evidence in plan['evidence']:
            fact = {k: deepcopy(evidence[k]) for k in (
                'url', 'start', 'end', 'body_hash', 'body_chars', 'counts', 'focus_intervals', 'focus_hits')}
            fact['focus_terms'] = sorted(plan['focus_terms'])
            key = self._fact(directory, 'fragment', fact)
            refs.append({'id': key, **{k: deepcopy(evidence[k]) for k in (
                'requested_by', 'reasons', 'evaluated_by', 'checked_at', 'reused_from_context') if k in evidence}})
        packed['evidence_refs'] = refs
        packed['metric_refs'] = {group: {url: self._fact(directory, 'aggregate', {
            'url': url, 'body_hash': plan['hashes'][url], 'counts': counts,
            'ranges': coverage(plan, url, None if group == 'combined' else group)})
            for url, counts in values.items()} for group, values in plan['metrics'].items()}
        return packed

    def unpack(self, packed):
        if 'evidence_refs' not in packed:
            return deepcopy(packed)
        plan = {k: deepcopy(v) for k, v in packed.items() if k not in ('evidence_refs', 'metric_refs')}
        plan['evidence'] = []
        for ref in packed['evidence_refs']:
            fact = self.fact(ref['id'])
            fact.pop('focus_terms', None)
            plan['evidence'].append({**fact, **{k: v for k, v in ref.items() if k != 'id'}, 'context_ref': ref['id']})
        plan['metrics'] = {group: {url: self.fact(key)['counts'] for url, key in values.items()}
                           for group, values in packed['metric_refs'].items()}
        return plan

    def save(self, directory, plan, job_id, status='running'):
        packed = self.pack(directory, plan)
        self.db.execute('''UPDATE content_searches SET state=?,job_id=?,status=?,updated_at=?
            WHERE directory_url=? AND seed=?''',
            (encode(packed), job_id, status, utcnow(), directory, plan['content_seed']))
        return packed

    def reusable(self, directory, pending, digest, keywords, focus_terms):
        rows = self.db.execute('''SELECT id,data FROM content_facts WHERE directory_url=?
            AND kind='fragment' AND url=? AND body_hash=? AND start=? AND end=? ORDER BY id''',
            (directory, pending['url'], digest, pending['start'], pending['end'])).fetchall()
        for row in rows:
            fact = json.loads(row['data'])
            if all(k['term'] in fact['counts'] for k in keywords) and fact['focus_terms'] == sorted(focus_terms):
                return {**fact, 'context_ref': row['id']}
        return None

    def hints(self, directory, plan):
        if not plan['focus_terms']:
            return []
        rows = self.db.execute("SELECT id,data FROM content_facts WHERE directory_url=? AND kind='fragment'", (directory,)).fetchall()
        result = []
        for row in rows:
            fact = json.loads(row['data'])
            if (fact['url'] in plan['sources'] and fact['body_hash'] == plan['hashes'].get(fact['url'])
                    and fact['focus_terms'] == sorted(plan['focus_terms']) and fact['focus_intervals']):
                result.append({**fact, 'context_ref': row['id']})
        return result

    def searches(self, directory):
        result = []
        for row in self.db.execute('SELECT * FROM content_searches WHERE directory_url=? ORDER BY created_at,seed', (directory,)):
            plan = json.loads(row['state'])
            job = self.db.execute('SELECT status,error FROM jobs WHERE id=?', (row['job_id'],)).fetchone()
            result.append({'seed': row['seed'], 'status': row['status'] if row['status'] == 'completed' else job['status'] if job else row['status'],
                'job_id': row['job_id'], 'iteration': plan['iteration'],
                'completed_rounds': plan.get('rounds_completed', 0),
                'scanned_chars': plan.get('consumed_chars', 0), 'references': len(plan['evidence_refs']),
                'shared_reused_chars': plan.get('shared_reused_chars', 0),
                'execution': ContentExecution(plan).snapshot(plan.get('consumed_chars', 0),
                    max(0, plan.get('consumed_chars', 0) - plan['limit'] + plan['iteration_budget'])),
                'binding': json.loads(row['binding']), 'updated_at': row['updated_at']})
        return result
