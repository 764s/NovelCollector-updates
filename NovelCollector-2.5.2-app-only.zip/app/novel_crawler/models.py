from dataclasses import dataclass
from math import isfinite
from typing import Protocol

class UnknownTemplate(ValueError):
    """Never fall back to searching the entire page."""

class CrawlStop(RuntimeError):
    def __init__(self, reason, url='', retry_after=None):
        super().__init__(reason)
        self.reason, self.url, self.retry_after = reason, url, retry_after

@dataclass(frozen=True)
class SiteDefinition:
    key: str
    version: str
    homepage: str
    allowed_hosts: tuple[str, ...]
    user_agent: str = 'NovelBodyKeywordCrawler/1.0'

@dataclass(frozen=True)
class Book:
    url: str
    title: str
    body_urls: tuple[str, ...]

@dataclass(frozen=True)
class Body:
    text: str  # Transient only: never put this in persistent state or result files.
    next_urls: tuple[str, ...]
    removed_preamble_paragraphs: int = 0

class SiteAdapter(Protocol):
    definition: SiteDefinition
    def seed_kind(self, url: str) -> tuple[str, str]: ...
    def directory_from_body(self, html: str, url: str) -> str: ...
    def category_url(self, html: str, url: str) -> str: ...
    def book_links(self, html: str, url: str) -> list[str]: ...
    def directory(self, html: str, url: str) -> Book: ...
    def body(self, html: str, url: str, book: Book) -> Body: ...
    @property
    def board_types(self) -> dict[str, str]: ...
    def normalize_board(self, value: dict) -> dict: ...
    def board_reader(self, board: dict): ...
    @property
    def content_capabilities(self) -> frozenset[str]: ...
    def content_reader(self, transport, cancellation): ...

@dataclass(frozen=True)
class RunConfig:
    keyword: str = '修仙'  # First term; kept for v1 state compatibility.
    keywords: tuple[str, ...] = ()  # Additional terms, in user order.
    start_url: str | None = None
    max_books: int = 5
    pages_per_book: int = 20
    max_body_pages: int = 100
    interval: float = 3.2
    timeout: float = 30
    max_response_bytes: int = 4_000_000
    max_snippets_per_book: int = 2
    snippet_chars: int = 32
    # Hard cap for cumulative requests, including directories, robots and redirects.
    max_requests: int = 160

    @property
    def terms(self):
        return tuple(dict.fromkeys((self.keyword,) + self.keywords))

    def __post_init__(self):
        if not isinstance(self.keyword, str) or not self.keyword or len(self.keyword) > 64:
            raise ValueError('keyword must contain 1–64 literal characters')
        if not isinstance(self.keywords, tuple) or any(not isinstance(k, str) or not k or len(k) > 64 for k in self.keywords):
            raise ValueError('keywords must be a tuple of non-empty literal strings, each <=64 characters')
        if len(self.terms) > 100:
            raise ValueError('at most100 distinct keywords are supported')
        if self.start_url is not None and (not isinstance(self.start_url, str) or not self.start_url):
            raise ValueError('start_url must be a non-empty URL string or None')
        for name in ('max_books', 'pages_per_book', 'max_body_pages', 'max_response_bytes', 'max_requests'):
            value = getattr(self, name)
            if type(value) is not int or value <= 0:
                raise ValueError(f'{name} must be a positive integer')
        if type(self.interval) not in (int, float) or type(self.timeout) not in (int, float) or not isfinite(self.interval) or not isfinite(self.timeout) or self.interval < 3 or self.timeout <= 0:
            raise ValueError('interval must be >= 3 seconds; timeout must be positive')
        if type(self.max_snippets_per_book) is not int or type(self.snippet_chars) is not int or not 0 <= self.max_snippets_per_book <= 2 or not 0 <= self.snippet_chars <= 40:
            raise ValueError('snippets are restricted to <= 2 per book and <= 40 characters each')
