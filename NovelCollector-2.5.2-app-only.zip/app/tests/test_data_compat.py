"""Rollback must account for retained content modes as well as current config."""
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

from core import Manager
from data_compat import minimum_reader_version
from main import Application, VERSION
from test_content_modes import fixed_config
from updater import RUNTIME, UpdateError, _detected_platform


class DataCompatibilityTests(unittest.TestCase):
    def test_configuration_is_a_requirement_but_literal_keyword_is_not(self):
        with tempfile.TemporaryDirectory() as temp:
            manager = Manager(temp, auto_start=False)
            try:
                saved = manager.create_collection(fixed_config())
                self.assertEqual(manager.minimum_reader_version(), '2.5.0')
                manager.update_collection(saved['id'], {'strategies': [{'id': 'distributed'}],
                    'name': 'fixed_interval', 'keywords': [{'term': 'fixed_interval'}]})
                self.assertIsNone(manager.minimum_reader_version())
            finally:
                manager.close()

    def test_retained_modes_are_checked_in_each_persisted_location(self):
        columns = {'collections': ['config'], 'jobs': ['config', 'state'], 'books': ['data'],
                   'content_searches': ['binding', 'state'], 'discovery_evaluations': ['data']}
        db = sqlite3.connect(':memory:')
        try:
            for table, names in columns.items():
                db.execute(f'CREATE TABLE {table} ({",".join(name + " TEXT" for name in names)})')
            for table, names in columns.items():
                for column in names:
                    with self.subTest(table=table, column=column):
                        values = {name: '{}' for name in names}
                        values[column] = json.dumps({'nested': {'specs': [{'id': 'fixed_interval', 'enabled': False}]}})
                        db.execute(f'INSERT INTO {table} VALUES ({",".join("?" for _ in names)})', list(values.values()))
                        self.assertEqual(minimum_reader_version(db), '2.5.0')
                        db.execute(f'DELETE FROM {table}')
                        self.assertIsNone(minimum_reader_version(db))
        finally:
            db.close()

    def test_resetting_collection_does_not_hide_historical_job_requirement(self):
        with tempfile.TemporaryDirectory() as temp:
            manager = Manager(temp, auto_start=False)
            try:
                saved = manager.create_collection(fixed_config())
                job = manager.start_scan(saved['id'], content_seed='fixed')
                manager.pause_job(job['id'])
                manager.update_collection(saved['id'], {'strategies': [{'id': 'distributed'}]})
            finally:
                manager.close()
            manager = Manager(temp, auto_start=False)
            try:
                self.assertEqual(manager.minimum_reader_version(), '2.5.0')
            finally:
                manager.close()


class RollbackApplicationTests(unittest.TestCase):
    def test_application_rejects_old_reader_and_remains_usable(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            home = root / 'program'
            for version in ('2.4.0', VERSION):
                target = home / 'releases' / version / 'app'
                target.mkdir(parents=True)
                (target / 'main.py').write_text('# isolated release fixture\n')
            (home / 'runtime-compat.json').write_text(json.dumps({'schema': 1, 'runtime': RUNTIME,
                'data_format': 1, 'platform': _detected_platform()}))
            pointer = home / 'active-release.json'
            pointer.write_text(json.dumps({'schema': 1, 'version': VERSION, 'path': f'releases/{VERSION}/app',
                'previous': {'version': '2.4.0', 'path': 'releases/2.4.0/app'}}))
            with patch('main.HOME', home), patch('main.resolve_data_dir', return_value=root / 'data'):
                app = Application()
                try:
                    saved = app.action('/api/collections', fixed_config())
                    before_pointer = pointer.read_bytes()
                    before_data = list(app.manager.db.iterdump())
                    with self.assertRaisesRegex(UpdateError, '已取消回退'):
                        app.action('/api/updates/rollback', {'confirmed': True})
                    self.assertEqual(pointer.read_bytes(), before_pointer)
                    self.assertEqual(list(app.manager.db.iterdump()), before_data)
                    self.assertFalse(app.restart)
                    self.assertFalse(app.maintenance)
                    self.assertEqual(app.snapshot()['collections'][0]['id'], saved['id'])
                    self.assertTrue(list((root / 'data-backups').glob('*/app.db')))
                finally:
                    app.close()
