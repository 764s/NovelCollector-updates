"""Anonymous, fixed-source public updates; downloaded archives still need Updater.stage()."""
import hashlib
import io
import re
import zipfile
import zlib

from updater import MAX_ARCHIVE_BYTES, MAX_MANIFEST_BYTES, MAX_FILES, UpdateError, _json, _version
from release_http import read_api, ReleaseHTTPError

REPOSITORY = '764s/NovelCollector-updates'
RELEASES_URL = 'https://github.com/' + REPOSITORY + '/releases'
MAX_METADATA_BYTES = 512 * 1024
MAX_CHECKSUM_BYTES = 4096
MAX_ASSETS = 100
METADATA_TIMEOUT = 30
DOWNLOAD_TIMEOUT = 120
_DIGEST = re.compile(r'sha256:([0-9a-f]{64})\Z')
_FALLBACK = '也可在 GitHub Releases 手动下载可信的 app-only ZIP，再使用本地 ZIP 更新。'
_MESSAGES = {
    'release_unavailable': '公开更新源暂时不可用或尚未发布版本，请稍后重试。无需登录或填写令牌。',
    'rate_limited': 'GitHub 暂时限制了请求频率，请稍后重试。无需登录或填写令牌。',
    'network_error': '暂时无法连接 GitHub，请检查网络后重试。',
    'timeout': '连接 GitHub 超时，请稍后重试。',
    'response_too_large': 'GitHub 返回的内容超过安全大小限制，已停止下载。',
    'invalid_release': 'GitHub Release 元数据无效，或不是 vX.Y.Z 格式的正式版本。',
    'missing_asset': '此 Release 缺少与版本完全匹配的 app-only ZIP。',
    'missing_checksum': '此 Release 没有可验证的 SHA-256，已停止自动下载。',
    'invalid_checksum': 'Release 的 SHA-256 元数据或校验文件无效，已停止下载。',
    'checksum_mismatch': '下载文件的 SHA-256 或大小与 Release 不一致，已拒绝此更新。',
    'invalid_archive': '下载文件不是有效的 app-only ZIP，或清单版本与 Release 不一致。',
    'unsafe_redirect': 'GitHub 返回了不受支持的下载地址，已停止更新。',
}


class _Failure(Exception):
    def __init__(self, status):
        self.status = status
        super().__init__(status)


def _integer(value, maximum):
    return type(value) is int and 0 < value <= maximum


def _api(asset_id=None, *, limit=MAX_METADATA_BYTES, timeout=METADATA_TIMEOUT):
    try:
        return read_api(REPOSITORY, asset_id, limit=limit, timeout=timeout)
    except ReleaseHTTPError as error:
        status = error.status
        if status in ('auth_required', 'access_or_missing', 'access_denied', 'sso_required'):
            status = 'release_unavailable'
        raise _Failure(status) from None


def _asset(value, maximum):
    if (not _integer(value.get('id'), (1 << 63) - 1)
            or not _integer(value.get('size'), maximum)
            or value.get('state') != 'uploaded'):
        raise _Failure('invalid_release')
    digest = value.get('digest')
    if digest is not None and (not isinstance(digest, str) or not _DIGEST.fullmatch(digest)):
        raise _Failure('invalid_checksum')
    return {'id': value['id'], 'name': value['name'], 'size': value['size'],
            'sha256': _DIGEST.fullmatch(digest)[1] if digest is not None else None}


def _download_asset(asset, limit):
    data = _api(asset['id'], limit=limit, timeout=DOWNLOAD_TIMEOUT)
    if not data or len(data) > limit or len(data) != asset['size']:
        raise _Failure('checksum_mismatch')
    if asset['sha256'] and hashlib.sha256(data).hexdigest() != asset['sha256']:
        raise _Failure('checksum_mismatch')
    return data


def _checksum(data, name):
    try:
        text = data.decode('ascii').rstrip('\r\n')
    except UnicodeError:
        raise _Failure('invalid_checksum') from None
    # Accept precisely the standard sha256sum line for this exact ZIP name.
    match = re.fullmatch(r'([0-9a-fA-F]{64}) [ *]' + re.escape(name), text)
    if not match:
        raise _Failure('invalid_checksum')
    return match[1].lower()


def _manifest_version(data, version):
    # Only a cheap bounded preflight. Updater.stage performs the full archive,
    # path, file hash, runtime, platform and data-format validation afterwards.
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            members = archive.infolist()
            manifests = [item for item in members if item.filename == 'manifest.json']
            if len(members) > MAX_FILES * 2 + 1 or len(manifests) != 1:
                raise _Failure('invalid_archive')
            item = manifests[0]
            if (item.orig_filename != item.filename or item.flag_bits & 1
                    or not 0 < item.file_size <= MAX_MANIFEST_BYTES
                    or item.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED)):
                raise _Failure('invalid_archive')
            with archive.open(item) as stream:
                raw = stream.read(MAX_MANIFEST_BYTES + 1)
            if len(raw) != item.file_size or len(raw) > MAX_MANIFEST_BYTES:
                raise _Failure('invalid_archive')
            value = _json(raw)
            if not isinstance(value, dict) or value.get('version') != version:
                raise _Failure('invalid_archive')
    except (zipfile.BadZipFile, zipfile.LargeZipFile, RuntimeError, EOFError,
            NotImplementedError, zlib.error, UpdateError, ValueError, OSError):
        raise _Failure('invalid_archive') from None


class GitHubUpdates:
    """Fixed-repository, no-install transport; results never contain raw errors.

    check(): JSON-safe status, version, fixed release link and download size.
    download(): rechecks latest, then adds archive bytes on status=downloaded.
    The caller MUST remove archive before JSON serialization and use Updater's
    validation/staging before seeking install consent. Neither method writes.
    """
    def __init__(self, current_version):
        _version(current_version)
        self.current_version = current_version

    def _result(self, status, message, **extra):
        return {'ok': status in ('available', 'current', 'downloaded'),
                'status': status, 'message': message, 'repository': REPOSITORY,
                'current_version': self.current_version, 'releases_url': RELEASES_URL,
                **extra}

    def _error(self, failure):
        status = failure.status if failure.status in _MESSAGES else 'network_error'
        return self._result(status, _MESSAGES[status] + ' ' + _FALLBACK)

    def _latest(self):
        raw = _api()
        if len(raw) > MAX_METADATA_BYTES:
            raise _Failure('response_too_large')
        try:
            release = _json(raw)
            if (not isinstance(release, dict) or release.get('draft') is not False
                    or release.get('prerelease') is not False):
                raise _Failure('invalid_release')
            tag = release.get('tag_name')
            if not isinstance(tag, str) or not tag.startswith('v'):
                raise _Failure('invalid_release')
            version = tag[1:]
            _version(version)
            info = {'version': version, 'release_url': RELEASES_URL + '/tag/' + tag}
            if _version(version) <= _version(self.current_version):
                return self._result('current', '当前已是最新版本，无需更新。', **info), None, None
            assets = release.get('assets')
            if (not isinstance(assets, list) or len(assets) > MAX_ASSETS
                    or any(not isinstance(item, dict) or not isinstance(item.get('name'), str)
                           for item in assets)):
                raise _Failure('invalid_release')
            name = 'NovelCollector-' + version + '-app-only.zip'
            matches = [item for item in assets if item['name'] == name]
            if not matches:
                raise _Failure('missing_asset')
            if len(matches) != 1:
                raise _Failure('invalid_release')
            asset = _asset(matches[0], MAX_ARCHIVE_BYTES)
            checksum = None
            if not asset['sha256']:
                checksums = [item for item in assets if item['name'] == name + '.sha256']
                if not checksums:
                    raise _Failure('missing_checksum')
                if len(checksums) != 1:
                    raise _Failure('invalid_checksum')
                checksum = _asset(checksums[0], MAX_CHECKSUM_BYTES)
                if checksum['id'] == asset['id']:
                    raise _Failure('invalid_release')
            return self._result('available', '发现新版本，可下载校验后预览更新。', **info,
                                asset_name=name, size=asset['size'],
                                checksum_source='github_digest' if asset['sha256'] else 'companion_asset'), asset, checksum
        except UpdateError:
            raise _Failure('invalid_release') from None

    def check(self):
        try:
            return self._latest()[0]
        except _Failure as failure:
            return self._error(failure)

    def download(self):
        try:
            result, asset, checksum = self._latest()
            if result['status'] != 'available':
                return result
            expected = asset['sha256']
            if checksum:
                expected = _checksum(_download_asset(checksum, MAX_CHECKSUM_BYTES), asset['name'])
            data = _download_asset(asset, MAX_ARCHIVE_BYTES)
            if hashlib.sha256(data).hexdigest() != expected:
                raise _Failure('checksum_mismatch')
            _manifest_version(data, result['version'])
            return {**result, 'status': 'downloaded', 'message': '更新包已下载并通过 SHA-256 与版本校验，尚未安装。',
                    'archive_sha256': expected, 'archive': data}
        except _Failure as failure:
            return self._error(failure)
