"""Content modes, lazy character readers and resumable fixed sampling."""
from copy import deepcopy
from hashlib import sha256
import json
import tempfile
import threading
import unittest
from unittest.mock import patch

from content_model import ContentMode
from content_reader import WebsiteContentReader
from core import Manager
from novel_crawler.adapters.shuku52 import Shuku52Adapter
from novel_crawler.models import Book, Body, CrawlStop
from text_strategies import TextScheduler, consumed, coverage, normalize_strategies, summarize
from transport import FetchResult, PauseRequested
from test_strategies import URLS, config, finish, prose, MapTransport
from test_core import DIRECTORY


def fixed_config(offset=0, gap=0, width=5, budget=100, focus=False, distributed=False):
    return config(sample_chars=width, chars_per_book=budget, strategies=[
        {'id': 'distributed', 'enabled': distributed},
        {'id': 'fixed_interval', 'params': {'offset_chars': offset, 'gap_chars': gap}},
        {'id': 'focus_neighbors', 'enabled': focus,
         'params': {'radius_chars': 30, 'miss_chars': 20, 'region_chars': 60}}])


def positions(rows):
    return [(r['url'], r['start'], r['end']) for r in rows]


class ModeTests(unittest.TestCase):
    def test_mode_is_immutable_and_excludes_weights_and_run_allowance(self):
        cfg = fixed_config()
        mode = ContentMode.from_config(cfg)
        cfg['chars_per_book'] = 20
        cfg['keywords'][0]['weight'] = 90
        self.assertEqual(mode, ContentMode.from_config(cfg))
        serialized = mode.binding()
        serialized['strategies'][-1]['params']['gap_chars'] = 8
        self.assertEqual(mode, ContentMode.from_config(cfg))
        cfg['keywords'][0]['focused'] = False
        self.assertNotEqual(mode, ContentMode.from_config(cfg))
        self.assertNotEqual(mode, ContentMode.from_config(fixed_config(gap=1)))
        self.assertNotEqual(mode, ContentMode.from_config(fixed_config(), URLS[0]))

    def test_existing_mode_keeps_exact_v1_binding(self):
        cfg = config()
        old = {'version': 1, 'start_body': URLS[0], 'sample_chars': cfg['sample_chars'],
               'keywords': sorted([{'term': k['term'], 'focused': k['focused']} for k in cfg['keywords']],
                                  key=lambda k: k['term']), 'strategies': cfg['strategies']}
        self.assertEqual(ContentMode.from_config(cfg, URLS[0]).binding(), old)
        self.assertEqual(ContentMode.from_binding(old).binding(), old)
        old['version'] = 999
        with self.assertRaises(ValueError):
            ContentMode.from_binding(old)

    def test_invalid_fixed_parameters_and_no_baseline_are_rejected(self):
        for params in ({'offset_chars': -1}, {'gap_chars': True}, {'gap_chars': 1.5},
                       {'gap_chars': 10000001}, {'offset_pages': 1}):
            with self.subTest(params=params), self.assertRaises(ValueError):
                normalize_strategies([{'id': 'fixed_interval', 'params': params}])
        with self.assertRaises(ValueError):
            normalize_strategies([{'id': 'focus_neighbors'}])


class FixedSamplingTests(unittest.TestCase):
    def test_offset_window_and_gap_cross_sources_by_characters(self):
        cfg = fixed_config(offset=4, gap=3, width=5, budget=15)
        scheduler = TextScheduler.create(URLS[:3], cfg, content_seed='fixed')
        rows = finish(scheduler, dict(zip(URLS, ['文' * 6, '文' * 7, '文' * 20])), cfg)
        self.assertEqual(positions(rows), [(URLS[0], 4, 6), (URLS[1], 0, 3),
            (URLS[1], 6, 7), (URLS[2], 0, 4), (URLS[2], 7, 12)])
        self.assertEqual(consumed(scheduler.state), 15)

    def test_same_pattern_with_one_long_source_or_many_sources(self):
        cfg = fixed_config(offset=7, gap=4, width=9, budget=32)
        full = TextScheduler.create(URLS[:1], cfg, content_seed='fixed')
        split = TextScheduler.create(URLS[:4], cfg, content_seed='fixed')
        a = finish(full, {URLS[0]: '剑' * 100}, cfg)
        b = finish(split, {u: '剑' * n for u, n in zip(URLS, [11, 17, 23, 49])}, cfg)
        offsets = dict(zip(URLS, [0, 11, 28, 51]))
        visited_a = {i for r in a for i in range(r['start'], r['end'])}
        visited_b = {offsets[r['url']] + i for r in b for i in range(r['start'], r['end'])}
        self.assertEqual(visited_a, visited_b)
        self.assertEqual(sum(r['counts']['剑'] for r in a), sum(r['counts']['剑'] for r in b))

    def test_continue_completes_partial_window_without_resetting_gap(self):
        cfg = fixed_config(gap=4, width=5, budget=7)
        scheduler = TextScheduler.create(URLS[:1], cfg, content_seed='fixed')
        texts = {URLS[0]: '文' * 80}
        finish(scheduler, texts, cfg)
        self.assertEqual(coverage(scheduler.state, URLS[0]), [[0, 5], [9, 11]])
        scheduler = TextScheduler(json.loads(json.dumps(scheduler.state)))
        scheduler.continue_search(5)
        finish(scheduler, texts, cfg)
        self.assertEqual(coverage(scheduler.state, URLS[0]), [[0, 5], [9, 14], [18, 20]])
        run = scheduler.execution_snapshot()
        self.assertEqual((run['iteration'], run['budget_chars'], run['scanned_chars'], run['remaining_chars']), (2, 5, 5, 0))
        together = TextScheduler.create(URLS[:1], fixed_config(gap=4, width=5, budget=12), content_seed='fixed')
        finish(together, texts, cfg)
        self.assertEqual(coverage(together.state, URLS[0]), coverage(scheduler.state, URLS[0]))

    def test_pause_keeps_pending_decision_and_does_not_allocate_budget(self):
        cfg = fixed_config(offset=2, gap=3, budget=11)
        scheduler = TextScheduler.create(URLS[:1], cfg, content_seed='fixed')
        text = '文' * 100
        scheduler.register_source(URLS[0], len(text), sha256(text.encode()).hexdigest())
        decision = deepcopy(scheduler.next())
        restored = TextScheduler(json.loads(json.dumps(scheduler.state)))
        self.assertEqual(restored.next(), decision)
        self.assertEqual(restored.execution_snapshot(), scheduler.execution_snapshot())
        self.assertEqual(positions(finish(restored, {URLS[0]: text}, cfg)),
                         positions(finish(scheduler, {URLS[0]: text}, cfg)))

    def test_exhausted_pattern_does_not_claim_unsampled_gaps(self):
        cfg = fixed_config(gap=30, width=5, budget=100)
        scheduler = TextScheduler.create(URLS[:1], cfg, content_seed='fixed')
        finish(scheduler, {URLS[0]: '文' * 12}, cfg)
        self.assertEqual(consumed(scheduler.state), 5)
        self.assertEqual(scheduler.stop_reason(), 'sampling_pattern_exhausted')
        scheduler.continue_search(100)
        self.assertEqual(finish(scheduler, {URLS[0]: '文' * 12}, cfg), [])

    def test_followup_uses_remaining_allowance_when_fixed_targets_exhaust(self):
        cfg = fixed_config(gap=100, width=5, budget=15, focus=True)
        scheduler = TextScheduler.create(URLS[:1], cfg, content_seed='fixed')
        finish(scheduler, {URLS[0]: '剑' + '文' * 30}, cfg)
        self.assertEqual(consumed(scheduler.state, 'fixed_interval'), 5)
        self.assertEqual(consumed(scheduler.state), 15)
        self.assertGreater(consumed(scheduler.state, 'focus_neighbors'), 0)

    def test_multiple_baselines_and_focus_have_one_budget_and_deduped_score(self):
        cfg = fixed_config(gap=7, width=20, budget=200, focus=True, distributed=True)
        scheduler = TextScheduler.create(URLS[:1], cfg, content_seed='composed')
        finish(scheduler, {URLS[0]: '剑' * 1000}, cfg)
        summary = summarize(scheduler.report('job', 1, 'completed', scheduler.stop_reason()), cfg['keywords'], 1)
        self.assertEqual(summary['combined']['scanned_chars'], 200)
        self.assertGreaterEqual(summary['baseline']['scanned_chars'], 120)
        self.assertEqual(summary['ranking_score'], 20000)
        self.assertEqual(summary['baseline_strategies'], ['distributed', 'fixed_interval'])
        self.assertGreater(consumed(scheduler.state, 'distributed'), 0)
        self.assertGreater(consumed(scheduler.state, 'fixed_interval'), 0)
        self.assertEqual(sum(b - a for a, b in coverage(scheduler.state, URLS[0])), 200)

    def test_newly_observed_tail_continues_from_last_local_cursor(self):
        cfg = fixed_config(gap=4, width=5, budget=20)
        scheduler = TextScheduler.create(URLS[:1], cfg, content_seed='fixed')
        finish(scheduler, {URLS[0]: '文' * 7}, cfg)
        scheduler.discover(URLS[0], [URLS[1]])
        scheduler.continue_search(5)
        rows = finish(scheduler, {URLS[1]: '文' * 20}, cfg)
        self.assertEqual(positions(rows), [(URLS[1], 2, 7)])


class ReaderTests(unittest.TestCase):
    def setUp(self):
        self.adapter = Shuku52Adapter()
        self.book = Book(DIRECTORY, '测试书', tuple(URLS[:6]))
        self.cancel = threading.Event()
        self.transport = type('Transport', (), {})()
        self.reader = self.adapter.content_reader(self.transport, self.cancel)

    def test_reader_keeps_prose_in_bounded_memory_and_cache_is_book_scoped(self):
        with patch.object(self.transport, 'fetch', create=True, side_effect=lambda url, **kw: FetchResult('html', url, 200)) as fetch:
            with patch.object(self.adapter, 'body', return_value=Body('正文', ())):
                for url in URLS[:5]:
                    read = self.reader.read(self.book, url)
                    self.assertEqual(read.digest, sha256('正文'.encode()).hexdigest())
                self.assertFalse(self.reader.cached(self.book, URLS[0]))
                self.reader.read(self.book, URLS[4])
                self.assertEqual(fetch.call_count, 5)
                another = Book(DIRECTORY + '-other', '同源但不同书', self.book.body_urls)
                self.assertFalse(self.reader.cached(another, URLS[4]))
                self.reader.clear()
                self.assertFalse(self.reader.cached(self.book, URLS[4]))

    def test_unknown_source_and_unsupported_search_never_make_requests(self):
        with patch.object(self.transport, 'fetch', create=True) as fetch:
            for call, reason in ((lambda: self.reader.read(self.book, URLS[10]), 'content_source_outside_book'),
                                 (lambda: self.reader.search(self.book, '剑'), 'content_search_unsupported')):
                with self.assertRaises(CrawlStop) as error:
                    call()
                self.assertEqual(error.exception.reason, reason)
            fetch.assert_not_called()
        self.assertEqual(self.adapter.content_capabilities, frozenset({'read'}))

    def test_reader_rejects_redirect_and_cancellation(self):
        with patch.object(self.transport, 'fetch', create=True, return_value=FetchResult('', URLS[1], 200)):
            with self.assertRaises(CrawlStop) as error:
                self.reader.read(self.book, URLS[0])
            self.assertEqual(error.exception.reason, 'body_redirect_changed_identity')
        self.cancel.set()
        with self.assertRaises(PauseRequested):
            self.reader.read(self.book, URLS[0])

    def test_304_requires_validators_and_is_not_cached_as_prose(self):
        with patch.object(self.transport, 'fetch', create=True, return_value=FetchResult('', URLS[0], 304)):
            with self.assertRaises(CrawlStop):
                self.reader.read(self.book, URLS[0])
            result = self.reader.read(self.book, URLS[0], validators={'etag': 'v1'})
            self.assertIsNone(result.body)
            self.assertFalse(self.reader.cached(self.book, URLS[0]))


class ModeIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.urls, self.texts, self.calls = URLS[:3], {u: prose(60) for u in URLS[:3]}, []
        self.factory = lambda **kw: MapTransport(self, **kw)
        self.manager = Manager(self.temp.name, transport_factory=self.factory, auto_start=False)
        self.cfg = fixed_config(offset=4, gap=8, width=10, budget=25)
        self.cid = self.manager.create_collection(self.cfg)['id']

    def tearDown(self):
        self.manager.close()
        self.temp.cleanup()

    def run_search(self, seed='fixed'):
        job = self.manager.start_scan(self.cid, content_seed=seed)
        self.manager._run_job(job['id'])
        row = self.manager._get_job(job['id'])
        self.assertEqual(row['status'], 'completed', row['error'])
        return json.loads(self.manager.content.get(DIRECTORY, seed)['state'])

    def test_restart_and_continue_keep_fixed_pattern_and_unique_search(self):
        first = self.run_search()
        self.manager.close()
        self.manager = Manager(self.temp.name, transport_factory=self.factory, auto_start=False)
        second = self.run_search()
        self.assertEqual(second['evidence_refs'][:len(first['evidence_refs'])], first['evidence_refs'])
        self.assertEqual(second['consumed_chars'], 50)
        self.assertEqual(self.manager.db.execute('SELECT COUNT(*) FROM content_searches').fetchone()[0], 1)
        self.assertEqual(self.manager.snapshot()['results'][0]['content_searches'][0]['execution']['scanned_chars'], 25)

    def test_shared_facts_keep_each_seed_cursor_and_attribution(self):
        first = self.run_search('a')
        second = self.run_search('b')
        self.assertEqual([r['id'] for r in first['evidence_refs']], [r['id'] for r in second['evidence_refs']])
        self.assertEqual(second['shared_reused_chars'], 25)
        self.assertEqual(json.loads(self.manager.content.get(DIRECTORY, 'a')['state']), first)
        result = self.manager.snapshot()['results'][0]
        self.assertEqual(result['scanned_chars'], 25)
        self.assertEqual(result['strategy_summary']['baseline_strategies'], ['fixed_interval'])

    def test_same_seed_rejects_pattern_change_but_accepts_budget_and_weights(self):
        self.run_search()
        self.manager.update_collection(self.cid, {'chars_per_book': 10, 'keywords': [
            {'term': '剑', 'weight': 4, 'focused': True}, {'term': '雨', 'weight': 1}]})
        self.assertEqual(self.run_search()['consumed_chars'], 35)
        self.manager.update_collection(self.cid, {'strategies': fixed_config(gap=9)['strategies']})
        with self.assertRaises(ValueError):
            self.manager.start_scan(self.cid, content_seed='fixed')
        self.run_search('new-pattern')

    def test_failed_fact_commit_does_not_advance_pattern(self):
        first = self.run_search()
        with patch.object(self.manager.content, '_fact', side_effect=RuntimeError('simulated write failure')):
            job = self.manager.start_scan(self.cid, content_seed='fixed')
            self.manager._run_job(job['id'])
        self.assertEqual(json.loads(self.manager.content.get(DIRECTORY, 'fixed')['state']), first)


if __name__ == '__main__':
    unittest.main()
