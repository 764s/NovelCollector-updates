"""Character-based strategy integration; all prose and source responses are synthetic."""
import csv
from hashlib import sha256
import io
import json
import tempfile
import unittest
from unittest.mock import patch

from core import Manager, validate_config
from main import report_csv
from text_strategies import TextScheduler, normalize_strategies, summarize, consumed, intervals
from transport import FetchResult, PauseRequested
from test_core import DIRECTORY, body, directory

URLS = [DIRECTORY[:-5] + f'_{i + 1}.html' for i in range(100)]


def config(**changes):
    return validate_config({'name': '字数策略夹具', 'start_url': DIRECTORY,
        'keywords': [{'term': '剑', 'weight': 2, 'focused': True}, {'term': '雨', 'weight': 1}],
        'max_books': 1, 'chars_per_book': 400, 'sample_chars': 20,
        'strategies': [{'id': 'distributed'}, {'id': 'focus_neighbors',
            'params': {'radius_chars': 80, 'miss_chars': 40, 'region_chars': 120}}], **changes})


def prose(length=2000, words=None):
    text = list('文' * length)
    for position, word in (words or {}).items():
        text[position:position + len(word)] = word
    return ''.join(text)


def finish(scheduler, texts, cfg):
    observations = []
    for _ in range(1000):
        pending = scheduler.next()
        if pending is None:
            return observations
        text = texts[pending['url']]
        if pending['start'] is None:
            scheduler.register_source(pending['url'], len(text), sha256(text.encode()).hexdigest())
            continue
        observations.append(scheduler.observe(text, cfg['keywords'], '2026-10-02T00:00:00Z'))
    raise AssertionError('non-terminating strategy schedule')


class StrategyTests(unittest.TestCase):
    def test_single_long_document_has_distributed_fragments_and_exact_char_budget(self):
        cfg = config()
        scheduler = TextScheduler.create(URLS[:1], cfg)
        rows = finish(scheduler, {URLS[0]: prose(10000)}, cfg)
        self.assertEqual(consumed(scheduler.state), 400)
        self.assertTrue(all(row['end'] - row['start'] <= 20 for row in rows))
        self.assertEqual(min(row['start'] for row in rows), 0)
        self.assertEqual(max(row['end'] for row in rows), 10000)
        self.assertTrue(any(4000 <= row['start'] <= 6000 for row in rows))
        self.assertEqual(len({r['url'] for r in rows}), 1)

    def test_focus_adds_character_ranges_near_a_hit(self):
        cfg = config()
        scheduler = TextScheduler.create(URLS[:1], cfg)
        rows = finish(scheduler, {URLS[0]: prose(words={905: '剑', 930: '剑雨'})}, cfg)
        directed = [row for row in rows if 'focus_neighbors' in row['requested_by']]
        self.assertTrue(directed)
        self.assertTrue(any(r['start'] <= 930 < r['end'] for r in directed))
        self.assertTrue(all(825 <= r['start'] < r['end'] <= 986 for r in directed))
        self.assertLessEqual(sum(r['end'] - r['start'] for r in directed), 120)
        self.assertGreaterEqual(consumed(scheduler.state, 'distributed'), 240)
        result = summarize(scheduler.report('job', 1, 'completed'), cfg['keywords'], 1)
        self.assertEqual(result['combined']['counts']['剑'], 2)
        self.assertEqual(result['strategies'][0]['counts']['剑'], 1)
        self.assertEqual(result['ranking_score'], result['strategies'][0]['per_10k_chars'])
        self.assertLess(result['ranking_score'], result['combined']['per_10k_chars'])

    def test_dense_hits_cannot_reset_radius_or_steal_coverage(self):
        cfg = config(chars_per_book=413, sample_chars=37)
        scheduler = TextScheduler.create(URLS[:1], cfg)
        rows = finish(scheduler, {URLS[0]: '剑' * 10000}, cfg)
        self.assertEqual(consumed(scheduler.state), 413)
        self.assertGreaterEqual(consumed(scheduler.state, 'distributed'), 248)
        self.assertEqual(sum(b - a for a, b in intervals((r['start'], r['end']) for r in rows)), 413)
        self.assertTrue(all(r['used_chars'] <= 120 for r in scheduler.state['strategy_state']['focus_neighbors']['regions']))

    def test_neighbors_continue_across_source_boundary_in_characters(self):
        cfg = config()
        scheduler = TextScheduler.create(URLS[:2], cfg)
        rows = finish(scheduler, {URLS[0]: prose(words={1998: '剑'}), URLS[1]: prose(words={15: '剑'})}, cfg)
        near = [r for r in rows if r['url'] == URLS[1] and 'focus_neighbors' in r['requested_by']]
        self.assertTrue(near)
        self.assertTrue(any(r['start'] == 0 and r['end'] <= 20 for r in near))
        self.assertTrue(any(reason['anchor_url'] == URLS[0] for r in near for reason in r['reasons'] if reason['strategy'] == 'focus_neighbors'))
        self.assertEqual(consumed(scheduler.state), 400)

    def test_shared_ranges_are_counted_once_and_useful_spare_chars_are_reused(self):
        cfg = config()
        scheduler = TextScheduler.create(URLS[:2], cfg)
        rows = finish(scheduler, {URLS[0]: prose(25, {20: '剑'}), URLS[1]: prose(1000, {1: '剑'})}, cfg)
        self.assertEqual(consumed(scheduler.state), 400)
        self.assertTrue(any(set(r['requested_by']) == {'distributed', 'focus_neighbors'} for r in rows))
        for url in URLS[:2]:
            selected = [r for r in rows if r['url'] == url]
            self.assertEqual(sum(r['end'] - r['start'] for r in selected),
                             sum(end - start for start, end in intervals((r['start'], r['end']) for r in selected)))

    def test_zero_weight_focus_still_triggers(self):
        cfg = config(keywords=[{'term': '剑', 'weight': 0, 'focused': True}])
        scheduler = TextScheduler.create(URLS[:1], cfg)
        rows = finish(scheduler, {URLS[0]: prose(words={905: '剑'})}, cfg)
        self.assertTrue(any('focus_neighbors' in row['requested_by'] for row in rows))
        self.assertEqual(summarize(scheduler.report('job', 1, 'completed'), cfg['keywords'], 1)['ranking_score'], 0)

    def test_no_hit_or_disabled_strategy_returns_budget_to_distributed_sampling(self):
        for specs in (None, [{'id': 'distributed'}]):
            cfg = config(strategies=specs)
            scheduler = TextScheduler.create(URLS[:1], cfg)
            rows = finish(scheduler, {URLS[0]: prose()}, cfg)
            self.assertEqual(consumed(scheduler.state, 'distributed'), 400)
            self.assertTrue(all(r['requested_by'] == ['distributed'] for r in rows))

    def test_fragment_boundary_match_only_appears_once_both_parts_are_read(self):
        cfg = config(chars_per_book=8, sample_chars=4, keywords=[{'term': '修仙', 'weight': 1, 'focused': True}])
        scheduler = TextScheduler.create(URLS[:1], cfg)
        text = '文文文修仙文文文'
        pending = scheduler.next()
        scheduler.register_source(URLS[0], len(text), sha256(text.encode()).hexdigest())
        scheduler.next()
        scheduler.observe(text, cfg['keywords'], 'now')
        first = summarize(scheduler.report('job', 1), cfg['keywords'], 1)
        self.assertEqual(first['combined']['counts']['修仙'], 0)
        finish(scheduler, {URLS[0]: text}, cfg)
        result = summarize(scheduler.report('job', 1, 'completed'), cfg['keywords'], 1)
        self.assertEqual(result['combined']['counts']['修仙'], 1)
        self.assertTrue(result['regions'])

    def test_serialized_pending_fragment_restores_identical_decisions(self):
        cfg = config()
        texts = {URLS[0]: prose(words={5: '剑'})}
        scheduler = TextScheduler.create(URLS[:1], cfg)
        scheduler.next()
        scheduler.register_source(URLS[0], len(texts[URLS[0]]), sha256(texts[URLS[0]].encode()).hexdigest())
        scheduler.next()
        scheduler.observe(texts[URLS[0]], cfg['keywords'], 'now')
        pending = scheduler.next()
        restored = TextScheduler(json.loads(json.dumps(scheduler.state)))
        self.assertEqual(restored.next(), pending)
        self.assertEqual(finish(scheduler, texts, cfg), finish(restored, texts, cfg))
        self.assertEqual(scheduler.report('job', 1), restored.report('job', 1))

    def test_new_terms_unknown_and_reweight_uses_saved_evidence(self):
        cfg = config()
        scheduler = TextScheduler.create(URLS[:1], cfg)
        finish(scheduler, {URLS[0]: '剑' * 25}, cfg)
        report = scheduler.report('job', 1, 'completed')
        reweighted = summarize(report, [{'term': '剑', 'weight': 9}], 2)
        self.assertEqual(reweighted['ranking_score'], 90000)
        self.assertTrue(reweighted['configuration_changed'])
        changed = summarize(report, [{'term': '新', 'weight': 1}], 2)
        self.assertIsNone(changed['ranking_score'])
        self.assertIsNone(changed['combined']['counts']['新'])

    def test_validation_and_legacy_budget_conversion(self):
        old = validate_config({'keywords': [{'term': '剑'}], 'pages_per_book': 7})
        self.assertEqual(old['chars_per_book'], 1400)
        self.assertNotIn('pages_per_book', old)
        self.assertFalse(old['keywords'][0]['focused'])
        for changes in ({'chars_per_book': 0}, {'sample_chars': 2001}, {'chars_per_book': True},
                        {'keywords': [{'term': '剑', 'focused': 'yes'}]}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                config(**changes)
        for specs in ([], [{'id': 'unknown'}], [{'id': 'distributed', 'enabled': False}],
                      [{'id': 'distributed', 'enabled': 1}], [{'id': 'distributed', 'version': True}],
                      [{'id': 'distributed', 'params': {'pages': 5}}],
                      [{'id': 'distributed'}, {'id': 'focus_neighbors', 'params': {'radius_chars': 0}}]):
            with self.subTest(specs=specs), self.assertRaises(ValueError):
                normalize_strategies(specs)


class MapTransport:
    def __init__(self, fixture, **kwargs):
        self.fixture = fixture
        self.count, self.event = kwargs['request_count'], kwargs['on_request']

    def load_robots(self):
        self.count += 1
        self.event({'count': self.count, 'event': 'started'})

    def fetch(self, url, validators=None):
        self.count += 1
        self.event({'count': self.count, 'event': 'started'})
        self.fixture.calls.append((url, validators))
        if url == DIRECTORY:
            return FetchResult(directory(self.fixture.urls), url, 200)
        return FetchResult(body(self.fixture.texts[url], first=url == self.fixture.urls[0]), url, 200, '"fixture"')

    def close(self):
        pass


class ManagerStrategyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.urls, self.texts, self.calls = URLS[:1], {URLS[0]: prose(words={905: '剑', 930: '剑雨'})}, []
        self.factory = lambda **kw: MapTransport(self, **kw)
        self.manager = Manager(self.temp.name, transport_factory=self.factory, auto_start=False)
        self.collection = self.manager.create_collection(config())

    def tearDown(self):
        self.manager.close()
        self.temp.cleanup()

    def scan(self):
        job = self.manager.start_scan(self.collection['id'])
        self.manager._run_job(job['id'])
        return self.manager.snapshot()

    def pause_inside_source(self):
        original = TextScheduler.observe
        calls = 0
        def interrupt(scheduler, *args):
            nonlocal calls
            calls += 1
            if calls == 5:
                raise PauseRequested(URLS[0])
            return original(scheduler, *args)
        with patch.object(TextScheduler, 'observe', interrupt):
            return self.scan()

    def test_single_document_fetched_once_and_only_budgeted_chars_counted(self):
        result = self.scan()
        self.assertEqual(result['jobs'][0]['status'], 'completed')
        self.assertEqual(result['jobs'][0]['progress']['matched_chars'], 400)
        self.assertEqual(result['jobs'][0]['progress']['body_attempts'], 1)
        self.assertEqual(result['jobs'][0]['progress']['request_count'], 3)
        row = result['results'][0]
        self.assertEqual(row['scanned_chars'], 400)
        self.assertEqual(row['status'], 'sampled')
        self.assertEqual(row['strategy_summary']['combined']['counts'], row['counts'])
        self.assertEqual(row['strategy_summary']['stop_reason'], 'char_budget_reached')
        self.assertEqual(row['pages'][0]['text_length'], 2000)
        self.assertEqual(sum(url == URLS[0] for url, _ in self.calls), 1)
        csv_rows = list(csv.reader(io.StringIO(report_csv([row]).decode('utf-8-sig'))))
        self.assertEqual(json.loads(csv_rows[1][csv_rows[0].index('策略汇总')]), row['strategy_summary'])
        self.assertEqual(json.loads(csv_rows[1][csv_rows[0].index('搜书来源')]), [])
        for table in ('pages', 'books', 'jobs'):
            data = [tuple(record) for record in self.manager.db.execute('SELECT * FROM ' + table)]
            self.assertNotIn('文' * 80, repr(data))

    def test_pause_restart_restores_character_offset_and_budget(self):
        first = self.pause_inside_source()
        job = first['jobs'][0]
        self.assertEqual(job['status'], 'paused')
        saved = json.loads(self.manager._get_job(job['id'])['state'])
        self.assertIsNotNone(saved['text_plan']['pending']['start'])
        self.manager.close()
        self.manager = Manager(self.temp.name, transport_factory=self.factory, auto_start=False)
        self.manager.resume_job(job['id'])
        self.manager._run_job(job['id'])
        result = self.manager.snapshot()
        self.assertEqual(result['jobs'][0]['status'], 'completed')
        self.assertEqual(result['jobs'][0]['progress']['matched_chars'], 400)
        self.assertEqual(result['results'][0]['scanned_chars'], 400)
        self.assertEqual(sum(url == URLS[0] for url, _ in self.calls), 2)

    def test_source_changed_while_paused_stops_without_mixing_offsets(self):
        first = self.pause_inside_source()
        count = first['results'][0]['scanned_chars']
        job = first['jobs'][0]
        self.texts[URLS[0]] = '改' + self.texts[URLS[0]][1:]
        self.manager.resume_job(job['id'])
        self.manager._run_job(job['id'])
        result = self.manager.snapshot()
        self.assertEqual(result['jobs'][0]['error'], 'source_changed_during_scan')
        self.assertEqual(result['results'][0]['scanned_chars'], count)

    def test_crashed_job_summary_uses_recovered_status(self):
        first = self.pause_inside_source()
        job = first['jobs'][0]
        self.manager.db.execute("UPDATE jobs SET status='running' WHERE id=?", (job['id'],))
        self.manager.db.commit()
        self.manager.close()
        self.manager = Manager(self.temp.name, transport_factory=self.factory, auto_start=False)
        result = self.manager.snapshot()
        self.assertEqual(result['jobs'][0]['status'], 'paused')
        self.assertEqual(result['results'][0]['strategy_summary']['status'], 'paused')
        self.assertEqual(result['results'][0]['strategy_summary']['stop_reason'], 'interrupted_restart')

    def test_later_scan_extends_character_coverage_without_counting_duplicates(self):
        first = self.scan()['results'][0]
        second = self.scan()['results'][0]
        self.assertGreater(second['scanned_chars'], first['scanned_chars'])
        self.assertLessEqual(second['scanned_chars'], 800)
        self.assertEqual(second['strategy_summary']['combined']['scanned_chars'], 400)

    def test_body_seed_starts_at_first_char_of_selected_source(self):
        self.manager.update_collection(self.collection['id'], {'start_url': URLS[0]})
        result = self.scan()
        self.assertEqual(result['jobs'][0]['status'], 'completed')
        self.assertEqual(sum(url == URLS[0] for url, _ in self.calls), 1)
        self.assertEqual(result['results'][0]['strategy_summary']['evidence'][0]['start'], 0)

    def test_legacy_paused_job_keeps_its_original_queue(self):
        old_config = {'keywords': [{'term': '剑', 'weight': 1}], 'name': '旧任务',
                      'start_url': DIRECTORY, 'max_books': 1, 'pages_per_book': 2}
        job = self.manager.start_scan(self.collection['id'])
        state = json.loads(self.manager._get_job(job['id'])['state'])
        state.pop('sampling_version')
        state.update(stage='body', current_book={'url': DIRECTORY, 'title': '旧任务', 'body_urls': self.urls},
                     directories=[DIRECTORY], selected_pages=self.urls, page_index=0)
        self.manager._put_book(self.collection['id'], DIRECTORY, {'body_urls': self.urls, 'title': '旧任务'})
        self.manager.db.execute('UPDATE jobs SET config=? WHERE id=?', (json.dumps(old_config), job['id']))
        self.manager._save_state(job['id'], state)
        self.manager._run_job(job['id'])
        result = self.manager.snapshot()
        self.assertEqual(result['jobs'][0]['status'], 'completed')
        self.assertIsNone(result['results'][0]['strategy_summary'])
        self.assertIsNone(result['results'][0]['scanned_chars'])


if __name__ == '__main__':
    unittest.main()
