"""Flat book lists, replaceable observations and one positional seed per list.

No prose lives here. Entries and selections reference the global book context;
completed evaluations contain the content search's existing evidence references.
All writes participate in the manager's lock and SQLite transaction.
"""
from hashlib import sha256
from datetime import datetime
import json
import uuid

from content_search import binding, encode
from transport import utcnow


def board_id(board):
    return sha256(encode([board['type'], board['base_url'], board['keys']]).encode()).hexdigest()


def seed_config(value=None):
    value = {} if value is None else value
    if not isinstance(value, dict) or set(value) - {'offset', 'interval'}:
        raise ValueError('榜种子只接受开始偏移和固定间隔')
    result = {}
    for key in ('offset', 'interval'):
        number = value.get(key, 0)
        if type(number) is not int or not 0 <= number <= 1_000_000:
            raise ValueError('开始偏移和固定间隔须为 0–1000000 的整数')
        result[key] = number
    return result


class BoardStore:
    def __init__(self, db):
        self.db = db
        db.executescript('''
        CREATE TABLE IF NOT EXISTS discovery_boards(
            id TEXT PRIMARY KEY, type TEXT NOT NULL, base_url TEXT NOT NULL,
            keys TEXT NOT NULL, current_version TEXT, created_at TEXT NOT NULL,
            UNIQUE(type,base_url,keys));
        CREATE TABLE IF NOT EXISTS discovery_versions(
            id TEXT PRIMARY KEY, board_id TEXT NOT NULL REFERENCES discovery_boards(id),
            state TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS discovery_entries(
            version_id TEXT NOT NULL REFERENCES discovery_versions(id),
            position INTEGER NOT NULL, directory_url TEXT NOT NULL,
            source_url TEXT NOT NULL, PRIMARY KEY(version_id,position));
        CREATE TABLE IF NOT EXISTS discovery_context(
            board_id TEXT NOT NULL REFERENCES discovery_boards(id),
            directory_url TEXT NOT NULL, first_seen TEXT NOT NULL, last_seen TEXT NOT NULL,
            PRIMARY KEY(board_id,directory_url));
        CREATE TABLE IF NOT EXISTS discovery_searches(
            board_id TEXT PRIMARY KEY REFERENCES discovery_boards(id),
            config TEXT NOT NULL, state TEXT NOT NULL, job_id TEXT NOT NULL,
            status TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS discovery_selections(
            board_id TEXT NOT NULL REFERENCES discovery_boards(id),
            directory_url TEXT NOT NULL, version_id TEXT NOT NULL,
            position INTEGER NOT NULL, selected_at TEXT NOT NULL,
            PRIMARY KEY(board_id,directory_url));
        CREATE TABLE IF NOT EXISTS discovery_evaluations(
            id TEXT PRIMARY KEY, directory_url TEXT NOT NULL, profile TEXT NOT NULL,
            data TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS discovery_evaluation_profile
            ON discovery_evaluations(directory_url,profile,created_at);
        ''')

    def search(self, key):
        row = self.db.execute('SELECT * FROM discovery_searches WHERE board_id=?', (key,)).fetchone()
        return {**dict(row), 'config': json.loads(row['config']), 'state': json.loads(row['state'])} if row else None

    def version(self, key):
        row = self.db.execute('SELECT * FROM discovery_versions WHERE id=?', (key,)).fetchone()
        return {**dict(row), 'state': json.loads(row['state'])} if row else None

    def save_search(self, search):
        self.db.execute('UPDATE discovery_searches SET state=?,job_id=?,status=?,updated_at=? WHERE board_id=?',
                        (encode(search['state']), search['job_id'], search['status'], utcnow(), search['board_id']))

    def open(self, board, config, job_id, refresh=False):
        key, now = board_id(board), utcnow()
        search = self.search(key)
        if search:
            if search['config'] != config:
                raise ValueError('此榜只保留一个种子；已有偏移 %s、间隔 %s，请沿用这组参数' %
                                 (search['config']['offset'], search['config']['interval']))
            job = self.db.execute('SELECT status FROM jobs WHERE id=?', (search['job_id'],)).fetchone()
            if job and job[0] in ('paused', 'running', 'pausing', 'queued'):
                raise ValueError('此榜有未完成任务，请恢复原任务后再继续或刷新')
        self.db.execute('INSERT OR IGNORE INTO discovery_boards VALUES(?,?,?,?,NULL,?)',
                        (key, board['type'], board['base_url'], board['keys'], now))
        current = self.db.execute('SELECT current_version FROM discovery_boards WHERE id=?', (key,)).fetchone()[0]
        version = self.version(current) if current else None
        # Continue within a local day; an explicit refresh or a later date replaces
        # only the list observation. Paused jobs never run this branch again.
        if refresh or not version or (datetime.fromisoformat(version['created_at']).astimezone().date()
                                     != datetime.fromisoformat(now).astimezone().date()):
            if current:
                self.db.execute("UPDATE discovery_versions SET status='obsolete' WHERE id=?", (current,))
            current = uuid.uuid4().hex
            self.db.execute('INSERT INTO discovery_versions VALUES(?,?,?,?,?)',
                            (current, key, encode({'request': None, 'reader': {}, 'count': 0,
                                                  'fetched': [], 'exhausted': False}), 'current', now))
            self.db.execute('UPDATE discovery_boards SET current_version=? WHERE id=?', (current, key))
        state = search['state'] if search else {'iteration': 0, 'pending': None}
        if state.get('version_id') != current:
            state.update(version_id=current, next_position=config['offset'])
        state['iteration'] += 1
        self.db.execute('''INSERT INTO discovery_searches VALUES(?,?,?,?,?,?)
            ON CONFLICT(board_id) DO UPDATE SET state=excluded.state,job_id=excluded.job_id,
            status=excluded.status,updated_at=excluded.updated_at''',
            (key, encode(config), encode(state), job_id, 'running', now))
        return key

    def next_entry(self, key):
        search = self.search(key)
        state = search['state']
        if state.get('pending'):
            return state['pending']
        version = self.version(state['version_id'])
        while state['next_position'] < version['state']['count']:
            position = state['next_position']
            state['next_position'] += search['config']['interval'] + 1
            row = self.db.execute('SELECT * FROM discovery_entries WHERE version_id=? AND position=?',
                                  (state['version_id'], position)).fetchone()
            if row is None:
                raise ValueError('榜单书目引用缺失')
            # Count positions BEFORE checking previous selections. Shared books
            # and repeated entries must not change this arithmetic progression.
            if self.db.execute('SELECT 1 FROM discovery_selections WHERE board_id=? AND directory_url=?',
                               (key, row['directory_url'])).fetchone():
                continue
            state['pending'] = {**dict(row), 'board_id': key}
            self.save_search(search)
            return state['pending']
        self.save_search(search)
        return None

    def observe(self, key, request, reader, books, next_request, source_url):
        search = self.search(key)
        version = self.version(search['state']['version_id'])
        state, now = version['state'], utcnow()
        fingerprint = sha256(encode(request).encode()).hexdigest()
        if fingerprint in state['fetched']:
            raise ValueError('榜单翻页形成循环')
        for book in books:
            url = book['directory_url']
            old = self.db.execute('SELECT data FROM content_contexts WHERE directory_url=?', (url,)).fetchone()
            metadata = json.loads(old[0]) if old else {'directory_url': url, 'body_urls': []}
            # An article's "read this book" anchor is not a better title than
            # one already obtained from the book's own directory.
            if not metadata.get('body_urls') or not metadata.get('title'):
                metadata['title'] = book['title'] or metadata.get('title', '')
            self.db.execute('INSERT OR REPLACE INTO content_contexts VALUES(?,?)', (url, encode(metadata)))
            self.db.execute('INSERT INTO discovery_entries VALUES(?,?,?,?)',
                            (version['id'], state['count'], url, source_url))
            state['count'] += 1
            self.db.execute('''INSERT INTO discovery_context VALUES(?,?,?,?)
                ON CONFLICT(board_id,directory_url) DO UPDATE SET last_seen=excluded.last_seen''',
                (key, url, now, now))
        state.update(reader=reader, request=next_request, exhausted=next_request is None)
        state['fetched'].append(fingerprint)
        if next_request and sha256(encode(next_request).encode()).hexdigest() in state['fetched']:
            # Keep the successfully observed facts, but never call this exhausted.
            state['cycle'] = True
        self.db.execute('UPDATE discovery_versions SET state=? WHERE id=?', (encode(state), version['id']))

    def complete(self, key):
        search = self.search(key)
        pending = search['state']['pending']
        if pending is None:
            raise ValueError('榜种子没有待处理书目')
        self.db.execute('INSERT OR IGNORE INTO discovery_selections VALUES(?,?,?,?,?)',
                        (key, pending['directory_url'], pending['version_id'], pending['position'], utcnow()))
        search['state']['pending'] = None
        self.save_search(search)

    def finish(self, key, job_id, status):
        self.db.execute('UPDATE discovery_searches SET status=?,updated_at=? WHERE board_id=? AND job_id=?',
                        (status, utcnow(), key, job_id))

    @staticmethod
    def profile(config, start_body=None):
        return sha256(encode(binding(config, start_body)).encode()).hexdigest()

    def remember(self, directory, config, record):
        if not record.get('strategy_run', {}).get('content_seed'):
            return
        value = {k: v for k, v in record.items() if k not in
                 ('board_source', 'evaluation_ref', 'discovery_reused', 'discovered_job_id')}
        value.update(snippets=[], snippet_sources=[])
        key = sha256(encode(value).encode()).hexdigest()
        self.db.execute('INSERT OR IGNORE INTO discovery_evaluations VALUES(?,?,?,?,?)',
                        (key, directory, self.profile(config, record['strategy_run'].get('seed')), encode(value), utcnow()))

    def reusable(self, directory, config):
        rows = self.db.execute('''SELECT id,data FROM discovery_evaluations
            WHERE directory_url=? AND profile=? ORDER BY created_at DESC''', (directory, self.profile(config)))
        for row in rows:
            data = json.loads(row['data'])
            run = data['strategy_run']
            if run.get('status') == 'completed' and (run.get('stop_reason') in ('scope_exhausted', 'sampling_pattern_exhausted')
                    or run.get('limit', 0) >= config['chars_per_book']):
                return row['id']
        return None

    def resolve(self, record):
        if not record.get('evaluation_ref'):
            return record
        row = self.db.execute('SELECT data FROM discovery_evaluations WHERE id=?', (record['evaluation_ref'],)).fetchone()
        if row is None:
            raise ValueError('书目检测引用缺失')
        return {**json.loads(row[0]), **record}

    def summaries(self):
        result = []
        for row in self.db.execute('SELECT * FROM discovery_boards ORDER BY created_at'):
            search, version = self.search(row['id']), self.version(row['current_version'])
            result.append({**dict(row), 'seed': search['config'] if search else seed_config(),
                'status': search['status'] if search else 'queued', 'job_id': search['job_id'] if search else None,
                'next_position': search['state']['next_position'] if search else 0,
                'iteration': search['state']['iteration'] if search else 0,
                'observed_books': version['state']['count'] if version else 0,
                'exhausted': version['state']['exhausted'] if version else False,
                'observed_at': version['created_at'] if version else None,
                'selected_books': self.db.execute('SELECT COUNT(*) FROM discovery_selections WHERE board_id=?', (row['id'],)).fetchone()[0],
                'known_books': self.db.execute('SELECT COUNT(*) FROM discovery_context WHERE board_id=?', (row['id'],)).fetchone()[0]})
        return result
