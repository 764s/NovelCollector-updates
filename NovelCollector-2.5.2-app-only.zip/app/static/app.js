'use strict';
const $ = id => document.getElementById(id);
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const params = new URLSearchParams(location.hash.slice(1));
if (params.get('token')) { sessionStorage.setItem('novel-token', params.get('token')); history.replaceState(null, '', location.pathname); }
const token = sessionStorage.getItem('novel-token') || '';
let state = null, currentId = '', dirty = false, tab = 'collect', busy = false, stopped = false, initial = true;
let chosen = new Map(), checkedDownloads = new Set(), openDetails = new Set(), pageLimits = new Map();
const statusNames = {running:'正在执行',pausing:'正在暂停',paused:'已暂停',completed:'已完成',stopped:'已停止',failed:'中断',blocked:'访问停止',interrupted:'中断',queued:'排队中',counted:'已计数',sampled:'已扫描样本',unscanned:'未扫描',requires_rescan:'新增词待扫描',unchanged_304:'来源未修改',unchanged_hash:'正文哈希未变',downloaded:'已下载',updated:'已更新'};
const reasonNames = {http_403_access_stop:'来源拒绝访问（403），已停止',http_429_access_stop:'来源限流（429），已停止',captcha_or_challenge_stop:'遇到验证码或访问挑战，已停止',robots_denied_or_unavailable:'来源规则不允许访问或无法读取',robots_denied:'来源 robots 规则禁止访问',network_error_stop:'网络中断，进度已保留',dns_error_stop:'无法解析来源域名，进度已保留',request_budget_reached:'已达到本次请求上限',interrupted_restart:'上次程序中断，已恢复为暂停',unknown_template:'无法可靠识别正文模板',source_changed_during_scan:'已检测正文发生变化，请换用新内容种子',content_seed_conflict:'此书的同名内容种子存在未完成任务或配置不同，请恢复原任务或换新种子',board_pagination_cycle:'榜单下一页形成循环，已保留进度并停止'};
const reason = s => reasonNames[s] || s;
const status = s => statusNames[s] || s || '待处理';
const date = s => { if(!s) return '未知'; const d=new Date(s); return Number.isNaN(d.getTime())?s:d.toLocaleString('zh-CN',{hour12:false}); };
const num = n => Number(n || 0).toLocaleString('zh-CN',{maximumFractionDigits:2});
function notify(message, error=false) { $('notice').textContent=message; $('notice').className=error?'error':''; $('notice').hidden=false; }
async function api(path, body) {
  const response = await fetch(path,{method:body===undefined?'GET':'POST',headers:{'X-App-Token':token,...(body===undefined?{}:{'Content-Type':'application/json'})},body:body===undefined?undefined:JSON.stringify(body)});
  if(!response.ok){let data;try{data=await response.json()}catch{data={error:'本地服务请求失败'}}throw Error(data.error || '操作失败')}
  return response.json();
}
async function action(fn) {
  if(busy) return;
  busy=true;
  try { await fn(); await refresh(); } catch(e) { notify(e.message,true); } finally {busy=false;}
}
function keywordRow(term='',weight=1,focused=false) {
  const row=document.createElement('div');row.className='keyword-row';
  row.innerHTML=`<input class="term" aria-label="关键词" maxlength="64" placeholder="字面关键词" value="${esc(term)}" required><input class="weight" aria-label="关键词权重" type="number" min="0" max="100" step="any" value="${esc(weight)}" required><button type="button" class="remove" aria-label="删除关键词">×</button><label class="focus-toggle"><input class="focused" type="checkbox" ${focused?'checked':''}>特别关注 · 命中后扩展扫描</label>`;
  row.querySelector('.remove').onclick=()=>{if($('keyword-editor').children.length<=1){notify('至少保留一个关键词',true);return}row.remove();dirty=true};
  $('keyword-editor').append(row);
}
function loadConfig(collection) {
  dirty=false;currentId=collection?.id||'';
  $('collection-select').value=currentId;
  $('name').value=collection?.name || '修仙正文搜集';$('start-url').value=collection?.start_url || 'https://www.52shuku.net/';
  $('start-url').disabled=!!(collection && state?.results.some(r=>r.collection_id===collection.id));
  $('start-url').title=$('start-url').disabled?'已有结果；更换起始页面请新建搜集器':'';
  const legacyList=collection && ['https://www.52shuku.net/','https://www.52shuku.net/wuxia/'].includes(collection.start_url);
  const legacyPaused=collectionJobs().some(j=>j.status==='paused'&&!j.board_id);
  $('source-type').value=collection?.board?.type || ((!collection||(legacyList&&!legacyPaused))?'category':'direct');
  $('board-keys').value=collection?.board?.keys || '';
  $('book-offset').value=collection?.discovery_seed?.offset ?? 0;
  $('book-interval').value=collection?.discovery_seed?.interval ?? 0;
  $('max-books').value=collection?.max_books||5;$('chars-per-book').value=collection?.chars_per_book||4000;$('sample-chars').value=collection?.sample_chars||200;
  $('keyword-editor').replaceChildren();(collection?.keywords||[{term:'修仙',weight:1}]).forEach(k=>keywordRow(k.term,k.weight,k.focused));
  const focus=collection?.strategies?.find(s=>s.id==='focus_neighbors');
  const fixed=collection?.strategies?.find(s=>s.id==='fixed_interval'&&s.enabled);
  const distributed=collection?.strategies?.find(s=>s.id==='distributed'&&s.enabled);
  $('content-sampling').value=fixed?(distributed?'combined':'fixed_interval'):'distributed';
  $('content-offset').value=fixed?.params?.offset_chars??0;
  $('content-gap').value=fixed?.params?.gap_chars??0;
  $('focus-strategy').checked=focus?.enabled??true;
  $('focus-distance').value=focus?.params?.radius_chars??800;
  $('focus-misses').value=focus?.params?.miss_chars??400;
  $('focus-budget').value=focus?.params?.region_chars??1200;
  $('content-seed').value=collectionJobs().find(j=>j.content_seed)?.content_seed||'default';
  renderContentControls();renderBoardControls();renderResults();renderActive();
}
function renderContentControls(){
  const fixed=$('content-sampling').value!=='distributed';
  $('fixed-sampling-settings').hidden=!fixed;
  $('content-offset').disabled=$('content-gap').disabled=!fixed;
}
function contentStrategies(){
  const mode=$('content-sampling').value;
  return [{id:'distributed',enabled:mode!=='fixed_interval'},
    {id:'fixed_interval',enabled:mode!=='distributed',params:{offset_chars:Number($('content-offset').value),gap_chars:Number($('content-gap').value)}},
    {id:'focus_neighbors',enabled:$('focus-strategy').checked,params:{radius_chars:Number($('focus-distance').value),miss_chars:Number($('focus-misses').value),region_chars:Number($('focus-budget').value)}}];
}
function currentBoard(){return (state?.boards||[]).find(b=>b.type===$('source-type').value&&b.base_url===$('start-url').value.trim()&&b.keys===$('board-keys').value)}
function renderBoardControls(){
  const enabled=$('source-type').value!=='direct', board=currentBoard();
  $('board-settings').hidden=!enabled;$('board-key-field').hidden=!enabled;
  $('board-keys').required=enabled&&$('source-type').value==='site_search';
  $('refresh-board').hidden=!enabled;
  $('start-url-label').textContent=enabled?'榜基础地址':'小说目录 / 正文地址';
  $('source-help').textContent=$('source-type').value==='site_search'?'填写包含网站自带搜索表单的页面地址；搜索词与正文检测词分别设置。':enabled?'填写分类、榜单、tag 或收录文章的实际地址。当前正文适配范围为 52书库武侠玄幻书目。':'直接继续一本小说的正文检测。';
  const locked=!!(currentId&&state?.results.some(r=>r.collection_id===currentId));
  $('source-type').disabled=locked;$('board-keys').disabled=locked;
  for(const [id,key] of [['book-offset','offset'],['book-interval','interval']]){
    $(id).disabled=!!board;
    if(board)$(id).value=board.seed[key];
  }
  $('board-progress').textContent=board?`此榜共享一个种子 · 偏移 ${board.seed.offset}，间隔 ${board.seed.interval} · 累计选取 ${board.selected_books} 本 · 当前版本已读取 ${board.observed_books} 个位置${board.exhausted?' · 列表已读完':''}。`:'0 / 0 表示从第一本连续选取。间隔 2 表示每选一本跳过两本；跨分页连续计数。';
}
function config() {
  if(!$('config-form').reportValidity()) throw Error('请检查输入字段');
  return {name:$('name').value.trim(),start_url:$('start-url').value.trim(),board:$('source-type').value==='direct'?null:{type:$('source-type').value,base_url:$('start-url').value.trim(),keys:$('board-keys').value},discovery_seed:{offset:Number($('book-offset').value),interval:Number($('book-interval').value)},keywords:[...$('keyword-editor').children].map(row=>({term:row.querySelector('.term').value,weight:Number(row.querySelector('.weight').value),focused:row.querySelector('.focused').checked})),max_books:Number($('max-books').value),chars_per_book:Number($('chars-per-book').value),sample_chars:Number($('sample-chars').value),strategies:contentStrategies()};
}
async function saveConfig(){const data=config();const saved=await api(currentId?'/api/collections/update':'/api/collections',currentId?{id:currentId,config:data}:data);currentId=saved.id;$('start-url').value=saved.start_url;dirty=false;return saved;}
function showTab(next) {
  tab=next;document.querySelectorAll('.nav').forEach(b=>b.classList.toggle('active',b.dataset.tab===next));
  ['collect','downloads','history'].forEach(t=>$(t+'-view').hidden=t!==next);
  $('view-title').textContent={collect:'搜集与评分',downloads:'下载管理器',history:'执行记录'}[next];
  if(next==='downloads'){renderSelection();renderDownloads()} 
}
function collectionJobs(){return state?.jobs.filter(j=>j.collection_id===currentId)||[]}
function jobBanner(job, download=false) {
  if(!job)return '';
  const p=job.progress||{};const detail=download?`${job.completed?.length||0} / ${job.items?.length||0} 页 · 新写入 ${job.downloaded||0} · 未变 ${job.unchanged||0} · 请求 ${job.request_count||0}/64`:`本次已选取 ${num(p.books_done)} / ${num(p.max_books)} 本 · 共享检测复用 ${num(p.shared_reused_books)} 本 · 已检测 ${num(p.matched_chars)} 字 · 来源读取 ${p.body_attempts||0}/100 · 请求 ${p.request_count||0}/160 · 复用 ${Number(p.reused_304||0)+Number(p.reused_hash||0)}`;
  let button='';
  if(job.status==='running')button=`<button class="button small secondary" data-action="${download?'download-':'scan-'}pause" data-id="${job.id}">暂停</button>`;
  if(job.status==='paused'||(download&&job.status==='interrupted'))button=`<button class="button small secondary" data-action="${download?'download-':'scan-'}resume" data-id="${job.id}">${download?'继续':'恢复任务'}</button>`;
  return `<div class="job-banner ${['stopped','failed','blocked','interrupted'].includes(job.status)?'blocked':''}"><div><strong>${download?'下载检查':'搜集任务'} · ${esc(status(job.status))}${job.content_seed?' · 内容种子 '+esc(job.content_seed):''}</strong><p>${esc(detail)}${p.shared_reused_chars?' · 共享证据复用 '+num(p.shared_reused_chars)+' 字':''}</p>${job.error?`<p>${esc(reason(job.error))}</p>`:''}${job.status==='running'&&p.current_url?`<p>${esc(p.current_url)}</p>`:''}${download&&job.message?`<p>${esc(job.message)}</p>`:''}</div>${button}</div>`;
}
function renderActive(){if(!state)return;const jobs=collectionJobs(),board=currentBoard();const shared=board?state.jobs.find(j=>j.id===board.job_id):null;const job=jobs.find(j=>j.id===state.active_job)||(shared?.status==='paused'?shared:null)||jobs.find(j=>j.content_seed===$('content-seed').value.trim()&&j.status==='paused')||jobs[0];$('active-job').innerHTML=jobBanner(job);const active=!!state.active_job||!!state.downloads.active_job;$('start-scan').disabled=active;$('refresh-board').disabled=active||shared?.status==='paused';$('save-config').disabled=jobs.some(j=>['running','pausing'].includes(j.status));$('start-scan').textContent=$('source-type').value==='direct'?'开始 / 继续内容种子':'开始 / 继续搜书';}
function boardSummary(row){
  const sources=(row.board_sources||[]).map(s=>`<span class="chip">${esc(state.board_types?.[s.type]||s.type)}${s.keys?' · '+esc(s.keys):''} · 选取时第 ${num(s.position+1)} 本</span>`).join('');
  return sources||row.discovery_reused?`<div class="board-summary"><div class="chips">${sources}</div>${row.discovery_reused?'<p class="field-help">已引用共享的正文检测结果；本次搜书未重新读取正文，检测时间沿用原记录。</p>':''}</div>`:'';
}
function allCurrentResults(){return state?.results.filter(r=>r.collection_id===currentId)||[]}
function pageKey(row,page){return row.directory_url+'|'+page.url}
const strategyNames={distributed:'分布采样',fixed_interval:'固定间隔采样',focus_neighbors:'关注词扩展扫描'};
const strategyStatus={disabled:'未启用',no_focus_terms:'未设置关注词',no_focus_hit:'本次样本未命中关注词'};
const scanStopNames={char_budget_reached:'本书匹配字数用尽',scope_exhausted:'已覆盖本次范围',sampling_pattern_exhausted:'固定采样位置已用尽',region_budget_reached:'区域追加额度用尽',neighborhood_complete:'已到字数范围或连续未命中',pending:'待继续扫描'};
function strategySummary(row){
  const summary=row.strategy_summary;
  if(!summary)return '<p class="field-help">尚无适用于此搜集器的正文检测记录，可使用当前内容种子检测此书。</p>';
  const strategies=summary.strategies.map(s=>`<span class="chip">${esc(strategyNames[s.id]||s.name)}：${num(s.scanned_chars)} 字 · ${num(s.fragments)} 段${strategyStatus[s.status]?' · '+esc(strategyStatus[s.status]):''}</span>`).join('');
  const regions=summary.regions.map(r=>`<li>${r.context_ref?'共享关注线索 · ':''}${r.anchors.map(a=>`<a href="${esc(a.url)}" target="_blank" rel="noopener noreferrer">${esc(a.terms.join('、'))} · 来源正文第 ${num(a.start+1)}–${num(a.end)} 字</a>`).join('；')} · 周边追加扫描 ${num(r.used_chars)} 字 · ${esc(scanStopNames[r.stop_reason]||r.stop_reason)}</li>`).join('');
  const seedInfo=summary.content_seed?`内容种子 ${esc(summary.content_seed)} · 第 ${num(summary.iteration)} 次执行 · 本次 ${num(summary.iteration_scanned_chars)} / ${num(summary.iteration_budget)} 字`:'最近一次扫描';
  const seeds=(row.content_searches||[]).map(s=>`<div class="seed-history-row"><span>${esc(s.seed)} · ${esc(status(s.status))} · 累计 ${num(s.scanned_chars)} 字 · 第 ${num(s.iteration)} 次</span><button class="text-button" data-content-seed="${esc(s.seed)}">选用此种子</button>${['completed','stopped','failed'].includes(s.status)?`<button class="text-button" data-continue-seed="${esc(s.seed)}" data-directory="${esc(row.directory_url)}" ${state.active_job||state.downloads.active_job?'disabled':''}>继续此书</button>`:''}${s.status==='paused'?`<button class="text-button" data-action="scan-resume" data-id="${esc(s.job_id)}" ${state.active_job||state.downloads.active_job?'disabled':''}>恢复原任务</button>`:''}</div>`).join('');
  return `<div class="strategy-summary"><p>${seedInfo} · ${esc(status(summary.status))}${summary.stop_reason?' · '+esc(scanStopNames[summary.stop_reason]||reason(summary.stop_reason)):''} · ${summary.content_seed?'种子累计':'去重检测'} ${num(summary.combined.scanned_chars)} 字${summary.configuration_changed?' · 配置已变更，采样位置来自上次任务':''}</p>${summary.stale_sources?.length?'<p class="error">此种子引用的正文版本已有变化，请换用新种子；历史证据保留。</p>':''}<div class="chips">${strategies}</div>${regions?`<ul class="focus-regions">${regions}</ul>`:''}${seeds?`<details data-key="${esc(row.directory_url+':seeds')}" ${openDetails.has(row.directory_url+':seeds')?'open':''}><summary>此书的内容种子 · ${row.content_searches.length} 个</summary>${seeds}</details>`:''}<p class="field-help">共享上下文按区间去重；各内容种子分别汇总策略结果。排序使用最近执行种子的基础样本每万字加权次数，不推算全书。</p></div>`;
}
function renderResults(){
  if(!state)return;
  document.querySelectorAll('#results details[open]').forEach(d=>openDetails.add(d.dataset.key));
  const rows=allCurrentResults();const matches=rows.filter(r=>Number(r.matching_pages)>0).length;
  $('result-summary').textContent=rows.length?`${rows.length} 本书 · ${matches} 本命中 · 按基础样本每万字评分排序`:(currentId?'还没有结果，开始一次有界搜集':'保存搜集器后开始扫描');
  $('export-csv').disabled=$('export-json').disabled=!rows.length;
  $('result-stats').innerHTML=rows.length?`<div class="stat"><strong>${num(matches)}</strong><span>样本命中书目</span></div><div class="stat"><strong>${num(rows.reduce((a,r)=>a+(r.scanned_chars||0),0))}</strong><span>已知累计检测字数</span></div><div class="stat"><strong>${num(rows.reduce((a,r)=>a+r.matching_pages,0))}</strong><span>命中来源</span></div>`:'';
  if(!rows.length){$('results').innerHTML='<div class="empty-state"><strong>把关键词变成可追溯的链接集</strong>设置字面关键词与权重，再开始搜集<br>命中次数、扫描范围和检查时间都会保留</div>';return}
  $('results').innerHTML=rows.map((r,index)=>{
    const key=r.directory_url;
    const chips=Object.entries(r.counts||{}).map(([k,v])=>`<span class="chip ${v===null?'warn':v>0?'hit':''}">${esc(k)} <b>${v===null?'待扫描':num(v)+' 次'}</b></span>`).join('');
    const pages=r.pages||[]; const limit=pageLimits.get(key)||20;
    return `<article class="result-card"><div class="result-top"><span class="rank">${String(index+1).padStart(2,'0')}</span><div><h3><a href="${esc(r.directory_url)}" target="_blank" rel="noopener noreferrer">${esc(r.title||'待识别书目')}</a></h3><a class="result-link" href="${esc(r.directory_url)}" target="_blank" rel="noopener noreferrer">${esc(r.directory_url)}</a></div><div class="score"><b>${r.ranking_score==null?'—':num(r.ranking_score)}</b><span>${r.ranking_score==null?'待取得基础样本':'基础样本 / 万字'}</span></div></div><div class="chips">${chips}<span class="chip">累计加权次数 ${r.score===null?'待扫描':num(r.score)}</span><span class="chip">${r.scanned_chars==null?'历史字数未知':'累计检测 '+num(r.scanned_chars)+' 字'} · ${num(r.scanned_pages)} 个来源</span>${r.requires_rescan?'<span class="chip warn">新增词尚未完整覆盖</span>':''}</div><div class="metadata"><span>来源更新：${esc(date(r.source_updated_at))}</span><span>目录检查：${esc(date(r.checked_at))}</span></div>${boardSummary(r)}${strategySummary(r)}<button class="text-button" data-scan-book="${esc(r.directory_url)}" ${state.active_job||state.downloads.active_job?'disabled':''}>用当前内容种子检测此书</button><details data-key="${esc(key)}" ${openDetails.has(key)?'open':''}><summary>命中与来源明细 · 可选择下载</summary>${(r.snippets||[]).map(s=>`<p class="snippet">${esc(typeof s==='string'?s:s.text||s.snippet||'')}</p>`).join('')}<p class="field-help">勾选仅加入下载管理器，不会立即下载。未扫描网页不等于未命中。正文检查时间以每页记录为准。</p><div class="pages">${pages.slice(0,limit).map(p=>`<div class="page-row"><input type="checkbox" aria-label="选择正文页 ${esc(p.url)}" data-page="${esc(pageKey(r,p))}" ${chosen.has(pageKey(r,p))?'checked':''}><div><a href="${esc(p.url)}" target="_blank" rel="noopener noreferrer">${esc(p.url.split('/').pop())}</a><small>${esc(status(p.status))} · 检查 ${esc(date(p.checked_at))}</small><small>来源更新 ${esc(date(p.source_updated_at))}</small>${p.sampled_chars!==undefined?`<small>累计检测 ${num(p.sampled_chars)} / ${num(p.text_length)} 字</small>`:''}${p.sampling?`<small>最近片段：第 ${num((p.sampling.start||0)+1)}–${num(p.sampling.end)} 字 · ${p.sampling.requested_by.map(id=>esc(strategyNames[id]||id)).join('、')}</small>`:''}</div><div class="page-count">${Object.entries(p.counts||{}).map(([k,v])=>`${esc(k)}：${v===null?'未知':num(v)}`).join(' · ')}</div></div>`).join('')}</div>${pages.length>limit?`<button class="text-button" data-more="${esc(key)}">显示更多网页（${limit} / ${pages.length}）</button>`:''}</details></article>`;
  }).join('');
}
function renderSelection(){
  $('selection-count').textContent=chosen.size+' 页';
  $('download-selection').innerHTML=chosen.size?[...chosen.entries()].map(([key,item])=>`<div class="selected-item"><div>${esc(item.title)}<br><span class="muted">${esc(item.url.split('/').pop())}</span></div><button data-remove="${esc(key)}" aria-label="移除页面">×</button></div>`).join(''):'<p class="muted">尚未选择正文页</p>';
}
function filteredDownloads(){return (state?.downloads.records||[]).filter(r=>{const before=$('downloaded-before').value;const after=$('source-after').value;if(before&&r.downloaded_at?.slice(0,10)>=before)return false;if(after&&r.source_updated_at&&r.source_updated_at.slice(0,10)<=after)return false;return true})}
function renderDownloads(){
  if(!state)return;
  const records=filteredDownloads();
  $('download-count').textContent=state.downloads.records.length;
  $('download-summary').textContent=`显示 ${records.length} / ${state.downloads.records.length} 条 · 日期按本地记录筛选`;
  $('download-jobs').innerHTML=jobBanner(state.downloads.jobs[0],true);
  $('start-download').disabled=!!state.active_job||!!state.downloads.active_job;
  $('refresh-downloads').disabled=$('start-download').disabled;
  $('download-records').innerHTML=records.length?records.map(r=>`<article class="download-card"><input type="checkbox" data-record="${esc(r.id)}" aria-label="选择下载记录 ${esc(r.title)}" ${checkedDownloads.has(r.id)?'checked':''}><div><h3>${esc(r.title)} · ${esc(r.url.split('/').pop())}</h3><a class="result-link" href="${esc(r.url)}" target="_blank" rel="noopener noreferrer">${esc(r.url)}</a><div class="chips"><span class="chip">${esc(status(r.status))}</span><span class="chip">${num(r.bytes)} 字节</span><span class="chip">${(r.versions||[]).length+1} 个本地版本</span></div><div class="metadata"><span>来源更新 ${esc(date(r.source_updated_at))}</span><span>下载 ${esc(date(r.downloaded_at))}</span><span>最近检查 ${esc(date(r.checked_at))}</span></div></div><div class="actions"><button class="button small secondary" data-file="${esc(r.id)}">保存 TXT 副本</button>${(r.versions||[]).map((v,i)=>`<button class="button small secondary" data-file="${esc(r.id)}" data-version="${i}">旧版 ${i+1}</button>`).join('')}</div></article>`).join(''):'<div class="empty-state">没有符合日期条件的下载记录</div>';
}
function renderHistory(){if(!state)return;const jobs=[...state.jobs.map(j=>({...j,kind:'搜集'})),...state.downloads.jobs.map(j=>({...j,kind:'下载'}))].sort((a,b)=>b.created_at.localeCompare(a.created_at));$('history-list').innerHTML=jobs.length?jobs.map(j=>`<div class="history-row"><div><strong>${j.kind} · ${esc(j.config?.name||'所选正文页')} · ${esc(status(j.status))}</strong><p>开始 ${esc(date(j.created_at))} · 最近记录 ${esc(date(j.updated_at))}</p>${j.error?`<p>${esc(reason(j.error))}</p>`:''}</div><span class="tag">${esc(j.id.slice(0,8))}</span></div>`).join(''):'<p class="muted">尚无执行记录</p>';$('data-directory').textContent=state.app.data_dir;}
async function refresh(){
  if(stopped)return;
  try{const next=await api('/api/state');if(stopped)return;state=next;$('connection').textContent='本机服务已连接';const options='<option value="">新建搜集器</option>'+state.collections.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('');if($('collection-select').innerHTML!==options)$('collection-select').innerHTML=options;
    if(initial){initial=false;loadConfig(state.collections[0]);}else{$('collection-select').value=currentId;}
    renderBoardControls();renderResults();renderActive();renderDownloads();renderHistory();renderUpdateControls();
  }catch(e){$('connection').textContent='未连接';notify(e.message,true)}
}
async function saveBlob(url,filename){const res=await fetch(url,{headers:{'X-App-Token':token}});if(!res.ok){const error=await res.json();throw Error(error.error||'导出失败')}const blob=await res.blob();const href=URL.createObjectURL(blob);const a=document.createElement('a');a.href=href;a.download=filename;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(href),5000);}
$('config-form').addEventListener('input',e=>{if(e.target.id!=='content-seed')dirty=true;else renderActive()});
$('source-type').onchange=()=>{dirty=true;renderBoardControls();renderActive()};
$('content-sampling').onchange=()=>{dirty=true;renderContentControls()};
for(const id of ['start-url','board-keys'])$(id).addEventListener('input',()=>{renderBoardControls();renderActive()});
$('config-form').addEventListener('submit',e=>{e.preventDefault();action(async()=>{await saveConfig();notify('搜集器已保存；已有关键词的权重已重算。新增关键词须再次扫描。')})});
$('add-keyword').onclick=()=>{if($('keyword-editor').children.length>=100){notify('最多 100 个关键词',true);return}keywordRow();dirty=true};
$('new-collection').onclick=()=>{if(dirty&&!confirm('放弃未保存的修改并新建搜集器？'))return;loadConfig(null)};
$('collection-select').onchange=e=>{if(dirty&&!confirm('放弃未保存的修改并切换搜集器？')){e.target.value=currentId;return}loadConfig(state.collections.find(c=>c.id===e.target.value))};
$('new-content-seed').onclick=()=>{$('content-seed').value=crypto.randomUUID();notify($('content-sampling').value==='fixed_interval'?'已填入新内容种子；固定采样位置由偏移和间隔决定。':'已填入新内容种子；分布采样将探索新的位置。')};
async function startContentScan(seed, directory, refreshBoard=false){
  if(dirty||!currentId||($('source-type').value!=='direct'&&!state?.collections.find(c=>c.id===currentId)?.board))await saveConfig();
  await api('/api/scans/start',{collection_id:currentId,content_seed:seed.trim(),...(directory?{directory_url:directory}:{}),refresh_board:refreshBoard});
  $('content-seed').value=seed.trim();
  notify(directory||$('source-type').value==='direct'?'内容搜索已启动；同种子从原进度继续，本次按追加字数执行。':refreshBoard?'已启动榜刷新；重建列表位置，保留书目上下文并复用已有检测。':'已启动搜书；按偏移和间隔继续选取，已有兼容内容检测将直接引用。');
}
$('start-scan').onclick=()=>action(()=>startContentScan($('content-seed').value));
$('refresh-board').onclick=()=>action(()=>startContentScan($('content-seed').value,null,true));
$('results').addEventListener('click',e=>{
  const book=e.target.closest('[data-scan-book]');
  if(book)action(()=>startContentScan($('content-seed').value,book.dataset.scanBook));
  const select=e.target.closest('[data-content-seed]');
  if(select){$('content-seed').value=select.dataset.contentSeed;renderActive();notify('已选用内容种子 '+select.dataset.contentSeed);}
  const next=e.target.closest('[data-continue-seed]');
  if(next)action(()=>startContentScan(next.dataset.continueSeed,next.dataset.directory));
});
$('export-csv').onclick=()=>action(()=>saveBlob('/api/report?collection_id='+encodeURIComponent(currentId)+'&format=csv','正文关键词链接集.csv'));
$('export-json').onclick=()=>action(()=>saveBlob('/api/report?collection_id='+encodeURIComponent(currentId)+'&format=json','正文关键词链接集.json'));
$('show-pilot').onclick=()=>action(async()=>{const data=await api('/api/pilot');const rows=data.books.filter(b=>b.total_keyword_occurrences>0).sort((a,b)=>b.total_keyword_occurrences-a.total_keyword_occurrences);$('pilot-results').innerHTML=rows.map(b=>`<p><a href="${esc(b.directory_url)}" target="_blank" rel="noopener noreferrer">${esc(b.title)}</a><br>修仙 ${b.total_keyword_occurrences} 次 · ${b.matching_pages} 页命中 / ${b.scanned_pages} 页扫描</p>`).join('');$('pilot-results').hidden=false;$('show-pilot').hidden=true});
$('start-download').onclick=()=>action(async()=>{await api('/api/downloads/start',{items:[...chosen.values()],rights_confirmed:$('rights-confirmed').checked});chosen.clear();$('rights-confirmed').checked=false;renderSelection();notify('下载任务已启动，仅处理所选正文页')});
$('refresh-downloads').onclick=()=>action(async()=>{const items=filteredDownloads().filter(r=>checkedDownloads.has(r.id)).map(r=>({url:r.url,directory_url:r.directory_url,title:r.title}));await api('/api/downloads/start',{items,rights_confirmed:$('rights-confirmed').checked});$('rights-confirmed').checked=false;notify('正在检查所选下载；未变内容不会重复写入')});
$('downloaded-before').onchange=renderDownloads;$('source-after').onchange=renderDownloads;
document.addEventListener('click',e=>{
  const more=e.target.closest('[data-more]');if(more){pageLimits.set(more.dataset.more,(pageLimits.get(more.dataset.more)||20)+50);renderResults()}
  const nav=e.target.closest('[data-tab]');if(nav)showTab(nav.dataset.tab);
  const remove=e.target.closest('[data-remove]');if(remove){chosen.delete(remove.dataset.remove);renderSelection();renderResults()}
  const file=e.target.closest('[data-file]');if(file)action(()=>saveBlob('/api/downloads/file/'+file.dataset.file+(file.dataset.version===undefined?'':'?version='+file.dataset.version),'正文-'+file.dataset.file.slice(0,8)+(file.dataset.version===undefined?'':'-旧版'+(Number(file.dataset.version)+1))+'.txt'));
  const button=e.target.closest('[data-action]');if(button)action(async()=>{const [type,verb]=button.dataset.action.split('-');await api('/api/'+(type==='scan'?'scans':'downloads')+'/'+verb,{job_id:button.dataset.id,rights_confirmed:$('rights-confirmed').checked});notify(verb==='pause'?'正在暂停，当前网络请求结束后会保存进度':'已继续任务')});
});
document.addEventListener('change',e=>{
  if(e.target.matches('[data-page]')){const key=e.target.dataset.page;if(e.target.checked){if(chosen.size>=20){e.target.checked=false;notify('每次最多选择 20 个正文网页',true);return}for(const r of state.results){const p=r.pages.find(p=>pageKey(r,p)===key);if(p){chosen.set(key,{url:p.url,directory_url:r.directory_url,title:r.title});break}}}else chosen.delete(key);renderSelection();$('download-count').textContent=state.downloads.records.length;}
  if(e.target.matches('[data-record]')){if(e.target.checked)checkedDownloads.add(e.target.dataset.record);else checkedDownloads.delete(e.target.dataset.record)}
});
document.addEventListener('toggle',e=>{if(e.target.matches('#results details')){if(e.target.open)openDetails.add(e.target.dataset.key);else openDetails.delete(e.target.dataset.key)}},true);
$('shutdown').onclick=$('footer-shutdown').onclick=()=>$('confirm-dialog').showModal();$('cancel-shutdown').onclick=()=>$('confirm-dialog').close();
$('confirm-shutdown').onclick=async()=>{try{await api('/api/shutdown',{});stopped=true;$('confirm-dialog').close();notify('正在保存进度并退出。再次使用请重新启动可执行程序。');$('connection').textContent='程序已关闭';document.querySelectorAll('button').forEach(b=>b.disabled=true)}catch(e){notify(e.message,true)}};
let updateStage=null, githubStage=null, githubVersion='', updateBusy=false, updatePhase='idle';
$('open-data').onclick=()=>action(()=>api('/api/data/open',{}));
function updateBlockReason(){
  if(!state)return '正在连接本地服务，请稍候。';
  if(state.app.updates.enabled===false)return '源码运行模式不支持安装更新，请使用完整发行包。';
  if(state.active_job||state.downloads.active_job)return '请先关闭此窗口，暂停搜集和下载，等待任务停止后再更新。';
  if(dirty)return '请先关闭此窗口并保存搜集器配置，再更新。';
  return '';
}
function renderUpdateControls(){
  const locked=updateBusy||stopped, blocked=updateBlockReason();
  const portable=!!state&&state.app.updates.enabled!==false;
  $('program-version').textContent=state?'当前版本 v'+state.app.version:'正在读取当前版本…';
  $('github-install').hidden=!githubVersion;
  $('github-install').disabled=locked||!!blocked||!githubVersion;
  $('update-install-hint').hidden=!githubVersion||stopped;
  $('github-check').hidden=!['current','error'].includes(updatePhase);
  $('github-check').disabled=locked;
  $('close-update').disabled=stopped||['downloading','installing'].includes(updatePhase);
  $('update-requirement').textContent=blocked;
  $('update-requirement').hidden=stopped||!blocked||(!githubVersion&&!document.querySelector('.update-advanced').open);
  $('check-update').disabled=locked||!portable;
  $('update-file').disabled=locked||!portable;
  $('trust-update').disabled=locked||!updateStage;
  $('install-update').disabled=locked||!!blocked||!updateStage||!$('trust-update').checked;
  $('rollback-update').disabled=locked||!!blocked||!state?.app.updates.can_rollback;

}
function updateStatus(message,phase){
  updatePhase=phase;
  $('github-status').textContent=message;
  $('github-status').classList.toggle('error',phase==='error');
  renderUpdateControls();
}
async function updateAction(fn){
  if(busy||stopped)return;
  busy=true;updateBusy=true;renderUpdateControls();
  try{await fn()}catch(e){updateStatus(e.message,'error')}
  finally{if(!stopped)await refresh();busy=false;updateBusy=false;renderUpdateControls()}
}
function resetOfflineUpdate(){updateStage=null;$('trust-update').checked=false;$('update-preview').textContent=''}
function showGitHubResult(result){
  if(result.status==='available'){
    githubVersion=result.version;
    updateStatus('发现新版本 v'+githubVersion,'ready');
  }else updateStatus(result.status==='current'?'已是最新版本。':result.message,result.status==='current'?'current':'error');
}
function checkGitHubUpdate(){return updateAction(async()=>{
  githubVersion='';githubStage=null;resetOfflineUpdate();
  updateStatus('正在检查更新…','checking');
  const result=await api('/api/updates/github/check',{});
  showGitHubResult(result);
})}
document.querySelectorAll('[data-check-update]').forEach(button=>button.onclick=()=>{
  if(!$('update-dialog').open){document.querySelector('.update-advanced').open=false;$('update-dialog').showModal()}
  if(updateBusy||stopped)return;
  if(busy){updateStatus('正在处理其他操作，请稍后重新检查。','error');return}
  checkGitHubUpdate();
});
$('github-check').onclick=checkGitHubUpdate;
$('close-update').onclick=()=>{if(!$('close-update').disabled)$('update-dialog').close()};
$('update-dialog').addEventListener('cancel',e=>{if($('close-update').disabled)e.preventDefault()});
document.querySelector('.update-advanced').addEventListener('toggle',renderUpdateControls);
async function switchProgram(route,body){
  const blocked=updateBlockReason();if(blocked)throw Error(blocked);
  updateStatus('正在备份数据并重启，请稍候…','installing');
  await api(route,body);stopped=true;
  updateStatus('数据已备份，正在重新启动。请使用新打开的页面；如未自动打开，请复制程序窗口中的完整本机地址。','restarting');
  $('connection').textContent='程序正在重启';
  document.querySelectorAll('button').forEach(b=>b.disabled=true);
}
$('github-install').onclick=()=>updateAction(async()=>{
  const blocked=updateBlockReason();if(blocked)throw Error(blocked);
  if(!githubVersion)throw Error('请先检查更新');
  if(!githubStage){
    resetOfflineUpdate();
    updateStatus('正在下载并校验 v'+githubVersion+'，完成后将备份数据并重启…','downloading');
    const preview=await api('/api/updates/github/prepare',{});
    githubStage=preview.stage_id;
    // A newer release may appear during download. Confirm its version before installing.
    if(preview.version!==githubVersion){
      githubVersion=preview.version;
      updateStatus('最新版本已变为 v'+githubVersion+'，已校验。请再次点击“更新并重启”确认安装。','ready');
      return;
    }
  }
  await switchProgram('/api/updates/install',{stage_id:githubStage,confirmed:true});
});
$('update-file').onchange=()=>{resetOfflineUpdate();renderUpdateControls()};
$('trust-update').onchange=renderUpdateControls;
$('check-update').onclick=()=>updateAction(async()=>{
  githubVersion='';githubStage=null;resetOfflineUpdate();
  updateStatus('正在检查离线更新包…','preparing');
  const file=$('update-file').files[0];if(!file)throw Error('请先选择 ZIP 更新包');
  if(file.size>20*1024*1024)throw Error('更新包超过 20 MiB；请选择 app-only 更新包');
  const bytes=new Uint8Array(await file.arrayBuffer());let raw='';
  for(let i=0;i<bytes.length;i+=8192)raw+=String.fromCharCode(...bytes.subarray(i,i+8192));
  const preview=await api('/api/updates/prepare',{archive:btoa(raw)});
  updateStage=preview.stage_id;
  $('update-preview').textContent='可更新至 v'+preview.version+'。SHA-256：'+preview.archive_sha256+'。校验通过不代表来源可信，请确认发布者后安装。';
  updateStatus('离线更新包已校验，请在下方确认来源后安装。','ready');
});
$('install-update').onclick=()=>updateAction(async()=>{
  if(!updateStage||!$('trust-update').checked)throw Error('请先校验并确认可信来源');
  await switchProgram('/api/updates/install',{stage_id:updateStage,confirmed:true});
});
$('rollback-update').onclick=()=>updateAction(async()=>{
  if(!confirm('备份当前数据并回退到上一个程序版本？数据仍保持最新，不恢复旧备份。'))return;
  await switchProgram('/api/updates/rollback',{confirmed:true});
});
keywordRow('修仙',1);refresh();setInterval(()=>{if(!busy&&!stopped)refresh()},3000);
