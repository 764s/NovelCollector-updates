"""Data capabilities that constrain switching back to an older application."""
import json


def minimum_reader_version(db):
    """Inspect actual configurations and retained history without changing data.

    A configuration reset does not remove searches or reports that an old app
    would still try to deserialize. Keyword/name strings are not capabilities.
    The caller holds the manager lock and has stopped background writers.
    """
    def uses_mode(value, mode):
        if isinstance(value, list):
            return any(uses_mode(item, mode) for item in value)
        if not isinstance(value, dict):
            return False
        for name in ('strategies', 'specs'):
            specs = value.get(name)
            if isinstance(specs, list) and any(isinstance(s, dict) and s.get('id') == mode for s in specs):
                return True
        return any(uses_mode(item, mode) for item in value.values() if isinstance(item, (dict, list)))

    fixed = False
    for table, columns in (
            ('collections', ('config',)), ('jobs', ('config', 'state')), ('books', ('data',)),
            ('content_searches', ('binding', 'state')), ('discovery_evaluations', ('data',))):
        for row in db.execute(f'SELECT {",".join(columns)} FROM {table}'):
            values = [json.loads(value) for value in row]
            if any(uses_mode(value, 'progressive_distributed') for value in values):
                return '2.6.0'
            fixed |= any(uses_mode(value, 'fixed_interval') for value in values)
    return '2.5.0' if fixed else None
