"""Independent regression/security review. All web and source content is synthetic.

Run: python -m unittest discover -s tests -p 'test_review.py' -v
The only real sockets used are a temporary local API server; no source is fetched.
"""
import http.client
import json
import socket
import tempfile
import threading
import unittest
from email.message import Message
from pathlib import Path
from unittest.mock import patch

from core import Manager, validate_config
from downloader import Downloader
from main import Application, InstanceLock, make_handler, report_csv
from http.server import ThreadingHTTPServer
from novel_crawler.models import CrawlStop
from novel_crawler.http import Robots
from transport import SafeTransport, FetchResult, source_date

BASE = 'https://www.52shuku.net'
DIRECTORY = BASE + '/wuxia/demo.html'
PAGE1 = BASE + '/wuxia/demo_1.html'
PAGE2 = BASE + '/wuxia/demo_2.html'
TEXT = '剑剑雨。' + '这是一段完全合成的测试内容。' * 12
BODY1 = '<article class="article-content"><p>测试说明</p><p>第一章</p><p>' + TEXT + '</p><div class="pagination2"><a href="demo.html">目录</a></div></article>'
BODY2 = '<article class="article-content"><p>剑雨雨。</p><div class="pagination2"><a href="demo.html">目录</a></div></article>'


def directory_html(pages=(PAGE1,)):
    return '<h1>合成演示</h1><article class="article-content"><p>小说简介：</p>' + ''.join('<li class="mulu"><a href="' + p + '">测试页</a></li>' for p in pages) + '</article>'


def config(**kwargs):
    return {'name': '测试', 'start_url': DIRECTORY, 'keywords': [{'term': '剑', 'weight': 2}], **kwargs}


class ScriptedTransport:
    """No sockets. Requests, conditional headers, cancellation, and budget recorded."""
    def __init__(self, responses, calls, **kwargs):
        self.responses = responses
        self.calls = calls
        self.request_count = kwargs.get('request_count', 0)
        self.maximum = kwargs['max_requests']
        self.event = kwargs.get('on_request', lambda r: None)
        self.cancel = kwargs['cancellation']

    def tick(self, url, validators=None):
        if self.request_count >= self.maximum:
            raise CrawlStop('request_budget_reached', url)
        self.request_count += 1
        self.event({'count': self.request_count, 'event': 'started', 'url': url})
        self.calls.append((url, validators))

    def load_robots(self):
        self.tick(BASE + '/robots.txt')

    def fetch(self, url, validators=None):
        self.tick(url, validators)
        response = self.responses[url]
        if isinstance(response, Exception):
            raise response
        return response if isinstance(response, FetchResult) else FetchResult(response, url, 200)

    def close(self):
        pass


class ManagerReview(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.calls = []
        self.responses = {DIRECTORY: directory_html(), PAGE1: FetchResult(BODY1, PAGE1, 200, '"v1"')}
        self.manager = Manager(self.temp.name, auto_start=False,
            transport_factory=lambda **kw: ScriptedTransport(self.responses, self.calls, **kw))
        self.collection = self.manager.create_collection(config())

    def tearDown(self):
        self.manager.close()
        self.temp.cleanup()

    def run_scan(self):
        job = self.manager.start_scan(self.collection['id'])
        self.manager._run_job(job['id'])
        return self.manager.snapshot()

    def test_weighted_literal_score_and_metadata_only(self):
        state = self.run_scan()
        self.assertEqual(state['jobs'][0]['status'], 'completed')
        result = state['results'][0]
        self.assertEqual(result['counts'], {'剑': 2})
        self.assertEqual(result['score'], 4)
        self.assertIsNone(result['source_updated_at'])
        self.assertLessEqual(len(result['snippets']), 2)
        self.assertTrue(all(len(x) <= 32 for x in result['snippets']))
        for table in ('collections', 'jobs', 'books', 'pages'):
            for row in self.manager.db.execute('SELECT * FROM ' + table):
                self.assertNotIn(TEXT, repr(tuple(row)))
        self.assertNotIn('html', result['pages'][0])
        self.assertNotIn('text', result['pages'][0])

    def test_reweight_needs_no_network_and_changes_score(self):
        self.run_scan()
        count = len(self.calls)
        self.manager.update_collection(self.collection['id'], {'keywords': [{'term': '剑', 'weight': 9}]})
        self.assertEqual(self.manager.snapshot()['results'][0]['score'], 18)
        self.assertEqual(len(self.calls), count)

    def test_added_term_is_unknown_until_recount_not_false_zero(self):
        self.run_scan()
        self.manager.update_collection(self.collection['id'], {'keywords': [{'term': '剑', 'weight': 2}, {'term': '雨', 'weight': 3}]})
        before = self.manager.snapshot()['results'][0]
        self.assertIsNone(before['score'])
        self.assertIsNone(before['counts']['雨'])
        self.assertTrue(before['requires_rescan'])
        self.calls.clear()
        after = self.run_scan()['results'][0]
        self.assertEqual(after['counts'], {'剑': 2, '雨': 1})
        self.assertEqual(after['score'], 7)
        self.assertIsNone([v for u, v in self.calls if u == PAGE1][0])

    def test_conditional_304_preserves_counts_and_source_date(self):
        self.responses[PAGE1] = FetchResult(BODY1, PAGE1, 200, '"v1"', None, '2025-01-01T00:00:00+00:00', 'explicit_modified_metadata')
        self.run_scan()
        self.calls.clear()
        self.responses[PAGE1] = FetchResult('', PAGE1, 304)
        state = self.run_scan()
        result = state['results'][0]
        self.assertEqual(result['score'], 4)
        self.assertEqual(result['pages'][0]['source_updated_at'], '2025-01-01T00:00:00+00:00')
        self.assertEqual(result['pages'][0]['status'], 'unchanged_304')
        self.assertEqual([v for u, v in self.calls if u == PAGE1][0]['etag'], '"v1"')

    def test_200_identical_hash_reuses_count(self):
        self.run_scan()
        state = self.run_scan()
        self.assertEqual(state['results'][0]['pages'][0]['status'], 'unchanged_hash')
        self.assertEqual(state['jobs'][0]['progress']['reused_hash'], 1)

    def test_redirect_identity_stops_without_persisting_wrong_body(self):
        self.responses[PAGE1] = FetchResult(BODY2, PAGE2, 200)
        state = self.run_scan()
        self.assertEqual(state['jobs'][0]['status'], 'stopped')
        self.assertEqual(state['jobs'][0]['error'], 'body_redirect_changed_identity')
        self.assertEqual(state['results'][0]['scanned_pages'], 0)

    def test_unscanned_new_directory_pages_are_prioritized(self):
        self.manager.update_collection(self.collection['id'], {'chars_per_book': len(TEXT)})
        self.run_scan()
        self.responses[DIRECTORY] = directory_html((PAGE1, PAGE2))
        self.responses[PAGE2] = BODY2.replace('剑雨雨。', '剑雨雨。' + '文' * (len(TEXT) - 4))
        self.calls.clear()
        result = self.run_scan()['results'][0]
        self.assertNotIn(PAGE1, [u for u, _ in self.calls])
        self.assertIn(PAGE2, [u for u, _ in self.calls])
        self.assertEqual(result['scanned_pages'], 2)
        self.assertEqual(result['score'], 6)

    def test_restart_pauses_and_preserves_cursor_budget(self):
        job = self.manager.start_scan(self.collection['id'])
        row = self.manager._get_job(job['id'])
        state = json.loads(row['state'])
        state['request_count'] = 159
        self.manager._save_state(job['id'], state)
        self.manager.close()
        self.manager = Manager(self.temp.name, auto_start=False,
            transport_factory=lambda **kw: ScriptedTransport(self.responses, self.calls, **kw))
        recovered = self.manager.snapshot()['jobs'][0]
        self.assertEqual(recovered['status'], 'paused')
        self.assertEqual(recovered['progress']['request_count'], 159)
        self.manager.resume_job(job['id'])
        self.manager._run_job(job['id'])
        stopped = self.manager.snapshot()['jobs'][0]
        self.assertEqual(stopped['status'], 'stopped')
        self.assertEqual(stopped['progress']['request_count'], 160)
        self.assertEqual(stopped['error'], 'request_budget_reached')

    def test_changed_config_prevents_resume(self):
        job = self.manager.start_scan(self.collection['id'])
        self.manager.pause_job(job['id'])
        self.manager.update_collection(self.collection['id'], {'name': '改名'})
        with self.assertRaises(ValueError):
            self.manager.resume_job(job['id'])

    def test_source_stop_does_not_auto_resume(self):
        self.responses[PAGE1] = CrawlStop('http_429_access_stop', PAGE1)
        state = self.run_scan()
        job = state['jobs'][0]
        self.assertEqual(job['status'], 'stopped')
        with self.assertRaises(ValueError):
            self.manager.resume_job(job['id'])


class HTTPReview(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        with patch('main.resolve_data_dir', return_value=Path(cls.temp.name)):
            cls.app = Application()
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), make_handler(cls.app))
        cls.server.daemon_threads = True
        cls.app.server = cls.server
        cls.worker = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.worker.start()
        cls.host = '127.0.0.1:' + str(cls.server.server_port)

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.worker.join(3)
        cls.app.close()
        cls.temp.cleanup()

    def request(self, method='GET', path='/api/state', headers=None, body=None, token=True):
        conn = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=3)
        hs = {'Host': self.host}
        if token:
            hs['X-App-Token'] = self.app.token
        hs.update(headers or {})
        conn.request(method, path, body=body, headers=hs)
        response = conn.getresponse()
        result = (response.status, response.read(), dict(response.getheaders()))
        conn.close()
        return result

    def test_api_requires_token(self):
        self.assertEqual(self.request(token=False)[0], 401)
        self.assertEqual(self.request(headers={'X-App-Token': 'wrong'})[0], 401)
        self.assertEqual(self.request()[0], 200)

    def test_host_origin_and_cross_site_guards(self):
        for headers in ({'Host': 'evil.example'}, {'Host': 'localhost:' + str(self.server.server_port)},
                        {'Origin': 'https://evil.example'}, {'Origin': 'null'},
                        {'Origin': 'http://127.0.0.1:1'}, {'Sec-Fetch-Site': 'cross-site'}):
            with self.subTest(headers=headers):
                self.assertEqual(self.request(headers=headers)[0], 403)
        self.assertEqual(self.request(headers={'Origin': 'http://' + self.host})[0], 200)

    def test_no_token_in_unauthenticated_assets(self):
        status, payload, hs = self.request(path='/', token=False)
        self.assertEqual(status, 200)
        self.assertNotIn(self.app.token.encode(), payload)
        self.assertEqual(hs['Referrer-Policy'], 'no-referrer')
        self.assertIn("frame-ancestors 'none'", hs['Content-Security-Policy'])

    def test_posts_are_json_and_size_bounded(self):
        self.assertEqual(self.request('POST', '/api/collections', {'Content-Type': 'text/plain'}, '{}')[0], 415)
        self.assertEqual(self.request('POST', '/api/collections', {'Content-Type': 'application/json'}, '[]')[0], 400)
        self.assertEqual(self.request('POST', '/api/collections', {'Content-Type': 'application/json', 'Content-Length': '1000001'}, None)[0], 413)
        self.assertEqual(self.request('POST', '/api/collections', {'Content-Type': 'application/json', 'Transfer-Encoding': 'chunked'}, '{}')[0], 400)

    def test_character_strategy_configuration_roundtrip(self):
        payload = config(chars_per_book=4000, sample_chars=200,
                         keywords=[{'term': '剑', 'weight': 0, 'focused': True}])
        code, body, _ = self.request('POST', '/api/collections', {'Content-Type': 'application/json'}, json.dumps(payload))
        self.assertEqual(code, 200)
        saved = json.loads(body)
        self.assertTrue(saved['keywords'][0]['focused'])
        self.assertEqual(saved['chars_per_book'], 4000)
        self.assertNotIn('pages_per_book', saved)
        state = json.loads(self.request()[1])
        restored = next(c for c in state['collections'] if c['id'] == saved['id'])
        self.assertEqual(restored, saved)
        self.assertEqual({s['id'] for s in restored['strategies']}, {'distributed', 'focus_neighbors'})

    def test_character_budget_and_focus_parameters_validated_by_api(self):
        for change in ({'chars_per_book': 50001}, {'sample_chars': 0},
                       {'keywords': [{'term': '剑', 'focused': 'true'}]},
                       {'strategies': [{'id': 'distributed'}, {'id': 'focus_neighbors', 'params': {'radius_chars': -1}}]}):
            payload = json.dumps(config(**change))
            self.assertEqual(self.request('POST', '/api/collections', {'Content-Type': 'application/json'}, payload)[0], 400)

    def test_content_seed_start_and_validation_via_http(self):
        code, payload, _ = self.request('POST', '/api/collections', {'Content-Type': 'application/json'}, json.dumps(config()))
        self.assertEqual(code, 200)
        cid = json.loads(payload)['id']
        with patch.object(self.app.manager, 'auto_start', False):
            for seed in ('', 'x' * 129, 1, {}):
                body = json.dumps({'collection_id': cid, 'content_seed': seed})
                self.assertEqual(self.request('POST', '/api/scans/start', {'Content-Type': 'application/json'}, body)[0], 400)
            body = json.dumps({'collection_id': cid, 'content_seed': 'http-seed'})
            code, payload, _ = self.request('POST', '/api/scans/start', {'Content-Type': 'application/json'}, body)
            self.assertEqual(code, 200)
            job = json.loads(payload)
            self.assertEqual(job['content_seed'], 'http-seed')
            self.app.manager.pause_job(job['id'])
            self.assertEqual(self.request('POST', '/api/scans/start', {'Content-Type': 'application/json'}, body)[0], 400)

    def test_arbitrary_url_download_and_missing_rights_rejected(self):
        body = json.dumps({'items': [{'url': PAGE1, 'directory_url': DIRECTORY}], 'rights_confirmed': True})
        self.assertEqual(self.request('POST', '/api/downloads/start', {'Content-Type': 'application/json'}, body)[0], 400)
        self.assertIsNone(self.app.downloader.snapshot()['active_job'])

    def test_static_paths_do_not_escape_assets(self):
        for path in ('/../main.py', '/%2e%2e/main.py', '/static/../../main.py', '/data/app.db'):
            with self.subTest(path=path):
                self.assertEqual(self.request(path=path)[0], 404)


class FakeGate:
    def acquire(self, cancellation, delay=0):
        pass
    def release(self):
        pass


class FakeResponse:
    def __init__(self, status=200, body=b'<html>fixture</html>', **headers):
        self.status = status
        self.body = body
        self.headers = Message()
        self.headers['Content-Type'] = headers.pop('Content-Type', 'text/html; charset=utf-8')
        for key, value in headers.items():
            self.headers[key] = value
        self.closed = False
        self.offset = 0
    def read(self, amount):
        chunk = self.body[self.offset:self.offset + amount]
        self.offset += len(chunk)
        return chunk
    read1 = read
    def close(self):
        self.closed = True


class TransportReview(unittest.TestCase):
    def public_resolver(self, hostname, port, **kw):
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', ('8.8.8.8', 443))]

    def transport(self, **kw):
        result = SafeTransport(gate=FakeGate(), resolver=self.public_resolver, **kw)
        result.robots = Robots('User-agent: *\nAllow: /', 'NovelBodyKeywordCrawler/1.0')
        return result

    def test_external_urls_credentials_ports_fragments_rejected(self):
        transport = self.transport()
        bad = ['http://www.52shuku.net/wuxia/demo.html', 'https://127.0.0.1/wuxia/demo.html',
            'https://www.52shuku.net.evil.test/wuxia/demo.html', 'https://evil.test/wuxia/demo.html',
            'https://x@www.52shuku.net/wuxia/demo.html', DIRECTORY + '?a=1', DIRECTORY + '#x',
            'https://www.52shuku.net:444/wuxia/demo.html', DIRECTORY + '\r\nX:bad']
        for url in bad:
            with self.subTest(url=url), self.assertRaises(CrawlStop):
                transport._validate(url)

    def test_traversal_and_encoded_path_separators_rejected(self):
        transport = self.transport()
        for path in ('/wuxia/../admin/test.html', '/wuxia/%2e%2e/%2e%2e/admin/test.html',
                     '/wuxia/a%2fb/test.html', '/wuxia/a%5cb/test.html'):
            with self.subTest(path=path), self.assertRaises(CrawlStop):
                transport._validate(BASE + path)

    def test_mixed_public_private_dns_rejected(self):
        for address in ('127.0.0.1', '10.0.0.1', '169.254.169.254', '::1', 'fc00::1', '224.0.0.1', '0.0.0.0'):
            transport = self.transport()
            transport.resolver = lambda *a, **k: [(2, 1, 6, '', ('8.8.8.8', 443)), (2, 1, 6, '', (address, 443))]
            with self.subTest(address=address), self.assertRaises(CrawlStop) as ctx:
                transport._resolve_public('www.52shuku.net')
            self.assertEqual(ctx.exception.reason, 'unsafe_dns_address')

    def test_network_is_pinned_and_conditional_headers_safe(self):
        response = FakeResponse()
        transport = self.transport()
        with patch('transport._PinnedHTTPSConnection') as connection:
            connection.return_value.getresponse.return_value = response
            transport.fetch(PAGE1, {'etag': '"v1"', 'last_modified': 'evil\r\nInjected: true'})
            connection.assert_called_once_with('www.52shuku.net', '8.8.8.8', 30)
            headers = connection.return_value.request.call_args.kwargs['headers']
            self.assertEqual(headers['If-None-Match'], '"v1"')
            self.assertNotIn('If-Modified-Since', headers)
            self.assertEqual(headers['Accept-Encoding'], 'identity')
        self.assertTrue(response.closed)

    def test_access_denial_retry_after_challenge_stop(self):
        cases = [
            (FakeResponse(403), 'http_403_access_stop'),
            (FakeResponse(429), 'http_429_access_stop'),
            (FakeResponse(200, **{'Retry-After': '30'}), 'retry_after_stop'),
            (FakeResponse(200, b'<title>Just a moment</title>'), 'captcha_or_challenge_stop'),
            (FakeResponse(200, b'<div class="g-recaptcha">'), 'captcha_or_challenge_stop'),
            (FakeResponse(200, **{'Content-Type': 'application/octet-stream'}), 'unexpected_content_type'),
            (FakeResponse(200, **{'Content-Encoding': 'gzip'}), 'unexpected_content_encoding')]
        for response, reason in cases:
            with self.subTest(reason=reason), patch('transport._PinnedHTTPSConnection') as connection:
                connection.return_value.getresponse.return_value = response
                with self.assertRaises(CrawlStop) as ctx:
                    self.transport().fetch(PAGE1)
                self.assertEqual(ctx.exception.reason, reason)
                self.assertTrue(response.closed)

    def test_response_size_and_total_request_budget(self):
        transport = self.transport(max_response_bytes=20)
        with patch('transport._PinnedHTTPSConnection') as connection:
            connection.return_value.getresponse.return_value = FakeResponse(body=b'x' * 21)
            with self.assertRaises(CrawlStop) as ctx:
                transport.fetch(PAGE1)
            self.assertEqual(ctx.exception.reason, 'response_size_limit')
        with patch('transport._PinnedHTTPSConnection') as connection:
            transport = self.transport(max_requests=2, request_count=2)
            with self.assertRaises(CrawlStop) as ctx:
                transport.fetch(PAGE1)
            self.assertEqual(ctx.exception.reason, 'request_budget_reached')
            connection.assert_not_called()

    def test_robots_denial_and_external_redirect_stop(self):
        transport = self.transport()
        transport.robots = Robots('User-agent: *\nDisallow: /wuxia/', 'NovelBodyKeywordCrawler/1.0')
        with patch('transport._PinnedHTTPSConnection') as connection, self.assertRaises(CrawlStop):
            transport.fetch(PAGE1)
        connection.assert_not_called()
        transport = self.transport()
        with patch('transport._PinnedHTTPSConnection') as connection:
            connection.return_value.getresponse.return_value = FakeResponse(302, **{'Location': 'https://example.org/evil'})
            with self.assertRaises(CrawlStop) as ctx:
                transport.fetch(PAGE1)
            self.assertEqual(ctx.exception.reason, 'external_or_unsafe_url')
            self.assertEqual(connection.call_count, 1)

    def test_304_without_actual_condition_is_rejected(self):
        transport = self.transport()
        with patch('transport._PinnedHTTPSConnection') as connection:
            connection.return_value.getresponse.return_value = FakeResponse(304)
            with self.assertRaises(CrawlStop):
                transport.fetch(PAGE1, {'etag': None, 'last_modified': None})

    def test_slow_body_total_deadline_is_bounded(self):
        clock = [0]
        response = FakeResponse(body=b'synthetic chunk')
        original = response.read1
        def delayed_read(amount):
            clock[0] += 31
            return original(amount)
        response.read1 = delayed_read
        with patch('transport.time.monotonic', side_effect=lambda: clock[0]), patch('transport._PinnedHTTPSConnection') as connection:
            connection.return_value.getresponse.return_value = response
            with self.assertRaises(CrawlStop):
                self.transport().fetch(PAGE1)
        self.assertTrue(response.closed)

    def test_cancellation_between_body_chunks_stops(self):
        transport = self.transport()
        response = FakeResponse(body=b'synthetic chunk')
        original = response.read1
        def cancelled_read(amount):
            transport.cancellation.set()
            return original(amount)
        response.read1 = cancelled_read
        with patch('transport._PinnedHTTPSConnection') as connection:
            connection.return_value.getresponse.return_value = response
            with self.assertRaises(CrawlStop) as ctx:
                transport.fetch(PAGE1)
            self.assertEqual(ctx.exception.reason, 'paused')
        self.assertTrue(response.closed)

    def test_source_date_does_not_infer_from_crawl_date(self):
        self.assertEqual(source_date('<p>最近检查于2026年10月2日</p>'), (None, None))
        self.assertEqual(source_date('<meta property="article:modified_time" content="2025-01-02T00:00:00Z">')[0], '2025-01-02T00:00:00+00:00')
        self.assertEqual(source_date('', 'Wed, 21 Oct 2015 07:28:00 GMT')[1], 'last_modified_header')


class DownloaderReview(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.downloader = Downloader(self.temp.name)
        self.calls = []
        self.responses = {DIRECTORY: directory_html((PAGE1, PAGE2)), PAGE1: FetchResult(BODY1, PAGE1, 200)}

    def tearDown(self):
        self.downloader.close()
        self.temp.cleanup()

    def run_download(self, items=None, trusted_pages=None):
        with patch('downloader.SafeTransport', side_effect=lambda **kw: ScriptedTransport(self.responses, self.calls, **kw)), patch.object(self.downloader, '_launch'):
            job = self.downloader.start(items or [{'url': PAGE1, 'directory_url': DIRECTORY, 'title': '合成'}], True, trusted_pages=trusted_pages)
            self.downloader._run(job)
        return self.downloader.snapshot()

    def test_rights_confirmation_is_required(self):
        for value in (None, False, 1, 'true'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.downloader.start([{'url': PAGE1, 'directory_url': DIRECTORY}], value)
        self.assertFalse(self.downloader.snapshot()['jobs'])

    def test_download_dates_unknown_and_hash_reuse(self):
        first = self.run_download()['records'][0]
        self.assertIsNone(first['source_updated_at'])
        content = self.downloader.file(first['id']).read_text('utf-8-sig')
        self.assertIn('来源更新：未知', content)
        self.assertIn(TEXT, content)
        second = self.run_download()['records'][0]
        self.assertEqual(second['filename'], first['filename'])
        self.assertEqual(second['downloaded_at'], first['downloaded_at'])
        self.assertEqual(second['status'], 'unchanged_hash')
        self.assertEqual(second['versions'], [])

    def test_changed_body_keeps_previous_version(self):
        first = self.run_download()['records'][0]
        self.responses[PAGE1] = FetchResult(BODY1.replace(TEXT, TEXT + '修改。'), PAGE1, 200)
        second = self.run_download()['records'][0]
        self.assertNotEqual(second['filename'], first['filename'])
        self.assertEqual(second['versions'][0]['filename'], first['filename'])
        self.assertTrue(self.downloader.file(first['id'], 0).is_file())

    def test_redirect_to_another_page_must_not_be_saved_under_original(self):
        self.responses[PAGE1] = FetchResult(BODY2, PAGE2, 200)
        state = self.run_download()
        self.assertFalse(state['records'], 'Wrong page content was saved under the original URL')
        self.assertIn(state['jobs'][0]['status'], ('blocked', 'interrupted'))

    def test_trusted_observed_pagination_only_page_can_download(self):
        self.responses[DIRECTORY] = directory_html((PAGE1,))
        self.responses[PAGE2] = FetchResult(BODY2, PAGE2, 200)
        state = self.run_download([{'url': PAGE2, 'directory_url': DIRECTORY}], {(PAGE2, DIRECTORY)})
        self.assertEqual(state['jobs'][0]['status'], 'completed')
        self.assertEqual(state['records'][0]['url'], PAGE2)
        self.assertIn('剑雨雨。', self.downloader.file(state['records'][0]['id']).read_text('utf-8-sig'))

    def test_client_forged_pagination_provenance_is_ignored(self):
        self.responses[DIRECTORY] = directory_html((PAGE1,))
        self.responses[PAGE2] = FetchResult(BODY2, PAGE2, 200)
        state = self.run_download([{'url': PAGE2, 'directory_url': DIRECTORY, 'observed_in_collection': True}])
        self.assertEqual(state['jobs'][0]['status'], 'blocked')
        self.assertFalse(state['records'])
        self.assertNotIn(PAGE2, [u for u, _ in self.calls])
        self.assertFalse(state['jobs'][0]['items'][0]['observed_in_collection'])

    def test_even_trusted_pagination_cannot_cross_books(self):
        other = BASE + '/wuxia/other_2.html'
        self.responses[other] = FetchResult(BODY2, other, 200)
        state = self.run_download([{'url': other, 'directory_url': DIRECTORY}], {(other, DIRECTORY)})
        self.assertEqual(state['jobs'][0]['status'], 'blocked')
        self.assertFalse(state['records'])

    def test_missing_validators_must_not_send_empty_conditional_request(self):
        self.run_download()
        self.calls.clear()
        self.run_download()
        self.assertIsNone([v for u, v in self.calls if u == PAGE1][0])

    def test_304_without_validators_is_not_accepted(self):
        self.run_download()
        self.responses[PAGE1] = FetchResult('', PAGE1, 304)
        state = self.run_download()
        self.assertNotEqual(state['records'][0]['status'], 'unchanged_304')
        self.assertIn(state['jobs'][0]['status'], ('blocked', 'interrupted'))

    def test_files_cannot_escape_download_folder(self):
        record = self.run_download()['records'][0]
        outside = Path(self.temp.name) / 'outside.txt'
        outside.write_text('private outside fixture', encoding='utf-8')
        record['filename'] = '../outside.txt'
        with self.downloader._db() as db:
            db.execute('UPDATE downloads SET data=? WHERE id=?', (json.dumps(record), record['id']))
        with self.assertRaises(ValueError):
            self.downloader.file(record['id'])
        record['filename'] = 'escaped.txt'
        try:
            (self.downloader.folder / 'escaped.txt').symlink_to(outside)
        except OSError:
            self.skipTest('This OS/account cannot create the symlink fixture')
        with self.downloader._db() as db:
            db.execute('UPDATE downloads SET data=? WHERE id=?', (json.dumps(record), record['id']))
        with self.assertRaises(ValueError):
            self.downloader.file(record['id'])

    def test_restart_retains_records_and_pauses_running_job(self):
        state = self.run_download()
        job = state['jobs'][0]
        job['status'] = 'running'
        job['request_count'] = 12
        self.downloader._save_job(job)
        self.downloader.close()
        self.downloader = Downloader(self.temp.name)
        recovered = self.downloader.snapshot()
        self.assertEqual(recovered['jobs'][0]['status'], 'paused')
        self.assertEqual(recovered['jobs'][0]['request_count'], 12)
        self.assertEqual(recovered['records'][0]['id'], state['records'][0]['id'])


class LifecycleReview(unittest.TestCase):
    def test_shutdown_retains_instance_lock_while_writer_survives(self):
        with tempfile.TemporaryDirectory() as folder:
            with patch('main.resolve_data_dir', return_value=Path(folder)):
                app = Application()
            try:
                with patch.object(app.manager, 'close'), patch.object(app.downloader, 'close'), patch.object(app.manager, 'worker') as worker:
                    worker.is_alive.return_value = True
                    app.close()
                acquired = False
                try:
                    second = InstanceLock(Path(folder) / '.instance.lock')
                    acquired = True
                    second.close()
                except RuntimeError:
                    pass
                self.assertFalse(acquired, 'A second instance acquired the data folder while an old writer was alive')
            finally:
                app.manager.close()
                app.downloader.close()
                app.instance_lock.close()


class ExportReview(unittest.TestCase):
    def test_csv_formula_injection_escaped(self):
        result = report_csv([{'title': '=HYPERLINK("x")', 'directory_url': DIRECTORY, 'counts': {}}]).decode('utf-8-sig')
        self.assertIn("'=HYPERLINK", result)


if __name__ == '__main__':
    unittest.main()
