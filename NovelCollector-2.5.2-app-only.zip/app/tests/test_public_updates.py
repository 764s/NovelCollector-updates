"""Public update routes still require local request authentication and never GitHub credentials."""
import http.client
import json
import os
from http.server import ThreadingHTTPServer
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

import github_updates
from main import Application, VERSION, make_handler

CURRENT = json.dumps({'tag_name': 'v' + VERSION, 'draft': False, 'prerelease': False}).encode()


class PublicUpdateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.directory = Path(self.temp.name) / 'data'
        with patch('main.resolve_data_dir', return_value=self.directory):
            self.app = Application()
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), make_handler(self.app))
        self.app.server = self.server
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=5)
        self.app.close()
        self.temp.cleanup()

    def request(self, route, body=None, *, authenticated=True, origin=None):
        connection = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=5)
        headers = {'Content-Type': 'application/json'}
        if authenticated:
            headers['X-App-Token'] = self.app.token
        if origin:
            headers['Origin'] = origin
        connection.request('GET' if body is None else 'POST', route,
                           body=None if body is None else json.dumps(body), headers=headers)
        response = connection.getresponse()
        status, result = response.status, json.loads(response.read())
        connection.close()
        return status, result

    def test_local_auth_and_origin_still_protect_update_operations(self):
        with patch.object(github_updates, 'read_api') as network:
            for route in ('/api/updates/github/check', '/api/updates/github/prepare'):
                self.assertEqual(self.request(route, {}, authenticated=False)[0], 401)
                self.assertEqual(self.request(route, {}, origin='https://evil.test')[0], 403)
        network.assert_not_called()

    def test_check_ignores_ambient_credentials_and_uses_only_public_source(self):
        with patch.dict(os.environ, {'GH_TOKEN': 'bad-secret', 'GITHUB_TOKEN': 'bad-secret'}), \
                patch.object(github_updates, 'read_api', return_value=CURRENT) as network, \
                patch('subprocess.Popen', side_effect=AssertionError('must not use CLI')):
            status, result = self.request('/api/updates/github/check', {})
        self.assertEqual((status, result['status']), (200, 'current'))
        self.assertEqual(network.call_args.args[0], '764s/NovelCollector-updates')
        self.assertNotIn('token', network.call_args.kwargs)
        _, state = self.request('/api/state')
        self.assertNotIn('github_authorized', state['app'])
        self.assertNotIn('github_authorization', state['app'])
        self.assertNotIn('bad-secret', json.dumps(state))

    def test_unavailable_source_never_suggests_credentials_or_reports_current(self):
        with patch.object(github_updates, 'read_api', side_effect=github_updates.ReleaseHTTPError('access_or_missing')):
            status, result = self.request('/api/updates/github/check', {})
        self.assertEqual((status, result['status']), (200, 'release_unavailable'))
        self.assertFalse(result['ok'])
        self.assertNotIn('requires_authorization', result)

    def test_removed_credential_route_never_persists_submitted_data(self):
        with patch.object(github_updates, 'read_api') as network:
            status, result = self.request('/api/updates/github/authorize', {'token': 'never-save-this'})
        self.assertEqual(status, 400)
        network.assert_not_called()
        self.assertNotIn('never-save-this', str(result))
        self.app.close()
        for path in self.directory.rglob('*'):
            if path.is_file():
                self.assertNotIn(b'never-save-this', path.read_bytes())


if __name__ == '__main__':
    unittest.main()
