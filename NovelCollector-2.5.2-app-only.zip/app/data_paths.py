"""Fixed per-user storage and safe, lossless SQLite update backups.

Data lives outside every extracted installation. No remembered selection,
legacy discovery, or import is performed. The caller of ``snapshot_data``
MUST hold the source instance lock and quiesce ALL collector/downloader
writers until it returns. Backups never replace or delete original data.
"""
from contextlib import closing
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import stat
import sys
import tempfile


class DataPathError(ValueError):
    """The requested data location is unsafe, missing, or incompatible."""


SCHEMA = {
    'app.db': {
        'collections': {'id', 'config', 'revision', 'created_at', 'updated_at'},
        'jobs': {'id', 'collection_id', 'status', 'config', 'revision', 'state',
                 'error', 'created_at', 'updated_at', 'finished_at'},
        'books': {'collection_id', 'directory_url', 'data'},
        'pages': {'collection_id', 'directory_url', 'url', 'data'},
    },
    'downloads.db': {
        'downloads': {'id', 'url', 'data'},
        'download_jobs': {'id', 'data'},
    },
}
# Additive content-search storage is optional in old databases. If present,
# validate the whole group before opening it or accepting an update backup.
CONTENT_SCHEMA = {
    'content_contexts': {'directory_url', 'data'},
    'content_sources': {'directory_url', 'url', 'data'},
    'content_facts': {'id', 'directory_url', 'kind', 'url', 'body_hash', 'start', 'end', 'data'},
    'content_searches': {'directory_url', 'seed', 'binding', 'state', 'job_id', 'status', 'created_at', 'updated_at'},
}
DISCOVERY_SCHEMA = {
    'discovery_boards': {'id', 'type', 'base_url', 'keys', 'current_version', 'created_at'},
    'discovery_versions': {'id', 'board_id', 'state', 'status', 'created_at'},
    'discovery_entries': {'version_id', 'position', 'directory_url', 'source_url'},
    'discovery_context': {'board_id', 'directory_url', 'first_seen', 'last_seen'},
    'discovery_searches': {'board_id', 'config', 'state', 'job_id', 'status', 'updated_at'},
    'discovery_selections': {'board_id', 'directory_url', 'version_id', 'position', 'selected_at'},
    'discovery_evaluations': {'id', 'directory_url', 'profile', 'data', 'created_at'},
}
# The current schema is unversioned. A future marker must be explicitly
# supported before this application can open it; no migration is attempted.
SUPPORTED_DATABASE_MARKERS = {(0, 0)}
_TRANSIENT = {'.instance.lock'} | {
    name + suffix for name in SCHEMA for suffix in ('-wal', '-shm', '-journal')
}


def _is_link(path, details):
    return (stat.S_ISLNK(details.st_mode)
            or bool(getattr(details, 'st_file_attributes', 0)
                    & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400))
            or (hasattr(path, 'is_junction') and path.is_junction()))


def _path(value):
    try:
        result = Path(os.path.abspath(os.path.expanduser(os.fspath(value))))
    except (TypeError, ValueError, OSError) as error:
        raise DataPathError('数据目录路径无效') from error
    # Check BEFORE resolve(), so a link cannot hide the supplied location.
    for item in [*reversed(result.parents), result]:
        try:
            details = item.lstat()
        except FileNotFoundError:
            continue
        except OSError as error:
            raise DataPathError(f'无法检查路径：{item}') from error
        if _is_link(item, details):
            raise DataPathError(f'为保护原始数据，不接受符号链接或目录联接：{item}')
    return result


def _exists(path):
    return os.path.lexists(path)


def _walk_error(error):
    raise error


def _walk_files(root):
    """Validate the entire tree, including files excluded from the copy."""
    files = {}
    for directory, dirs, names in os.walk(root, followlinks=False, onerror=_walk_error):
        for name in dirs + names:
            path = Path(directory) / name
            details = path.lstat()
            mode = details.st_mode
            if _is_link(path, details):
                raise DataPathError(f'数据目录包含符号链接或目录联接：{path}')
            if not (stat.S_ISDIR(mode) or stat.S_ISREG(mode)):
                raise DataPathError(f'数据目录包含不支持的特殊文件：{path}')
            if stat.S_ISREG(mode):
                files[path.relative_to(root).as_posix()] = path
    return files


def _open_database(path):
    # mode=ro, unlike immutable=1, includes committed changes still in a WAL.
    connection = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True, timeout=5)
    connection.execute('PRAGMA query_only=ON')
    return connection


def _filename(value):
    if (not isinstance(value, str) or not value or value in ('.', '..')
            or any(char in value for char in ('/', '\\', ':', '\x00'))):
        raise DataPathError('下载记录包含不安全的文件名')
    return value


def _json_object(value, location):
    try:
        result = json.loads(value)
    except (ValueError, TypeError) as error:
        raise DataPathError(f'数据记录 JSON 无效：{location}') from error
    if not isinstance(result, dict):
        raise DataPathError(f'数据记录必须是对象：{location}')
    return result


def _database_info(path, root, files):
    try:
        with closing(_open_database(path)) as db:
            check = [row[0] for row in db.execute('PRAGMA quick_check')]
            if check != ['ok']:
                raise DataPathError(f'数据库完整性检查失败：{path.name}')
            version = db.execute('PRAGMA user_version').fetchone()[0]
            application_id = db.execute('PRAGMA application_id').fetchone()[0]
            if (version, application_id) not in SUPPORTED_DATABASE_MARKERS:
                raise DataPathError(f'数据库版本不受当前程序支持，拒绝降级打开：{path.name} ({version}/{application_id})')
            tables = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            counts = {}
            expected = dict(SCHEMA[path.name])
            if path.name == 'app.db' and tables & CONTENT_SCHEMA.keys():
                expected.update(CONTENT_SCHEMA)
            if path.name == 'app.db' and tables & DISCOVERY_SCHEMA.keys():
                expected.update(DISCOVERY_SCHEMA)
                expected.update(CONTENT_SCHEMA)
            for table, expected_columns in expected.items():
                if table not in tables:
                    raise DataPathError(f'数据库缺少必要表：{path.name}/{table}')
                columns = {row[1] for row in db.execute(f'PRAGMA table_info("{table}")')}
                if not expected_columns <= columns:
                    raise DataPathError(f'数据库表结构不兼容：{path.name}/{table}')
                counts[table] = db.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0]
            if path.name == 'app.db':
                json_columns = [('collections', ('config',)), ('jobs', ('config', 'state')),
                                ('books', ('data',)), ('pages', ('data',))]
                if tables & CONTENT_SCHEMA.keys():
                    json_columns += [('content_contexts', ('data',)), ('content_sources', ('data',)),
                                     ('content_facts', ('data',)), ('content_searches', ('binding', 'state'))]
                if tables & DISCOVERY_SCHEMA.keys():
                    json_columns += [('discovery_versions', ('state',)),
                                     ('discovery_searches', ('config', 'state')),
                                     ('discovery_evaluations', ('data',))]
                for table, columns in json_columns:
                    for column in columns:
                        for row in db.execute(f'SELECT "{column}" FROM "{table}"'):
                            _json_object(row[0], f'{table}/{column}')
            else:
                for row in db.execute('SELECT data FROM download_jobs'):
                    _json_object(row[0], 'download_jobs')
                for row in db.execute('SELECT data FROM downloads'):
                    record = _json_object(row[0], 'downloads')
                    versions = record.get('versions', [])
                    if not isinstance(versions, list) or any(not isinstance(v, dict) for v in versions):
                        raise DataPathError('下载历史版本记录无效')
                    for item in [record, *versions]:
                        name = _filename(item.get('filename'))
                        if 'downloads/' + name not in files:
                            raise DataPathError(f'下载记录引用的文件缺失：{name}')
            # Include every table/index/trigger and every value, including future
            # compatible columns, in copy equivalence checks.
            digest = hashlib.sha256()
            for line in db.iterdump():
                digest.update(line.encode('utf-8'))
                digest.update(b'\n')
            return {
                'counts': counts,
                'user_version': version,
                'application_id': application_id,
                'logical_sha256': digest.hexdigest(),
            }
    except sqlite3.Error as error:
        raise DataPathError(f'无法读取或验证数据库：{path.name}（{error}）') from error


def _hash_file(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def inspect_data(path):
    """Validate the current data schema without initializing or repairing it.

    Returns absolute ``data_dir``, per-database counts/schema versions/logical
    hashes, and hashes/sizes for all regular non-database, non-transient files.
    Expected download versions must exist. Extra ordinary files are retained.
    """
    root = _path(path)
    if not root.is_dir():
        raise DataPathError(f'数据目录不存在或不是目录：{root}')
    try:
        files = _walk_files(root)
        for name in SCHEMA:
            if name not in files:
                raise DataPathError(f'数据目录缺少 {name}，不会创建空数据库：{root}')
        databases = {name: _database_info(root / name, root, files) for name in SCHEMA}
        ordinary = {
            name: {'bytes': file.stat().st_size, 'sha256': _hash_file(file)}
            for name, file in sorted(files.items()) if name not in SCHEMA and name not in _TRANSIENT
        }
    except OSError as error:
        raise DataPathError(f'无法完整读取数据目录：{root}（{error}）') from error
    return {'data_dir': str(root), 'databases': databases, 'files': ordinary}


def resolve_data_dir():
    """Return the fixed per-user location without creating or importing data.

    The path never depends on the executable, working directory, or an old
    installation's config.json. XDG_DATA_HOME must be absolute, as required
    by the XDG directory convention; an invalid value uses the home default.
    """
    if sys.platform == 'win32':
        local = os.environ.get('LOCALAPPDATA')
        base = Path(local) if local else Path.home() / 'AppData' / 'Local'
        if not base.is_absolute():
            raise DataPathError('LOCALAPPDATA 必须是绝对路径')
    else:
        xdg = os.environ.get('XDG_DATA_HOME')
        base = Path(xdg) if xdg and Path(xdg).is_absolute() else Path.home() / '.local' / 'share'
    return _path(base / 'NovelCollector' / 'data')


def _fsync_directory(path):
    if os.name != 'nt':
        descriptor = os.open(path, os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)


class DataInstanceLock:
    """Compatible with main.InstanceLock on Windows, macOS, and Linux."""
    def __init__(self, path):
        path = _path(path)
        try:
            descriptor = os.open(path, os.O_RDWR | os.O_CREAT | getattr(os, 'O_NOFOLLOW', 0), 0o600)
            self.file = os.fdopen(descriptor, 'r+b')
            if not os.fstat(self.file.fileno()).st_size:
                self.file.write(b'0')
                self.file.flush()
            self.file.seek(0)
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as error:
            if hasattr(self, 'file'):
                self.file.close()
            raise DataPathError('数据目录已有程序运行或无法锁定，请先退出正在运行的程序') from error

    def close(self):
        if self.file.closed:
            return
        self.file.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(), fcntl.LOCK_UN)
        finally:
            self.file.close()


def _rename_absent(source, target):
    """Atomic no-replace directory install, including a competing mkdir.

    Plain POSIX os.rename can replace an existing EMPTY destination directory;
    use OS no-replace primitives instead. Unsupported systems fail closed.
    """
    if os.name == 'nt':
        os.rename(source, target)  # Windows never replaces an existing target.
        return
    library = ctypes.CDLL(None, use_errno=True)
    if sys.platform.startswith('linux') and hasattr(library, 'renameat2'):
        rename = library.renameat2
        rename.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
        rename.restype = ctypes.c_int
        result = rename(-100, os.fsencode(source), -100, os.fsencode(target), 1)  # RENAME_NOREPLACE
    elif sys.platform == 'darwin' and hasattr(library, 'renamex_np'):
        rename = library.renamex_np
        rename.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_uint]
        rename.restype = ctypes.c_int
        result = rename(os.fsencode(source), os.fsencode(target), 4)  # RENAME_EXCL
    else:
        raise DataPathError('当前系统无法保证安全的原子备份')
    if result:
        code = ctypes.get_errno()
        raise OSError(code, os.strerror(code), str(target))


def _equivalent(first, second):
    return first['databases'] == second['databases'] and first['files'] == second['files']


def snapshot_data(source, backup_dest):
    """Copy quiescent data with SQLite backup; atomically publish if absent.

    Caller MUST already hold source .instance.lock and stop ALL writers.
    The destination must not exist and must be outside the source directory.
    This does not copy WAL/SHM/journal/lock files or change source databases.
    """
    source, target = _path(source), _path(backup_dest)
    if source == target or source in target.parents:
        raise DataPathError('备份目标必须位于原数据目录之外')
    if _exists(target):
        raise DataPathError(f'目标已存在，不会覆盖：{target}')
    original = inspect_data(source)
    target.parent.mkdir(parents=True, exist_ok=True)
    _path(target.parent)
    staging = Path(tempfile.mkdtemp(prefix=f'.{target.name}.copy-', dir=target.parent))
    try:
        files = _walk_files(source)
        # Keep empty directories too; never follow directory links.
        for directory, dirs, _ in os.walk(source, followlinks=False, onerror=_walk_error):
            for name in dirs:
                (staging / (Path(directory) / name).relative_to(source)).mkdir(parents=True, exist_ok=True)
        for relative, path in files.items():
            if relative in SCHEMA or relative in _TRANSIENT:
                continue
            destination = staging / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, destination, follow_symlinks=False)
            _path(destination)
            # Windows FlushFileBuffers needs a writable handle. Flush the new
            # copy before preserving a source file's possible read-only mode.
            with open(destination, 'r+b') as stream:
                os.fsync(stream.fileno())
            shutil.copystat(path, destination, follow_symlinks=False)
        for name in SCHEMA:
            with closing(_open_database(source / name)) as old, closing(sqlite3.connect(staging / name)) as new:
                old.backup(new)
                # Consolidate the destination only; original WAL remains intact.
                new.execute('PRAGMA journal_mode=DELETE')
            with open(staging / name, 'r+b') as stream:
                os.fsync(stream.fileno())
        copied = inspect_data(staging)
        if not _equivalent(original, copied) or not _equivalent(original, inspect_data(source)):
            raise DataPathError('复制前后数据不一致，原数据已保留；请停止所有写入后再试')
        for directory, _, _ in os.walk(staging, topdown=False, onerror=_walk_error):
            _fsync_directory(directory)
        # The platform primitive rejects even an empty destination created
        # between our initial check and publication.
        _path(target)
        _rename_absent(staging, target)
        _fsync_directory(target.parent)
        return target
    except (OSError, sqlite3.Error) as error:
        raise DataPathError(f'安全复制失败，原数据未删除：{error}') from error
    finally:
        if staging.exists():
            shutil.rmtree(staging)
