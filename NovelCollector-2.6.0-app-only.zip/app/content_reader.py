"""Book-scoped reads and lazy character locations; prose stays in memory."""
from dataclasses import dataclass
from hashlib import sha256
from typing import Protocol

from novel_crawler.models import Book, Body, CrawlStop
from transport import PauseRequested


class ContentSpace:
    """Ordered source references with lengths learned on demand.

    A cursor is (source, offset); it never needs an invented full-book length.
    The mapping is backed by the scheduler's existing serializable state.
    """
    def __init__(self, state):
        self.state = state

    @property
    def sources(self):
        return self.state['sources']

    def next_source(self, source):
        index = self.sources.index(source) + 1
        return self.sources[index] if index < len(self.sources) else None

    def length(self, source):
        return self.state['lengths'].get(source)

    def discover(self, after, sources):
        index = self.sources.index(after) + 1
        for source in sources:
            if source not in self.sources:
                self.sources.insert(index, source)
                index += 1


@dataclass(frozen=True)
class ContentRead:
    response: object
    body: Body | None
    digest: str | None
    used_bootstrap: bool = False


class BookContentReader(Protocol):
    capabilities: frozenset[str]
    def cached(self, book: Book, source: str) -> bool: ...
    def read(self, book: Book, source: str, *, validators=None, bootstrap=None) -> ContentRead: ...
    def search(self, book: Book, term: str, cursor=None) -> dict: ...
    def clear(self): ...


class WebsiteContentReader:
    """Default reader for an adapter with observed directory/body links.

    Optional book-local search belongs to a site reader. Its results are only
    candidate locations; callers must read/match them before creating evidence.
    All requests use the supplied bounded, robots-aware transport.
    """
    capabilities = frozenset({'read'})

    def __init__(self, adapter, transport, cancellation):
        self.adapter, self.transport, self.cancellation = adapter, transport, cancellation
        self._cache = {}
        self.max_cached_sources = 4
        self.max_cached_chars = 4_000_000

    def cached(self, book, source):
        return (book.url, source) in self._cache

    def read(self, book, source, *, validators=None, bootstrap=None):
        if source not in book.body_urls:
            raise CrawlStop('content_source_outside_book', source)
        if self.cancellation.is_set():
            raise PauseRequested(source)
        key = (book.url, source)
        if key in self._cache:
            return self._cache[key]
        used_bootstrap = bootstrap is not None and bootstrap.final_url == source
        response = bootstrap if used_bootstrap else self.transport.fetch(source, validators=validators)
        if response.final_url != source:
            raise CrawlStop('body_redirect_changed_identity', source)
        if self.cancellation.is_set():
            raise PauseRequested(source)
        if response.status == 304:
            if not validators:
                raise CrawlStop('uncertified_304_stop', source)
            return ContentRead(response, None, None, used_bootstrap)
        if response.status != 200:
            raise CrawlStop('unexpected_response_status', source)
        body = self.adapter.body(response.html, response.final_url, book)
        result = ContentRead(response, body, sha256(body.text.encode('utf-8')).hexdigest(), used_bootstrap)
        while self._cache and (len(self._cache) >= self.max_cached_sources or
                              sum(len(value.body.text) for value in self._cache.values()) + len(body.text) > self.max_cached_chars):
            self._cache.pop(next(iter(self._cache)))
        self._cache[key] = result
        return result

    def search(self, book, term, cursor=None):
        """Optional book-local lookup, reserved for readers declaring 'search'.

        Return candidate source references/character ranges and a next cursor;
        these are hints, never authoritative counts or completed coverage.
        Readers must constrain candidates to this book's observed sources and
        translate provider positions into the same normalized prose coordinates.
        """
        raise CrawlStop('content_search_unsupported', book.url)

    def clear(self):
        self._cache.clear()
