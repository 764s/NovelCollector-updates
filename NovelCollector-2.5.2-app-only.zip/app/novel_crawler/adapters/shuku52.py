"""Stable, stateless 52shuku site rules, separate from every run's queue/config/state."""
import re
from urllib.parse import urljoin, urlsplit, urlunsplit
from ..htmltree import Node, parse_html
from ..models import SiteDefinition, Book, Body, UnknownTemplate

CHAPTER = re.compile(r'^(?:第[零〇一二三四五六七八九十百千万两\d]+[章节回卷部]|楔子(?:\s|$)|序章(?:\s|$)|引子(?:\s|$))')
DIRECTORY_PATH = re.compile(r'^/wuxia/(?:[^/]+/)*[A-Za-z0-9-]+\.html$')
BODY_PATH = re.compile(r'^(/wuxia/(?:[^/]+/)*[A-Za-z0-9-]+)_(\d+)\.html$')

class Shuku52Adapter:
    scope_description = '首页 → 武侠玄幻分类第一页 → 按当前列表顺序选择书目；仅扫描正文网页样本，未扫描分类分页或全站'
    definition = SiteDefinition('52shuku', '1', 'https://www.52shuku.net/', ('www.52shuku.net', '52shuku.net'))

    @property
    def board_types(self):
        from board_reader import BOARD_TYPES
        return dict(BOARD_TYPES)

    def normalize_board(self, value):
        from board_reader import normalize_board
        return normalize_board(value, self)

    def board_reader(self, board):
        from board_reader import BoardReader
        return BoardReader(self, board)

    @property
    def content_capabilities(self):
        return frozenset({'read'})

    def content_reader(self, transport, cancellation):
        from content_reader import WebsiteContentReader
        return WebsiteContentReader(self, transport, cancellation)

    def normalize(self, href, base):
        try:
            parts = urlsplit(urljoin(base, href))
            port = parts.port
        except ValueError:
            return None
        if parts.scheme not in ('http', 'https') or parts.hostname not in self.definition.allowed_hosts:
            return None
        if parts.username or parts.password or port not in (None, 80, 443) or parts.query:
            return None
        return urlunsplit(('https', 'www.52shuku.net', parts.path or '/', '', ''))

    def seed_kind(self, url):
        canonical = self.normalize(url, self.definition.homepage)
        if not canonical:
            raise ValueError('start URL is not an allowed site URL')
        path = urlsplit(canonical).path
        if path == '/':
            return 'homepage', canonical
        if path == '/wuxia/':
            return 'category', canonical
        if BODY_PATH.fullmatch(path):
            return 'body', canonical
        if DIRECTORY_PATH.fullmatch(path):
            return 'directory', canonical
        raise ValueError('start URL is not a recognized homepage/category/directory/body template')

    def directory_from_body(self, html, url):
        article = self._article(parse_html(html))
        body_match = BODY_PATH.fullmatch(urlsplit(url).path)
        boundaries = [n for n in article.walk() if n.has_class('pagination2')]
        if not body_match or len(boundaries) != 1:
            raise UnknownTemplate('body seed lacks a recognized pagination boundary')
        directories = []
        for node in boundaries[0].walk():
            if node.tag == 'a' and node.text().strip() == '目录':
                link = self.normalize(node.attrs.get('href', ''), url)
                if link and urlsplit(link).path == body_match[1] + '.html' and link not in directories:
                    directories.append(link)
        if len(directories) != 1:
            raise UnknownTemplate('body seed requires one observed same-book directory link')
        return directories[0]

    @staticmethod
    def _article(root):
        nodes = [n for n in root.walk() if n.tag == 'article' and n.has_class('article-content')]
        if len(nodes) != 1:
            raise UnknownTemplate('expected exactly one article.article-content')
        return nodes[0]

    @staticmethod
    def _title(root):
        titles = [n.text().strip() for n in root.walk() if n.tag == 'h1']
        if len(titles) != 1 or not titles[0]:
            raise UnknownTemplate('expected one non-empty h1')
        return titles[0]

    def category_url(self, html, url):
        root = parse_html(html)
        for node in root.walk():
            if node.tag == 'a' and '武侠玄幻' in node.text():
                link = self.normalize(node.attrs.get('href', ''), url)
                if link and urlsplit(link).path == '/wuxia/':
                    return link
        raise UnknownTemplate('homepage has no observed 武侠玄幻 category link')

    def book_links(self, html, url):
        root = parse_html(html)
        links = []
        # Prefer the actual list article headings, never broad keyword/search links.
        for node in root.walk():
            if node.tag != 'h2':
                continue
            for anchor in node.walk():
                if anchor.tag == 'a':
                    link = self.normalize(anchor.attrs.get('href', ''), url)
                    if link and DIRECTORY_PATH.fullmatch(urlsplit(link).path) and link not in links:
                        links.append(link)
        if not links:
            raise UnknownTemplate('category has no recognized h2 book-directory links')
        return links

    def directory(self, html, url):
        root = parse_html(html)
        article = self._article(root)
        if not DIRECTORY_PATH.fullmatch(urlsplit(url).path):
            raise UnknownTemplate('not a recognized book directory URL')
        if not any(n.tag == 'p' and n.text().strip() == '小说简介：' for n in article.walk()):
            raise UnknownTemplate('directory lacks 小说简介 marker')
        stem = urlsplit(url).path[:-5]
        urls = []
        for node in article.walk():
            if node.tag != 'li' or not node.has_class('mulu'):
                continue
            for anchor in node.walk():
                if anchor.tag != 'a':
                    continue
                link = self.normalize(anchor.attrs.get('href', ''), url)
                match = BODY_PATH.fullmatch(urlsplit(link).path) if link else None
                if match and match[1] == stem and link not in urls:
                    urls.append(link)
        if not urls:
            raise UnknownTemplate('directory has no same-book li.mulu body links')
        return Book(url, self._title(root), tuple(urls))

    def body(self, html, url, book):
        root = parse_html(html)
        article = self._article(root)
        match = BODY_PATH.fullmatch(urlsplit(url).path)
        if not match or match[1] != urlsplit(book.url).path[:-5]:
            raise UnknownTemplate('body URL does not belong to this book')
        boundaries = [n for n in article.walk() if n.has_class('pagination2')]
        if len(boundaries) != 1:
            raise UnknownTemplate('body requires one pagination2 boundary')
        boundary = boundaries[0]
        paragraphs, reached = [], False
        for child in article.children:
            if child is boundary:
                reached = True
                break
            if isinstance(child, str):
                if child.strip():
                    raise UnknownTemplate('unexpected loose body text')
                continue
            if child.tag in ('script', 'style', 'noscript'):
                continue
            if child.tag != 'p':
                raise UnknownTemplate(f'unrecognized pre-pagination container: {child.tag}')
            # Linked paragraphs before pagination are not established prose template.
            if any(n.tag == 'a' for n in child.walk()):
                raise UnknownTemplate('unexpected linked paragraph before pagination')
            value = child.text().strip()
            if value:
                paragraphs.append(value)
        if not reached or not paragraphs:
            raise UnknownTemplate('pagination not a direct child or no paragraphs')
        if any(p.startswith('小说简介：') for p in paragraphs):
            raise UnknownTemplate('directory content cannot be searched as body')
        removed = 0
        if url == book.body_urls[0]:
            first_chapter = next((i for i, p in enumerate(paragraphs[:60]) if CHAPTER.match(p)), None)
            if first_chapter is None:
                raise UnknownTemplate('first page has no known chapter boundary; preamble unsafe')
            removed = first_chapter
            paragraphs = paragraphs[first_chapter:]
        # Chapter headings and site promotions are not novel prose matches.
        paragraphs = [p for p in paragraphs if not CHAPTER.match(p) and not p.startswith(('Tips：', '传送门：', '所属专题：'))]
        if not paragraphs:
            raise UnknownTemplate('no prose remains after removing metadata')
        next_urls = []
        for anchor in boundary.walk():
            if anchor.tag == 'a' and anchor.text().strip() == '下一页':
                link = self.normalize(anchor.attrs.get('href', ''), url)
                candidate = BODY_PATH.fullmatch(urlsplit(link).path) if link else None
                if candidate and candidate[1] == match[1] and link not in next_urls:
                    next_urls.append(link)
        return Body('\n'.join(paragraphs), tuple(next_urls), removed)
