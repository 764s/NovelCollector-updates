"""Bounded HTTPS reads from GitHub's release API, without a CLI dependency.

All requests are anonymous. No tokens, CLI, cookies or system credentials are
read. Asset redirects may reach only GitHub's asset hosts. No release-provided
URLs are used.
"""
import http.client
import re
import ssl
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, HTTPSHandler, Request, build_opener


MAX_REDIRECTS = 3
ASSET_HOSTS = frozenset({'release-assets.githubusercontent.com', 'objects.githubusercontent.com'})


class ReleaseHTTPError(Exception):
    def __init__(self, status):
        self.status = status
        super().__init__(status)


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _asset_redirect(url):
    try:
        if not isinstance(url, str) or not 1 <= len(url) <= 8192 or any(ord(c) < 33 or ord(c) == 127 for c in url):
            raise ValueError()
        parsed = urlsplit(url)
        if (parsed.scheme != 'https' or parsed.hostname not in ASSET_HOSTS
                or parsed.port not in (None, 443) or parsed.username is not None
                or parsed.password is not None or parsed.fragment):
            raise ValueError()
    except ValueError:
        raise ReleaseHTTPError('unsafe_redirect') from None
    return url


def read_api(repository, asset_id=None, *, limit=512 * 1024, timeout=30):
    if (not isinstance(repository, str)
            or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,99}/[A-Za-z0-9][A-Za-z0-9_.-]{0,99}', repository)):
        raise ReleaseHTTPError('invalid_release')
    if asset_id is not None and (type(asset_id) is not int or not 0 < asset_id < 1 << 63):
        raise ReleaseHTTPError('invalid_release')
    if type(limit) is not int or limit < 1 or timeout <= 0:
        raise ReleaseHTTPError('invalid_release')
    suffix = 'latest' if asset_id is None else 'assets/' + str(asset_id)
    url = 'https://api.github.com/repos/' + repository + '/releases' + '/' + suffix
    headers = {'Accept': 'application/vnd.github+json' if asset_id is None else 'application/octet-stream',
               'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'NovelCollector-Updater',
               'Accept-Encoding': 'identity'}
    deadline = time.monotonic() + timeout
    try:
        opener = build_opener(_NoRedirect(), HTTPSHandler(context=ssl.create_default_context()))
        for redirect in range(MAX_REDIRECTS + 1):
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise ReleaseHTTPError('timeout')
            try:
                response = opener.open(Request(url, headers=headers, method='GET'), timeout=remaining)
            except HTTPError as error:
                try:
                    if error.code in (301, 302, 303, 307, 308):
                        if asset_id is None or redirect == MAX_REDIRECTS:
                            raise ReleaseHTTPError('unsafe_redirect') from None
                        url = _asset_redirect(error.headers.get('Location'))
                        headers = {'Accept': 'application/octet-stream', 'User-Agent': 'NovelCollector-Updater',
                                   'Accept-Encoding': 'identity'}
                        continue
                    status = ('rate_limited' if error.code == 429 or (error.code == 403 and
                                  (error.headers.get('X-RateLimit-Remaining') == '0' or error.headers.get('Retry-After'))) else
                              'sso_required' if error.code == 403 and error.headers.get('X-GitHub-SSO', '').startswith('required') else
                              'auth_required' if error.code == 401 else
                              'access_or_missing' if error.code == 404 else
                              'access_denied' if error.code == 403 else 'network_error')
                    raise ReleaseHTTPError(status) from None
                finally:
                    error.close()
            with response:
                if response.status != 200:
                    raise ReleaseHTTPError('network_error')
                length = response.headers.get('Content-Length')
                if length is not None:
                    if not re.fullmatch(r'[0-9]{1,12}', length):
                        raise ReleaseHTTPError('invalid_release')
                    if int(length) > limit:
                        raise ReleaseHTTPError('response_too_large')
                encoding = response.headers.get('Content-Encoding', 'identity').lower()
                if encoding != 'identity':
                    raise ReleaseHTTPError('invalid_release')
                data = bytearray()
                while True:
                    if time.monotonic() >= deadline:
                        raise ReleaseHTTPError('timeout')
                    chunk = response.read1(min(65536, limit + 1 - len(data)))
                    if time.monotonic() >= deadline:
                        raise ReleaseHTTPError('timeout')
                    if not chunk:
                        break
                    data.extend(chunk)
                    if len(data) > limit:
                        raise ReleaseHTTPError('response_too_large')
                if length is not None and len(data) != int(length):
                    raise ReleaseHTTPError('network_error')
                return bytes(data)
    except (TimeoutError, URLError) as error:
        status = 'timeout' if isinstance(error, TimeoutError) or isinstance(getattr(error, 'reason', None), TimeoutError) else 'network_error'
        raise ReleaseHTTPError(status) from None
    except (OSError, http.client.HTTPException, ValueError):
        raise ReleaseHTTPError('network_error') from None
