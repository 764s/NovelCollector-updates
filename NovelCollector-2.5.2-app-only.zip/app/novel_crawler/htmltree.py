"""Small dependency-free HTML tree with the implicit <p> closing used by this site."""
from dataclasses import dataclass, field
from html.parser import HTMLParser

@dataclass
class Node:
    tag: str
    attrs: dict = field(default_factory=dict)
    children: list = field(default_factory=list)

    def has_class(self, value):
        return value in self.attrs.get('class', '').split()

    def walk(self):
        yield self
        for child in self.children:
            if isinstance(child, Node):
                yield from child.walk()

    def text(self):
        if self.tag in ('script', 'style', 'noscript'):
            return ''
        return ''.join(c.text() if isinstance(c, Node) else c for c in self.children)

class TreeParser(HTMLParser):
    VOID = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}
    BLOCK = {'p', 'div', 'ul', 'ol', 'article', 'section', 'h1', 'h2', 'h3', 'hr'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root = Node('document')
        self.stack = [self.root]

    def handle_starttag(self, tag, attrs):
        # The real site leaves its last body paragraph unclosed before pagination.
        if tag in self.BLOCK:
            for i in range(len(self.stack) - 1, 0, -1):
                if self.stack[i].tag == 'p':
                    self.stack = self.stack[:i]
                    break
                if self.stack[i].tag in ('article', 'div', 'body'):
                    break
        node = Node(tag, dict(attrs))
        self.stack[-1].children.append(node)
        if tag not in self.VOID:
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in self.VOID:
            self.handle_endtag(tag)

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                self.stack = self.stack[:i]
                return

    def handle_data(self, data):
        self.stack[-1].children.append(data)

def parse_html(html):
    parser = TreeParser()
    parser.feed(html)
    parser.close()
    return parser.root
