"""Local-only HTTP application. All collection data stays in fixed per-user storage."""
import argparse
import base64
import subprocess
import shutil
import atexit
import csv
from datetime import datetime, timezone
import io
import json
import mimetypes
import os
from pathlib import Path
import secrets
import signal
import socket
import sys
import threading
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit
import webbrowser

from core import Manager
from downloader import Downloader
from data_paths import (DataInstanceLock, DataPathError, inspect_data,
                        resolve_data_dir, snapshot_data)
from updater import Updater
from github_updates import GitHubUpdates

VERSION = '2.5.2'
ROOT = Path(__file__).resolve().parent
HOME = Path(os.environ.get("NOVELCOLLECTOR_HOME", str(ROOT.parent))).resolve()


class InstanceLock(DataInstanceLock):
    def __init__(self, path):
        try:
            super().__init__(path)
        except DataPathError as error:
            raise RuntimeError(str(error)) from error


def clean_csv(value):
    text = '' if value is None else str(value)
    return "'" + text if text.lstrip().startswith(('=', '+', '-', '@', '\t', '\r')) else text


def report_csv(rows):
    output = io.StringIO(newline='')
    writer = csv.writer(output)
    writer.writerow(['书名', '目录链接', '累计加权次数', '关键词命中次数', '命中来源', '已读取来源', '已发现来源', '来源更新日期', '本地检查时间', '状态', '累计已检测字数', '基础样本每万字评分', '策略汇总', '搜书来源'])
    for row in rows:
        writer.writerow([clean_csv(row.get(k)) for k in ('title', 'directory_url', 'score')] +
            [clean_csv(json.dumps(row.get('counts', {}), ensure_ascii=False))] +
            [clean_csv(row.get(k)) for k in ('matching_pages', 'scanned_pages', 'discovered_pages', 'source_updated_at', 'checked_at', 'status')] +
            [clean_csv(row.get('scanned_chars')), clean_csv(row.get('ranking_score')), clean_csv(json.dumps(row.get('strategy_summary'), ensure_ascii=False)),
             clean_csv(json.dumps(row.get('board_sources', []), ensure_ascii=False))])
    return output.getvalue().encode('utf-8-sig')


class Application:
    def __init__(self):
        self.updater = Updater(HOME, VERSION) if (HOME / "runtime-compat.json").is_file() else None
        self.data_dir = resolve_data_dir()
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.instance_lock = InstanceLock(self.data_dir / '.instance.lock')
        try:
            # Existing storage is validated before managers can create tables
            # or recover tasks. Never repair partial or unsupported schemas.
            if any(path.name != '.instance.lock' for path in self.data_dir.iterdir()):
                inspect_data(self.data_dir)
            self.manager = Manager(self.data_dir)
            self.downloader = Downloader(self.data_dir)
        except Exception:
            if hasattr(self, 'manager'):
                self.manager.close()
            self.instance_lock.close()
            raise
        self.action_lock = threading.RLock()
        self.token = secrets.token_urlsafe(32)
        self.server = None
        self.closed = False
        self.maintenance = False
        self.restart = False
        self.pending_stage = None
        self.github_updates = GitHubUpdates(VERSION)

    def snapshot(self):
        state = self.manager.snapshot()
        state['downloads'] = self.downloader.snapshot()
        state['app'] = {'version': VERSION, 'data_dir': str(self.data_dir), 'local_only': True,
            'scope': '52书库 · 武侠玄幻 · 每次最多 5 本 · 按正文字数采样',
            'formula': '基础样本每万字评分 = Σ（基础样本命中次数 × 权重）÷ 基础样本正文字数 × 10000',
            'updates': self.updater.status() if self.updater else {'enabled': False},
            'program_dir': str(HOME), 'data_format': 1}
        return state

    def action(self, route, body):
        with self.action_lock:
            if self.maintenance:
                raise ValueError('程序正在更新并重启，请稍候重新打开')
            if route == '/api/data/open':
                if os.name == 'nt':
                    os.startfile(str(self.data_dir))
                elif shutil.which('xdg-open'):
                    subprocess.Popen(['xdg-open', str(self.data_dir)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                else:
                    raise ValueError('此环境没有文件管理器，请复制页面显示的数据目录手动打开')
                return {'ok': True}
            if route == '/api/updates/github/check':
                return self.github_updates.check()
            if route == '/api/updates/github/prepare':
                if not self.updater:
                    raise ValueError('源码运行模式不能安装更新，请使用完整便携包')
                result = self.github_updates.download()
                if result.get('status') != 'downloaded':
                    raise ValueError(result.get('message', 'GitHub 更新暂不可用'))
                if self.pending_stage:
                    self.updater.discard(self.pending_stage)
                    self.pending_stage = None
                preview = self.updater.stage(result['archive'])
                self.pending_stage = preview['stage_id']
                return preview
            if route == '/api/updates/prepare':
                if not self.updater:
                    raise ValueError('当前为源码运行模式，请在完整便携程序中安装更新')
                encoded = body.get('archive', '')
                if not isinstance(encoded, str) or len(encoded) > 28_000_000:
                    raise ValueError('更新包过大')
                try:
                    raw = base64.b64decode(encoded, validate=True)
                except Exception:
                    raise ValueError('更新包编码无效')
                if self.pending_stage:
                    self.updater.discard(self.pending_stage)
                    self.pending_stage = None
                preview = self.updater.stage(raw)
                self.pending_stage = preview['stage_id']
                return preview
            if route in ('/api/updates/install', '/api/updates/rollback'):
                if not self.updater or body.get('confirmed') is not True:
                    raise ValueError('请明确确认安装或回退程序')
                workers = (getattr(self.manager, 'worker', None), self.downloader.thread)
                if any(w and w.is_alive() for w in workers):
                    raise ValueError('请先暂停搜集和下载，并等待当前请求结束，再更新')
                # Serialize all state-changing actions; no writer is alive. SQLite backup
                # reads committed WAL contents rather than copying an unsafe .db file.
                backup = self.data_dir.parent / (self.data_dir.name + '-backups') / (datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S') + '-' + secrets.token_hex(4))
                with self.manager.lock, self.downloader.lock:
                    snapshot_data(self.data_dir, backup)
                if route.endswith('/install'):
                    result = self.updater.install(body['stage_id'])
                else:
                    result = self.updater.rollback(minimum_version=self.manager.minimum_reader_version())
                self.maintenance = True
                self.restart = True
                # The immutable old release can remain open on Windows. Only the
                # pointer changes; the stable launcher/runtime are never replaced.
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return {'ok': True, 'backup_dir': str(backup), 'update': result, 'message': '已备份并切换版本，正在重新启动'}
            if route == '/api/collections':
                return self.manager.create_collection(body)
            if route == '/api/collections/update':
                return self.manager.update_collection(body['id'], body['config'])
            if route == '/api/scans/start':
                if self.downloader.snapshot()['active_job']:
                    raise ValueError('请先暂停下载任务，再启动搜集')
                return self.manager.start_scan(body['collection_id'], body.get('content_seed'), body.get('directory_url'), body.get('refresh_board', False))
            if route == '/api/scans/resume':
                if self.downloader.snapshot()['active_job']:
                    raise ValueError('请先暂停下载任务，再继续搜集')
                return self.manager.resume_job(body['job_id'])
            if route == '/api/scans/pause':
                return self.manager.pause_job(body['job_id'])
            if route == '/api/downloads/start':
                if self.manager.snapshot().get('active_job'):
                    raise ValueError('请先暂停搜集任务，再启动下载')
                items = body.get('items', [])
                if not isinstance(items, list):
                    raise ValueError('下载列表无效')
                # Only known collection-result pages may enter the downloader.
                known = {(p['url'], r['directory_url']) for r in self.manager.snapshot().get('results', []) for p in r.get('pages', [])}
                known.update((r['url'], r['directory_url']) for r in self.downloader.snapshot()['records'])
                if any(not isinstance(i, dict) or (i.get('url'), i.get('directory_url')) not in known for i in items):
                    raise ValueError('只能下载已搜集到的正文页，不能输入任意地址')
                return self.downloader.start(items, body.get('rights_confirmed'), trusted_pages=known)
            if route == '/api/downloads/pause':
                return self.downloader.pause(body['job_id'])
            if route == '/api/downloads/resume':
                if self.manager.snapshot().get('active_job'):
                    raise ValueError('请先暂停搜集任务，再继续下载')
                return self.downloader.resume(body['job_id'], body.get('rights_confirmed'))
            if route == '/api/shutdown':
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return {'ok': True, 'message': '正在保存进度并关闭'}
            raise ValueError('未知操作')

    def close(self):
        if self.closed:
            return
        self.closed = True
        self.github_updates = GitHubUpdates(VERSION)
        self.manager.close()
        self.downloader.close()
        writers = (getattr(self.manager, 'worker', None), self.downloader.thread)
        if any(worker and worker.is_alive() for worker in writers):
            # Never permit another instance to enter while an old writer lives.
            # The OS releases this process-owned lock when process exit ends daemons.
            print('等待网络任务结束；实例锁保留到进程退出。', file=sys.stderr, flush=True)
        else:
            self.instance_lock.close()


def make_handler(app):
    class Handler(BaseHTTPRequestHandler):
        server_version = 'NovelCollector/' + VERSION
        sys_version = ''
        protocol_version = 'HTTP/1.1'

        def setup(self):
            super().setup()
            self.connection.settimeout(10)

        def log_message(self, fmt, *args):
            # Never log tokens, request bodies, source text, or export content.
            if len(args) >= 2 and str(args[1]).startswith(('4', '5')):
                sys.stderr.write('[HTTP] %s\n' % args[1])

        def allowed(self, api=False):
            host = self.headers.get('Host', '')
            expected = f'127.0.0.1:{self.server.server_port}'
            if host != expected:
                self.respond(403, {'error': '仅允许本机地址访问'})
                return False
            origin = self.headers.get('Origin')
            if origin is not None and origin != 'http://' + expected:
                self.respond(403, {'error': '拒绝跨站请求'})
                return False
            if self.headers.get('Sec-Fetch-Site') == 'cross-site':
                self.respond(403, {'error': '拒绝跨站请求'})
                return False
            if api and not secrets.compare_digest(self.headers.get('X-App-Token', ''), app.token):
                self.respond(401, {'error': '访问凭据失效。请使用启动窗口中的完整地址重新打开'})
                return False
            return True

        def respond(self, status, value, content_type='application/json; charset=utf-8', filename=None):
            data = json.dumps(value, ensure_ascii=False, allow_nan=False).encode() if isinstance(value, (dict, list)) else value
            if isinstance(data, str):
                data = data.encode()
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Referrer-Policy', 'no-referrer')
            self.send_header('X-Frame-Options', 'DENY')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
            if filename:
                self.send_header('Content-Disposition', 'attachment; filename="' + filename + '"')
            self.end_headers()
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def do_GET(self):
            parsed = urlsplit(self.path)
            path = parsed.path
            if not self.allowed(api=path.startswith('/api/')):
                return
            try:
                if path == '/api/state':
                    self.respond(200, app.snapshot())
                elif path == '/api/pilot':
                    pilot = json.loads((ROOT / 'example' / 'prior-pilot.json').read_text('utf-8'))
                    self.respond(200, pilot)
                elif path == '/api/report':
                    params = parse_qs(parsed.query)
                    collection_id = params.get('collection_id', [''])[0]
                    rows = [r for r in app.manager.snapshot().get('results', []) if r.get('collection_id') == collection_id]
                    if not rows:
                        raise ValueError('该搜集器尚无可导出的结果')
                    fmt = params.get('format', ['csv'])[0]
                    if fmt == 'json':
                        self.respond(200, {'generated_at': datetime.now(timezone.utc).isoformat(),
                            'formula': 'sum(distributed_keyword_count * weight) / distributed_body_chars * 10000',
                            'count_formula': 'sum(keyword_count * weight)', 'aggregation_policy': 'distributed_char_density_v2',
                            'contains_fulltext': False, 'results': rows}, filename='novel-links.json')
                    elif fmt == 'csv':
                        self.respond(200, report_csv(rows), 'text/csv; charset=utf-8', 'novel-links.csv')
                    else:
                        raise ValueError('不支持的报告格式')
                elif path.startswith('/api/downloads/file/'):
                    record_id = path.rsplit('/', 1)[-1]
                    version_raw = parse_qs(parsed.query).get('version', [None])[0]
                    version = None if version_raw is None else int(version_raw)
                    file = app.downloader.file(record_id, version)
                    self.respond(200, file.read_bytes(), 'text/plain; charset=utf-8', file.name)
                elif path in ('/', '/index.html', '/style.css', '/app.js', '/favicon.svg'):
                    target = ROOT / 'static' / ('index.html' if path in ('/', '/index.html') else path[1:])
                    if not target.is_file():
                        self.respond(404, {'error': '页面不存在'})
                    else:
                        self.respond(200, target.read_bytes(), mimetypes.guess_type(str(target))[0] or 'application/octet-stream')
                else:
                    self.respond(404, {'error': '页面不存在'})
            except (ValueError, KeyError, TypeError) as error:
                self.respond(400, {'error': str(error)[:400]})
            except Exception:
                traceback.print_exc()
                self.respond(500, {'error': '读取失败，请查看程序窗口；任务记录仍保存在本地'})

        def do_POST(self):
            if not self.allowed(api=True):
                return
            if self.headers.get('Transfer-Encoding'):
                self.respond(400, {'error': '不支持此请求编码'})
                self.close_connection = True
                return
            try:
                length = int(self.headers.get('Content-Length', '0'))
                limit = 28_000_000 if urlsplit(self.path).path == '/api/updates/prepare' else 1_000_000
                if not 0 < length <= limit:
                    self.respond(413, {'error': '请求过大或为空'})
                    self.close_connection = True
                    return
                if not self.headers.get('Content-Type', '').startswith('application/json'):
                    self.respond(415, {'error': '需要 JSON 请求'})
                    self.close_connection = True
                    return
                body = json.loads(self.rfile.read(length))
                if not isinstance(body, dict):
                    raise ValueError('请求必须是对象')
                response = app.action(urlsplit(self.path).path, body)
                self.respond(200, response if response is not None else {'ok': True})
            except (ValueError, KeyError, TypeError) as error:
                self.respond(400, {'error': str(error)[:400]})
            except Exception:
                traceback.print_exc()
                self.respond(500, {'error': '操作失败，请查看程序窗口；已保存的数据不会被清除'})
    return Handler


def main():
    # Redirected Windows output otherwise uses the ANSI code page, which can
    # fail before the local URL is printed on a non-Chinese installation.
    if os.name == 'nt':
        for stream in (sys.stdout, sys.stderr):
            if stream is not None and hasattr(stream, 'reconfigure'):
                stream.reconfigure(encoding='utf-8', errors='backslashreplace')
    parser = argparse.ArgumentParser(description='关键词藏书夹 · 本地网页管理器')
    parser.add_argument('--host', default='127.0.0.1', choices=['127.0.0.1'], help='仅本机回环地址')
    parser.add_argument('--port', type=int, default=8765, help='本地端口，0 表示自动选择')
    parser.add_argument('--no-browser', action='store_true', help='不自动打开浏览器')
    parser.add_argument('--version', action='version', version=VERSION)
    args = parser.parse_args()
    if not 0 <= args.port <= 65535:
        parser.error('端口必须在 0–65535')
    app = Application()
    try:
        try:
            server = ThreadingHTTPServer((args.host, args.port), make_handler(app))
        except OSError:
            if args.port == 0:
                raise
            server = ThreadingHTTPServer((args.host, 0), make_handler(app))
        server.daemon_threads = True
        app.server = server
        url = f'http://127.0.0.1:{server.server_port}/#token={app.token}'
        print('关键词藏书夹 v' + VERSION, flush=True)
        print('仅本机访问：' + url, flush=True)
        print('本地数据：' + str(app.data_dir), flush=True)
        print('关闭网页不会退出程序。点击网页“退出程序”或在此窗口按 Ctrl+C。', flush=True)
        if not args.no_browser:
            webbrowser.open(url)
        def stop(signum, frame):
            threading.Thread(target=server.shutdown, daemon=True).start()
        signal.signal(signal.SIGINT, stop)
        if hasattr(signal, 'SIGTERM'):
            signal.signal(signal.SIGTERM, stop)
        server.serve_forever(poll_interval=.3)
        server.server_close()
    finally:
        app.close()
    if getattr(app, 'restart', False):
        script = HOME / 'app' / 'main.py' if (HOME / 'runtime-compat.json').is_file() else ROOT / 'main.py'
        command = [sys.executable, '-E', '-s', '-B', '-u', str(script), '--port', str(args.port)]
        if args.no_browser:
            command.append('--no-browser')
        subprocess.Popen(command, cwd=str(HOME))


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('无法启动：' + str(exc), file=sys.stderr, flush=True)
        if os.name == 'nt' and sys.stdin and sys.stdin.isatty():
            input('按 Enter 退出…')
        raise SystemExit(1)
