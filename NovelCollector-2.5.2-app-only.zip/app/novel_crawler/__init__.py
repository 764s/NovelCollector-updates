"""Deterministic, body-only novel keyword crawler (no model APIs)."""
__version__ = '1.1.0'
