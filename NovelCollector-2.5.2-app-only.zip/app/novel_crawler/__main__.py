import argparse
import sys
from pathlib import Path
from .adapters import ADAPTERS
from .engine import Crawler
from .models import RunConfig


def main():
    parser = argparse.ArgumentParser(description='不调用大模型的正文关键词爬取器；默认低频、单并发、有界试跑')
    parser.add_argument('--site', choices=sorted(ADAPTERS), default='52shuku')
    parser.add_argument('--keyword', action='append', help='可重复指定字面关键词；与文件条目合并、去重，ANY 匹配')
    parser.add_argument('--keyword-file', help='UTF-8 文件，每行一个关键词，忽略空行')
    parser.add_argument('--start-url', help='本站已识别首页、武侠分类、小说目录或正文网页')
    parser.add_argument('--max-books', type=int, default=5)
    parser.add_argument('--pages-per-book', type=int, default=20)
    parser.add_argument('--max-body-pages', type=int, default=100)
    parser.add_argument('--interval', type=float, default=3.2)
    parser.add_argument('--timeout', type=float, default=30)
    parser.add_argument('--max-requests', type=int, default=160)
    parser.add_argument('--output', default='results/run')
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    try:
        terms = list(args.keyword or [])
        if args.keyword_file:
            terms.extend(line.strip() for line in Path(args.keyword_file).read_text(encoding='utf-8-sig').splitlines() if line.strip())
        if not terms and (args.keyword or args.keyword_file):
            raise ValueError('keyword input contains no non-empty terms')
        terms = list(dict.fromkeys(terms or ['修仙']))
        config = RunConfig(keyword=terms[0], keywords=tuple(terms[1:]), start_url=args.start_url, max_books=args.max_books, pages_per_book=args.pages_per_book, max_body_pages=args.max_body_pages, interval=args.interval, timeout=args.timeout, max_requests=args.max_requests)
        crawler = Crawler(ADAPTERS[args.site](), config, args.output, args.resume)
        result = crawler.run()
    except (ValueError, OSError) as error:
        print(f'Error: {error}', file=sys.stderr)
        return 2
    print(f"status={result['status']}, scanned_body_pages={result['scanned_body_pages']}, output={args.output}")
    return 0 if result['status'] == 'pilot_complete' else 1

if __name__ == '__main__':
    raise SystemExit(main())
