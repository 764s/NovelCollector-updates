"""52shuku list capabilities. Public forms/next links are observed, never guessed.

The scheduler sees the same book-reference batch for categories, ranks, tags,
articles and native search. Site-specific extraction remains in this adapter.
"""
from urllib.parse import parse_qsl, quote, unquote, urlencode, urljoin, urlsplit, urlunsplit
import re

from novel_crawler.htmltree import parse_html
from novel_crawler.models import CrawlStop, UnknownTemplate


BOARD_TYPES = {'category': '分类榜', 'ranking': '固定榜', 'tag': 'tag 榜',
               'article': '收录文', 'annual_article': '年度总结文', 'site_search': '网站关键词搜索'}
QUERY_NAMES = {'keyboard', 'keyword', 'keywords', 'searchkey', 'q', 'query', 'wd', 'word', 's'}


def safe_url(value, adapter, base=None):
    try:
        if not isinstance(value, str) or len(value) > 8192:
            raise ValueError()
        p = urlsplit(urljoin(base or adapter.definition.homepage, value))
        if (p.scheme not in ('http', 'https') or p.hostname not in adapter.definition.allowed_hosts
                or p.username or p.password or p.port not in (None, 80, 443)
                or p.fragment or '\\' in value
                or any(ord(c) <= 32 for c in value)
                or any(x in ('.', '..') for x in p.path.split('/'))):
            raise ValueError()
        if re.search(r'%(?![0-9a-fA-F]{2})', p.path):
            raise ValueError()
        segments = [unquote(part, errors='strict') for part in p.path.split('/')]
        if any(part in ('.', '..') or any(c in part for c in ('/', '\\', '%'))
               or any(ord(c) <= 32 or ord(c) == 127 for c in part) for part in segments):
            raise ValueError()
        path = '/'.join(quote(part, safe=":@!$&'()*+,;=-._~") for part in segments)
        pairs = parse_qsl(p.query, keep_blank_values=True, max_num_fields=40)
        if any(not k or len(k) > 128 or len(v) > 2048 or any(ord(c) < 32 for c in k + v) for k, v in pairs):
            raise ValueError()
        return urlunsplit(('https', urlsplit(adapter.definition.homepage).hostname, path or '/', urlencode(pairs), ''))
    except (ValueError, TypeError, AttributeError, UnicodeError):
        raise ValueError('榜地址须为本站有效的 HTTPS 地址') from None


def normalize_board(value, adapter):
    if not isinstance(value, dict) or set(value) != {'type', 'base_url', 'keys'}:
        raise ValueError('榜身份须包含 type、base_url、keys 三个字符串')
    if not isinstance(value['type'], str) or value['type'] not in BOARD_TYPES:
        raise ValueError('此网站适配器尚不支持该榜类型')
    keys = value['keys']
    if not isinstance(keys, str) or len(keys) > 512 or any(ord(c) < 32 for c in keys):
        raise ValueError('榜 keys 须为最多 512 个字符的字符串')
    if value['type'] == 'site_search' and not keys.strip():
        raise ValueError('网站搜索榜必须填写搜索词 keys')
    if not isinstance(value['base_url'], str) or not value['base_url'].startswith('https://'):
        raise ValueError('榜基础地址须使用 HTTPS')
    return {'type': value['type'], 'base_url': safe_url(value['base_url'], adapter), 'keys': keys}


class BoardTransportAdapter:
    """Allow queries only in the board reader's currently authorized request."""
    def __init__(self, adapter):
        self.adapter, self.definition = adapter, adapter.definition
        self.request = None

    def __getattr__(self, key):
        return getattr(self.adapter, key)

    def validate_request_url(self, value):
        canonical = safe_url(value, self.adapter)
        if self.request:
            expected = urlsplit(self.request['url'])
            actual = urlsplit(canonical)
            # Search engines may redirect a submitted form to a search-result
            # URL. Still restrict it to the observed search endpoint directory.
            prefix = expected.path.rsplit('/', 1)[0] + '/'
            search_redirect = ('search' in expected.path.lower() and prefix != '/'
                               and actual.path.startswith(prefix))
            if (actual.path.rstrip('/') == expected.path.rstrip('/') or search_redirect):
                return canonical
        if urlsplit(canonical).query:
            raise ValueError('unobserved query URL')
        return self.adapter.seed_kind(canonical)[1]


class BoardReader:
    def __init__(self, adapter, board):
        self.adapter, self.board = adapter, board

    def initial(self):
        return {'url': self.board['base_url'], 'method': 'GET'}

    def _book(self, anchor, url):
        try:
            link = safe_url(anchor.attrs.get('href', ''), self.adapter, url)
            if urlsplit(link).query:
                return None
            kind, link = self.adapter.seed_kind(link)
            if kind == 'directory':
                return {'directory_url': link, 'title': anchor.text().strip()[:512]}
        except ValueError:
            pass
        return None

    def _search_form(self, root, url):
        candidates = []
        for form in root.walk():
            if form.tag != 'form':
                continue
            inputs = [n for n in form.walk() if n.tag == 'input']
            query = [n for n in inputs if n.attrs.get('name', '').lower() in QUERY_NAMES
                     and n.attrs.get('type', 'text').lower() in ('text', 'search')]
            if len(query) != 1:
                continue
            method = form.attrs.get('method', 'get').upper()
            if method not in ('GET', 'POST'):
                continue
            try:
                target = safe_url(form.attrs.get('action') or url, self.adapter, url)
            except ValueError:
                raise UnknownTemplate('网站搜索表单的目标地址不受本站适配器支持') from None
            fields = []
            for node in inputs:
                name, kind = node.attrs.get('name'), node.attrs.get('type', 'text').lower()
                if not name or 'disabled' in node.attrs:
                    continue
                if node is query[0]:
                    fields.append([name, self.board['keys']])
                elif kind == 'hidden' or (kind in ('radio', 'checkbox') and 'checked' in node.attrs):
                    fields.append([name, node.attrs.get('value', '')])
                elif kind not in ('submit', 'button', 'reset', 'radio', 'checkbox'):
                    raise UnknownTemplate('搜索表单包含未支持的必填字段')
            for select in (n for n in form.walk() if n.tag == 'select' and n.attrs.get('name')):
                options = [n for n in select.walk() if n.tag == 'option' and 'disabled' not in n.attrs]
                selected = next((n for n in options if 'selected' in n.attrs), options[0] if options else None)
                if selected:
                    fields.append([select.attrs['name'], selected.attrs.get('value', selected.text())])
            if len(fields) > 40 or any(len(k) > 128 or len(v) > 2048 or any(ord(c) < 32 for c in k + v) for k, v in fields):
                raise UnknownTemplate('搜索表单字段超出限制')
            if method == 'GET':
                p = urlsplit(target)
                target = urlunsplit((p.scheme, p.netloc, p.path, urlencode([tuple(pair) for pair in fields]), ''))
                candidates.append({'url': target, 'method': 'GET'})
            else:
                candidates.append({'url': target, 'method': 'POST', 'fields': fields})
        unique = {str(item): item for item in candidates}
        if len(unique) != 1:
            raise UnknownTemplate('未找到唯一可用的本站搜索表单；网站搜索未退回分类列表')
        return next(iter(unique.values()))

    def read(self, html, url, reader):
        root = parse_html(html)
        mode = self.board['type']
        reader = dict(reader)
        if not reader.get('entered'):
            reader['entered'] = True
            if mode == 'site_search':
                return [], self._search_form(root, url), reader
            if mode == 'category' and urlsplit(url).path == '/':
                return [], {'url': self.adapter.category_url(html, url), 'method': 'GET'}, reader
            if mode == 'tag' and self.board['keys']:
                targets = set()
                for anchor in root.walk():
                    if anchor.tag != 'a' or anchor.text().strip() != self.board['keys']:
                        continue
                    try:
                        target = safe_url(anchor.attrs.get('href', ''), self.adapter, url)
                    except ValueError:
                        continue
                    if target != url and ('tag' in urlsplit(target).path.lower() or 'tag' in anchor.attrs.get('rel', '').split()):
                        targets.add(target)
                if len(targets) > 1:
                    raise UnknownTemplate('tag 标识对应多个不同入口')
                if targets:
                    return [], {'url': targets.pop(), 'method': 'GET'}, reader
        links = []
        if mode in ('article', 'annual_article'):
            containers = [n for n in root.walk() if n.tag == 'article' and n.has_class('article-content')]
            if len(containers) != 1:
                raise UnknownTemplate('收录文缺少唯一的 article.article-content 区域')
            # A novel directory/body must never be mistaken for a recommendation.
            if any(n.has_class('mulu') or n.has_class('pagination2') for n in containers[0].walk()):
                raise UnknownTemplate('小说目录或正文不能作为收录文')
            links = [book for a in containers[0].walk() if a.tag == 'a' and (book := self._book(a, url))]
        else:
            headings = [n for n in root.walk() if n.tag in ('h2', 'h3')]
            for heading in headings:
                book = next((b for a in heading.walk() if a.tag == 'a' and (b := self._book(a, url))), None)
                if book:
                    links.append(book)
            if not links and mode == 'ranking':
                containers = [n for n in root.walk() if n.tag == 'ol' or any(n.has_class(c) for c in ('ranklist', 'ranking', 'toplist'))]
                for container in containers:
                    links.extend(book for a in container.walk() if a.tag == 'a' and (book := self._book(a, url)))
        if len(links) > 5000:
            raise UnknownTemplate('榜单单次书目数量超出限制')
        if not links:
            empty = any(phrase in root.text() for phrase in ('没有找到相关', '没有搜索到', '暂无相关', '无相关结果', '搜索结果为0'))
            if mode == 'site_search' and empty:
                return [], None, reader
            raise UnknownTemplate('榜单没有可识别的受支持书目，未将未知模板记为搜索完毕')
        if mode in ('article', 'annual_article'):
            return links, None, reader
        next_urls = []
        for anchor in root.walk():
            if anchor.tag != 'a':
                continue
            if (anchor.text().strip() not in ('下一页', '下一頁', '下页', '下頁', 'Next', 'next', '›', '»', '>')
                    and 'next' not in anchor.attrs.get('rel', '').split()):
                continue
            try:
                target = safe_url(anchor.attrs.get('href', ''), self.adapter, url)
            except ValueError:
                raise UnknownTemplate('榜单下一页地址不受支持') from None
            if target not in next_urls:
                next_urls.append(target)
        if len(next_urls) > 1:
            raise UnknownTemplate('榜单存在相互冲突的下一页链接')
        if not next_urls:
            # Some lists expose numbered links rather than a "next" anchor.
            # Only use an explicitly marked current position in pagination.
            for pagination in root.walk():
                if not any(pagination.has_class(c) for c in ('pagination', 'pages', 'pagebar')):
                    continue
                numbered = [n for n in pagination.walk() if n.tag == 'a' and n.text().strip().isdigit()]
                if not numbered:
                    continue
                current = [n for n in pagination.walk() if n.text().strip().isdigit()
                           and (n.has_class('current') or n.has_class('active') or n.attrs.get('aria-current') == 'page')]
                if len(current) != 1:
                    raise UnknownTemplate('无法确定数字翻页的当前位置')
                position = int(current[0].text().strip())
                forward = [n for n in numbered if int(n.text().strip()) == position + 1]
                targets = {safe_url(n.attrs.get('href', ''), self.adapter, url) for n in forward}
                if len(targets) > 1:
                    raise UnknownTemplate('数字翻页存在冲突链接')
                if targets:
                    next_urls = list(targets)
                    break
                if any(int(n.text().strip()) > position for n in numbered):
                    raise UnknownTemplate('数字翻页缺少相邻的下一页')
        return links, ({'url': next_urls[0], 'method': 'GET'} if next_urls else None), reader

    def fetch(self, transport, request):
        transport.adapter.request = request
        try:
            if request['method'] == 'POST':
                response = transport.fetch_form(request['url'], request['fields'])
            else:
                response = transport.fetch(request['url'])
            if response.status != 200:
                raise CrawlStop('unexpected_response_status', request['url'])
            return response
        finally:
            transport.adapter.request = None
