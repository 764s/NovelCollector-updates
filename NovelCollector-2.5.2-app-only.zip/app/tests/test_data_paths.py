"""Fixed per-user storage, removed data selection, and update backup integrity."""
from contextlib import contextmanager
import http.client
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core import Manager
from downloader import Downloader
import data_paths
from data_paths import DataPathError, inspect_data, resolve_data_dir, snapshot_data
import main
from main import Application, InstanceLock, make_handler
from http.server import ThreadingHTTPServer


BASE = 'https://www.52shuku.net/wuxia/'
DIRECTORY = BASE + 'snapshot-fixture.html'
PAGES = [BASE + 'snapshot-fixture_1.html', BASE + 'snapshot-fixture_2.html']
STAMP = '2026-10-01T08:00:00+00:00'


def populated_data(root, *, wal=False):
    """Create representative data using the current application schema.

    Includes collection and task state, keyword counts, download history,
    retained file versions and settings. Never accesses a source website.
    """
    root.mkdir(parents=True)
    manager = Manager(root, auto_start=False)
    downloader = Downloader(root)
    manager.close()
    downloader.close()
    config = {'name': '测试配置 · 保存', 'start_url': DIRECTORY,
              'keywords': [{'term': '剑', 'weight': 2}, {'term': '雨', 'weight': 0.5}],
              'max_books': 2, 'pages_per_book': 3, 'max_body_pages': 100,
              'max_requests': 160, 'interval': 3.2}
    old_config = {**config, 'name': '任务创建时配置'}
    state = {'stage': 'body', 'seed_kind': 'directory', 'seed_url': DIRECTORY,
             'directories': [DIRECTORY], 'book_index': 0, 'page_index': 1,
             'books_done': 0, 'body_attempts': 2, 'successful_body_pages': 2,
             'request_count': 6, 'reused_304': 1, 'reused_hash': 0, 'recounted': 1,
             'current_url': PAGES[1]}
    app = sqlite3.connect(root / 'app.db')
    app.execute('PRAGMA journal_mode=WAL')
    app.execute('PRAGMA wal_autocheckpoint=0')
    dump = lambda value: json.dumps(value, ensure_ascii=False)
    app.execute('INSERT INTO collections VALUES(?,?,?,?,?)', ('collection-test', dump(config), 7, STAMP, STAMP))
    app.executemany('INSERT INTO jobs VALUES(?,?,?,?,?,?,?,?,?,?)', [
        ('job-paused', 'collection-test', 'paused', dump(config), 7, dump(state), 'manual_pause', STAMP, STAMP, None),
        ('job-completed', 'collection-test', 'completed', dump(old_config), 6, dump(state), None, STAMP, STAMP, STAMP),
    ])
    book = {'title': '合成测试书', 'body_urls': PAGES, 'checked_at': STAMP,
            'source_updated_at': None, 'snippets': ['剑雨测试'], 'latest_job_id': 'job-paused'}
    app.execute('INSERT INTO books VALUES(?,?,?)', ('collection-test', DIRECTORY, dump(book)))
    for index, url in enumerate(PAGES):
        page = {'url': url, 'counts': {'剑': 3 + index, '雨': 1}, 'body_hash': f'body-{index}',
                'status': 'counted', 'checked_at': STAMP, 'etag': f'"v{index}"',
                'last_modified': 'Thu, 01 Oct 2026 08:00:00 GMT', 'source_updated_at': STAMP}
        app.execute('INSERT INTO pages VALUES(?,?,?,?)', ('collection-test', DIRECTORY, url, dump(page)))
    app.commit()
    download = sqlite3.connect(root / 'downloads.db')
    if wal:
        download.execute('PRAGMA journal_mode=WAL')
        download.execute('PRAGMA wal_autocheckpoint=0')
    for name, text in [('first-v1.txt', '历史版本，原样保留\n'), ('current-v2.txt', '最新版本，原样保留\n')]:
        (root / 'downloads' / name).write_text(text, encoding='utf-8-sig')
    record = {'id': 'download-test', 'url': PAGES[0], 'directory_url': DIRECTORY,
              'title': '合成测试书', 'filename': 'current-v2.txt', 'body_hash': 'new-hash',
              'downloaded_at': STAMP, 'checked_at': STAMP, 'status': 'updated',
              'versions': [{'filename': 'first-v1.txt', 'downloaded_at': STAMP, 'body_hash': 'first-hash'}]}
    job = {'id': 'download-job-test', 'status': 'paused', 'created_at': STAMP, 'updated_at': STAMP,
           'items': [{'url': url, 'directory_url': DIRECTORY, 'title': '合成测试书'} for url in PAGES],
           'completed': [PAGES[0]], 'request_count': 3, 'downloaded': 1, 'unchanged': 0,
           'rights_confirmed': True, 'message': '用户暂停', 'error': None}
    download.execute('INSERT INTO downloads VALUES(?,?,?)', (record['id'], record['url'], dump(record)))
    download.execute('INSERT INTO download_jobs VALUES(?,?)', (job['id'], dump(job)))
    download.commit()
    (root / 'settings.json').write_text(dump({'export_encoding': 'utf-8-sig', 'name': '原配置'}), encoding='utf-8')
    (root / 'downloads' / 'empty-folder').mkdir()
    if wal:
        return [app, download]
    app.close()
    download.close()
    return []



def equivalent_data(first, second):
    a, b = inspect_data(first), inspect_data(second)
    return a['databases'] == b['databases'] and a['files'] == b['files']


@contextmanager
def working_directory(path):
    previous = Path.cwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(previous)


class FixedDataPathTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name).resolve()
        self.user = self.root / 'user'
        self.environment = patch.dict(os.environ, {'HOME': str(self.user),
            'XDG_DATA_HOME': str(self.root / 'user-data')}, clear=False)
        self.environment.start()
        self.platform = patch('data_paths.sys.platform', 'linux')
        self.platform.start()
        self.addCleanup(self.temp.cleanup)
        self.addCleanup(self.environment.stop)
        self.addCleanup(self.platform.stop)

    def test_linux_uses_absolute_xdg_directory(self):
        expected = self.root / 'user-data' / 'NovelCollector' / 'data'
        self.assertEqual(resolve_data_dir(), expected)
        self.assertFalse(expected.exists())

    def test_linux_empty_missing_and_relative_xdg_use_home_default(self):
        for value in ('', 'relative/location', None):
            with self.subTest(value=value), patch.dict(os.environ):
                if value is None:
                    os.environ.pop('XDG_DATA_HOME', None)
                else:
                    os.environ['XDG_DATA_HOME'] = value
                self.assertEqual(resolve_data_dir(), self.user / '.local/share/NovelCollector/data')

    def test_windows_uses_local_app_data(self):
        with patch('data_paths.sys.platform', 'win32'), patch.dict(os.environ,
                {'LOCALAPPDATA': str(self.root / 'Windows User' / 'AppData' / 'Local')}):
            self.assertEqual(resolve_data_dir(), self.root / 'Windows User/AppData/Local/NovelCollector/data')

    def test_windows_missing_local_app_data_has_stable_home_default(self):
        with patch('data_paths.sys.platform', 'win32'), patch.dict(os.environ), patch('data_paths.Path.home', return_value=self.user):
            os.environ.pop('LOCALAPPDATA', None)
            self.assertEqual(resolve_data_dir(), self.user / 'AppData/Local/NovelCollector/data')

    def test_windows_relative_local_app_data_is_rejected(self):
        with patch('data_paths.sys.platform', 'win32'), patch.dict(os.environ, {'LOCALAPPDATA': 'relative'}):
            with self.assertRaises(DataPathError):
                resolve_data_dir()

    def test_install_move_and_legacy_config_cannot_select_or_import_data(self):
        expected = resolve_data_dir()
        for name in ('first extraction', 'moved extraction'):
            installation = self.root / name
            (installation / 'data').mkdir(parents=True)
            old_file = installation / 'data/app.db'
            old_file.write_bytes(b'legacy database must not be read or changed')
            config = installation / 'config.json'
            config.write_text('{deliberately malformed legacy config')
            with patch.object(main, 'HOME', installation), patch.dict(os.environ,
                    {'NOVELCOLLECTOR_HOME': str(installation)}), working_directory(installation):
                self.assertEqual(resolve_data_dir(), expected)
                app = Application()
                try:
                    self.assertEqual(app.data_dir, expected)
                    self.assertEqual(app.snapshot()['collections'], [])
                    self.assertNotIn('setup', app.snapshot())
                finally:
                    app.close()
            self.assertEqual(old_file.read_bytes(), b'legacy database must not be read or changed')
            self.assertEqual(config.read_text(), '{deliberately malformed legacy config')
        self.assertTrue((expected / 'app.db').is_file())

    def test_first_launch_needs_no_selection_and_reopens_same_saved_data(self):
        installation = self.root / 'program'
        installation.mkdir()
        with patch.object(main, 'HOME', installation):
            first = Application()
            try:
                collection = first.manager.create_collection({'name': 'Persistent collection',
                    'start_url': DIRECTORY, 'keywords': [{'term': '剑', 'weight': 2}]})
                location = first.data_dir
            finally:
                first.close()
            second = Application()
            try:
                self.assertEqual(second.data_dir, location)
                self.assertEqual(second.snapshot()['collections'][0]['id'], collection['id'])
            finally:
                second.close()
        self.assertFalse((installation / 'config.json').exists())
        self.assertFalse((installation / 'data').exists())

    def test_data_selection_python_api_is_removed(self):
        self.assertFalse(hasattr(data_paths, 'save_data_dir'))
        self.assertFalse(hasattr(data_paths, 'import_data_dir'))
        self.assertFalse(hasattr(main, 'SetupApplication'))
        with self.assertRaises(TypeError):
            Application(self.root)
        for kwargs in ({'explicit': self.root}, {'new_data': True}, {'import_data': self.root}):
            with self.subTest(kwargs=kwargs), self.assertRaises(TypeError):
                resolve_data_dir(**kwargs)

    def test_cli_has_no_data_selection_and_rejects_old_options(self):
        script = str(Path(main.__file__).resolve())
        help_result = subprocess.run([sys.executable, script, '--help'], capture_output=True, text=True, timeout=10)
        self.assertEqual(help_result.returncode, 0, help_result.stderr)
        for option in ('--data-dir', '--new-data', '--import-data'):
            with self.subTest(option=option):
                self.assertNotIn(option, help_result.stdout)
                result = subprocess.run([sys.executable, script, option], capture_output=True, text=True, timeout=10)
                self.assertEqual(result.returncode, 2)
                self.assertIn('unrecognized arguments', result.stderr)
        self.assertFalse(resolve_data_dir().exists())

    def test_existing_partial_or_corrupt_data_is_never_reinitialized(self):
        target = resolve_data_dir()
        target.mkdir(parents=True)
        (target / 'app.db').write_bytes(b'broken database')
        with self.assertRaises(DataPathError):
            Application()
        self.assertEqual((target / 'app.db').read_bytes(), b'broken database')
        self.assertFalse((target / 'downloads.db').exists())
        # Failure releases the lock instead of wedging all future launches.
        lock = InstanceLock(target / '.instance.lock')
        lock.close()

    def test_schema_validation_occurs_under_exclusive_instance_lock(self):
        first = Application()
        try:
            with patch('main.inspect_data') as inspected:
                with self.assertRaises(RuntimeError):
                    Application()
                inspected.assert_not_called()
        finally:
            first.close()

    def test_no_setup_page_script_or_action_is_exposed(self):
        app = Application()
        server = ThreadingHTTPServer(('127.0.0.1', 0), make_handler(app))
        app.server = server
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            connection = http.client.HTTPConnection('127.0.0.1', server.server_port, timeout=5)
            for path in ('/setup.html', '/setup.js'):
                connection.request('GET', path)
                response = connection.getresponse()
                self.assertEqual(response.status, 404)
                response.read()
            connection.request('GET', '/')
            response = connection.getresponse()
            self.assertEqual(response.status, 200)
            self.assertNotIn(b'setup.js', response.read())
            connection.request('POST', '/api/setup', json.dumps({'mode': 'new'}),
                {'Content-Type': 'application/json', 'X-App-Token': app.token})
            response = connection.getresponse()
            self.assertEqual(response.status, 400)
            response.read()
            connection.close()
        finally:
            server.shutdown()
            server.server_close()
            thread.join(5)
            app.close()


class SnapshotTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name).resolve()
        self.source = self.root / 'data'
        populated_data(self.source)
        self.lock = InstanceLock(self.source / '.instance.lock')
        self.addCleanup(self.temp.cleanup)
        self.addCleanup(self.lock.close)

    def test_snapshot_keeps_database_values_all_files_and_original_bytes(self):
        target = self.root / 'backup'
        before = inspect_data(self.source)
        original_bytes = {name: (self.source / name).read_bytes() for name in data_paths.SCHEMA}
        self.assertEqual(snapshot_data(self.source, target), target)
        self.assertTrue(equivalent_data(self.source, target))
        self.assertEqual(before, inspect_data(self.source))
        for name, contents in original_bytes.items():
            self.assertEqual((self.source / name).read_bytes(), contents)
        self.assertTrue((target / 'downloads/empty-folder').is_dir())
        for name in data_paths._TRANSIENT:
            self.assertFalse((target / name).exists())

    def test_backup_flushes_writable_copies_before_preserving_readonly_metadata(self):
        note = self.source / 'read-only.txt'
        note.write_bytes(b'preserve this file')
        note.chmod(0o444)
        target = self.root / 'writable-flush-backup'
        original_fsync = os.fsync
        def require_writable(descriptor):
            # A zero-byte write reproduces Windows' writable-handle requirement
            # without changing file contents, including on Linux test runners.
            os.write(descriptor, b'')
            original_fsync(descriptor)
        try:
            with patch('data_paths.os.fsync', side_effect=require_writable), patch('data_paths._fsync_directory'):
                snapshot_data(self.source, target)
            self.assertTrue(equivalent_data(self.source, target))
            self.assertEqual((target / note.name).read_bytes(), b'preserve this file')
            self.assertEqual((target / note.name).stat().st_mode & 0o777, note.stat().st_mode & 0o777)
        finally:
            note.chmod(0o644)
            if (target / note.name).exists():
                (target / note.name).chmod(0o644)

    def test_wal_only_commits_in_both_databases_are_copied(self):
        source = self.root / 'wal-data'
        connections = populated_data(source, wal=True)
        lock = InstanceLock(source / '.instance.lock')
        try:
            for name in data_paths.SCHEMA:
                self.assertGreater((source / (name + '-wal')).stat().st_size, 0)
            target = self.root / 'wal-backup'
            before = inspect_data(source)
            wal_bytes = {name: (source / (name + '-wal')).read_bytes() for name in data_paths.SCHEMA}
            snapshot_data(source, target)
            self.assertTrue(equivalent_data(source, target))
            self.assertEqual(before, inspect_data(source))
            self.assertEqual(inspect_data(target)['databases']['app.db']['counts']['jobs'], 2)
            for name, contents in wal_bytes.items():
                self.assertEqual((source / (name + '-wal')).read_bytes(), contents)
            for name in data_paths._TRANSIENT:
                self.assertFalse((target / name).exists())
        finally:
            lock.close()
            for connection in connections:
                connection.close()

    def test_failed_copy_preserves_source_and_removes_only_staging_files(self):
        before = inspect_data(self.source)
        target = self.root / 'failed-backup'
        with patch('data_paths.shutil.copyfile', side_effect=OSError('simulated full disk')):
            with self.assertRaises(DataPathError):
                snapshot_data(self.source, target)
        self.assertFalse(target.exists())
        self.assertFalse(list(self.root.glob('.failed-backup.copy-*')))
        self.assertEqual(before, inspect_data(self.source))

    def test_existing_empty_nested_and_same_targets_are_never_overwritten(self):
        target = self.root / 'already-exists'
        target.mkdir()
        for destination in (target, self.source / 'backup', self.source):
            with self.subTest(destination=destination), self.assertRaises(DataPathError):
                snapshot_data(self.source, destination)
        self.assertEqual(list(target.iterdir()), [])
        self.assertFalse((self.source / 'backup').exists())

    def test_destination_created_at_publication_is_not_replaced(self):
        target = self.root / 'racing-destination'
        rename = data_paths._rename_absent
        def competing_mkdir(staging, destination):
            destination.mkdir()
            return rename(staging, destination)
        with patch('data_paths._rename_absent', side_effect=competing_mkdir):
            with self.assertRaises(DataPathError):
                snapshot_data(self.source, target)
        self.assertEqual(list(target.iterdir()), [])
        self.assertFalse(list(self.root.glob('.racing-destination.copy-*')))
        self.assertEqual(inspect_data(self.source)['databases']['app.db']['counts']['jobs'], 2)

    def test_incomplete_download_history_blocks_backup(self):
        (self.source / 'downloads/first-v1.txt').unlink()
        with self.assertRaises(DataPathError):
            inspect_data(self.source)
        with self.assertRaises(DataPathError):
            snapshot_data(self.source, self.root / 'incomplete')
        self.assertFalse((self.root / 'incomplete').exists())

    def test_malicious_download_reference_is_rejected(self):
        with sqlite3.connect(self.source / 'downloads.db') as db:
            record = json.loads(db.execute('SELECT data FROM downloads').fetchone()[0])
            record['filename'] = '../settings.json'
            db.execute('UPDATE downloads SET data=?', (json.dumps(record),))
        with self.assertRaises(DataPathError):
            inspect_data(self.source)

    def test_symlinked_paths_or_data_files_are_rejected(self):
        linked = self.root / 'linked-data'
        try:
            linked.symlink_to(self.source, target_is_directory=True)
        except (OSError, NotImplementedError):
            self.skipTest('platform does not permit test symlinks')
        with self.assertRaises(DataPathError):
            inspect_data(linked)
        (self.source / 'downloads/link.txt').symlink_to(self.source / 'settings.json')
        with self.assertRaises(DataPathError):
            snapshot_data(self.source, self.root / 'linked-copy')
        self.assertFalse((self.root / 'linked-copy').exists())

    def test_database_extra_tables_are_copied_without_migration(self):
        with sqlite3.connect(self.source / 'app.db') as db:
            db.execute('CREATE TABLE notes(id TEXT, contents BLOB)')
            db.execute('INSERT INTO notes VALUES(?,?)', ('n', b'\x00\x01\xff'))
        target = self.root / 'metadata-backup'
        snapshot_data(self.source, target)
        self.assertTrue(equivalent_data(self.source, target))

    def test_unsupported_schema_markers_fail_closed(self):
        for marker in ('user_version', 'application_id'):
            with self.subTest(marker=marker):
                with sqlite3.connect(self.source / 'app.db') as db:
                    db.execute('PRAGMA ' + marker + '=99')
                with self.assertRaises(DataPathError):
                    inspect_data(self.source)
                with self.assertRaises(DataPathError):
                    snapshot_data(self.source, self.root / 'unsupported')
                with sqlite3.connect(self.source / 'app.db') as db:
                    db.execute('PRAGMA ' + marker + '=0')
        self.assertFalse((self.root / 'unsupported').exists())

    def test_missing_tables_and_columns_are_rejected(self):
        for malformed in ('DROP TABLE collections', 'ALTER TABLE collections RENAME COLUMN config TO wrong'):
            target = self.root / ('malformed-' + str(len(malformed)))
            populated_data(target)
            with sqlite3.connect(target / 'app.db') as db:
                db.execute(malformed)
            with self.assertRaises(DataPathError):
                inspect_data(target)

    def test_read_only_inspection_does_not_issue_writes(self):
        statements = []
        original = data_paths._open_database
        def traced(path):
            db = original(path)
            db.set_trace_callback(statements.append)
            return db
        with patch('data_paths._open_database', side_effect=traced):
            inspect_data(self.source)
        forbidden = ('INSERT ', 'UPDATE ', 'DELETE ', 'CREATE ', 'ALTER ', 'DROP ', 'VACUUM', 'REPLACE ')
        self.assertFalse([sql for sql in statements if sql.upper().lstrip().startswith(forbidden)])


if __name__ == '__main__':
    unittest.main()
