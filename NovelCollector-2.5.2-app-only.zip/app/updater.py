"""App-only, offline updates for the bundled desktop package.

The archive is untrusted executable software. SHA-256 checks detect corruption,
not publisher identity. Inspect/stage never import or execute archive contents.
The caller must obtain consent, stop all data writers and back up data before
calling install/rollback. Neither operation modifies runtime, bootstrap or data.

Format: manifest.json + app/*, installed to releases/<version>/app.
A single atomic active-release.json change selects the next launch and records
its predecessor. Existing releases are never overwritten or deleted.
"""
from contextlib import contextmanager
import ctypes
import hashlib
import io
import json
import os
from pathlib import Path
import platform as platform_module
import re
import secrets
import shutil
import stat
import sys
import threading
import zipfile
import zlib

SCHEMA = 1
DATA_FORMAT = 1
RUNTIME = 'cpython-3.14.8'
MAX_ARCHIVE_BYTES = 20 * 1024 * 1024
MAX_UNPACKED_BYTES = 20 * 1024 * 1024
MAX_FILES = 100
MAX_MANIFEST_BYTES = 128 * 1024
_VERSION = re.compile(r'(0|[1-9][0-9]{0,8})\.(0|[1-9][0-9]{0,8})\.(0|[1-9][0-9]{0,8})\Z')
_HASH = re.compile(r'[0-9a-f]{64}\Z')
_STAGE = re.compile(r'[0-9a-f]{32}\Z')
_COMPONENT = re.compile(r'[A-Za-z0-9_][A-Za-z0-9_.-]*\Z')
_RESERVED = {'CON', 'PRN', 'AUX', 'NUL', 'CLOCK$', 'CONIN$', 'CONOUT$'} | {
    p + str(n) for p in ('COM', 'LPT') for n in range(1, 10)}


class UpdateError(ValueError):
    """An update was rejected before changing the active release."""


def _version(value):
    if not isinstance(value, str) or not _VERSION.fullmatch(value):
        raise UpdateError('版本号必须是三段非负整数，例如 2.1.1')
    return tuple(int(part) for part in value.split('.'))


def _json(raw):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise UpdateError('JSON 中有重复字段')
            result[key] = value
        return result
    try:
        return json.loads(raw, object_pairs_hook=unique)
    except (ValueError, UnicodeError, RecursionError) as exc:
        if isinstance(exc, UpdateError):
            raise
        raise UpdateError('更新元数据不是有效的 JSON') from exc


def _bytes(value):
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(',', ':')).encode('ascii')


def _plain_integer(value, expected):
    return type(value) is int and value == expected


def _not_link(path):
    """Reject POSIX symlinks and Windows reparse points, including junctions."""
    try:
        mode = path.lstat()
    except FileNotFoundError:
        return
    if stat.S_ISLNK(mode.st_mode) or getattr(mode, 'st_file_attributes', 0) & 0x400:
        raise UpdateError('更新目录不能包含符号链接或重解析点')


def _safe_chain(home, target):
    try:
        parts = target.relative_to(home).parts
    except ValueError as exc:
        raise UpdateError('更新路径越出了程序目录') from exc
    current = home
    _not_link(current)
    for part in parts:
        current = current / part
        _not_link(current)


def _regular(path):
    _not_link(path)
    try:
        info = path.stat()
        if not stat.S_ISREG(info.st_mode):
            raise UpdateError('更新文件不是普通文件')
        if info.st_nlink != 1:
            raise UpdateError('更新文件不能是硬链接')
    except FileNotFoundError as exc:
        raise UpdateError('更新文件缺失') from exc


def _read_json_file(home, path, limit=MAX_MANIFEST_BYTES):
    _safe_chain(home, path)
    _regular(path)
    if path.stat().st_size > limit:
        raise UpdateError('更新元数据过大')
    with path.open('rb') as stream:
        raw = stream.read(limit + 1)
    if len(raw) > limit:
        raise UpdateError('更新元数据过大')
    return _json(raw)


def _descriptor(value):
    if not isinstance(value, dict) or set(value) != {'version', 'path'}:
        raise UpdateError('版本指针格式无效')
    _version(value['version'])
    if value['path'] != 'releases/' + value['version'] + '/app':
        raise UpdateError('版本指针指向了不允许的目录')
    return dict(value)


def _check_release(home, descriptor):
    descriptor = _descriptor(descriptor)
    target = home / descriptor['path']
    _safe_chain(home, target / 'main.py')
    if not target.is_dir():
        raise UpdateError('版本目录缺失')
    _regular(target / 'main.py')
    return target


def _pointer(home, default_version):
    path = home / 'active-release.json'
    _safe_chain(home, path)
    if path.exists():
        value = _read_json_file(home, path)
        if (not isinstance(value, dict) or set(value) != {'schema', 'version', 'path', 'previous'}
                or not _plain_integer(value.get('schema'), SCHEMA)):
            raise UpdateError('活动版本指针格式无效')
        current = _descriptor({key: value[key] for key in ('version', 'path')})
        previous = value['previous']
        if previous is not None:
            previous = _descriptor(previous)
            if previous == current:
                raise UpdateError('回退版本不能与活动版本相同')
    else:
        _version(default_version)
        current = {'version': default_version, 'path': 'releases/' + default_version + '/app'}
        previous = None
    _check_release(home, current)
    return {'schema': SCHEMA, **current, 'previous': previous}


def resolve_active_release(package_dir, default_version):
    """Validate the pointer and return the app directory, without executing it.

    The permanent bootstrap must provide its own bundled fallback version. It
    must not import this updatable module before choosing a trusted local path.
    """
    home = Path(os.path.abspath(package_dir))
    return _check_release(home, {k: v for k, v in _pointer(home, default_version).items()
                                if k in ('version', 'path')})


def _member_path(name, directory=False):
    if not isinstance(name, str) or len(name) > 220 or '\\' in name or '\x00' in name:
        raise UpdateError('更新包包含不安全的文件名')
    path = name[:-1] if directory and name.endswith('/') else name
    components = path.split('/')
    if len(components) > 16 or any(
        not _COMPONENT.fullmatch(part) or len(part) > 100 or part.endswith(('.', ' '))
        or part.split('.')[0].upper() in _RESERVED for part in components
    ):
        raise UpdateError('更新包包含不安全或 Windows 不兼容的路径')
    if components[0] != 'app' or (len(components) < 2 and not directory):
        raise UpdateError('更新包只能包含 app 目录中的程序文件')
    # Bytecode and native binaries have different runtime contracts and are not
    # part of this app-only format. Python imports must compile their own source.
    if not directory and (path.lower().endswith(('.pyc', '.pyo', '.dll', '.exe', '.pyd', '.so', '.dylib'))
                          or '__pycache__' in components):
        raise UpdateError('更新包不能包含缓存字节码、运行时或本机可执行文件')
    return path


def _manifest(value, runtime, platform):
    expected = {'schema', 'version', 'runtime', 'platforms', 'data_format', 'files'}
    if not isinstance(value, dict) or set(value) not in (expected, expected | {'minimum_updater'}):
        raise UpdateError('更新清单字段不完整或包含未知字段')
    if 'minimum_updater' in value:
        _version(value['minimum_updater'])
    if not _plain_integer(value['schema'], SCHEMA):
        raise UpdateError('不支持此更新清单格式')
    if not _plain_integer(value['data_format'], DATA_FORMAT):
        raise UpdateError('此更新需要不兼容的数据格式，请使用完整安装包')
    _version(value['version'])
    if value['runtime'] != runtime:
        raise UpdateError('此更新需要不同的 Python 运行时，请使用完整安装包')
    platforms = value['platforms']
    if (not isinstance(platforms, list) or not platforms
            or any(type(p) is not str or p not in ('windows-x64', 'linux-x64') for p in platforms)
            or len(set(platforms)) != len(platforms) or platform not in platforms):
        raise UpdateError('更新包不支持当前操作系统或架构')
    files = value['files']
    if not isinstance(files, dict) or not 1 <= len(files) <= MAX_FILES or 'app/main.py' not in files:
        raise UpdateError('更新清单文件数无效或缺少 app/main.py')
    seen = set()
    for name, digest in files.items():
        _member_path(name)
        folded = name.casefold()
        if folded in seen or not isinstance(digest, str) or not _HASH.fullmatch(digest):
            raise UpdateError('更新清单有重复路径或无效 SHA-256')
        seen.add(folded)
    for name in seen:
        if any('/'.join(name.split('/')[:i]) in seen for i in range(1, len(name.split('/')))):
            raise UpdateError('文件路径与目录冲突')
    return value


def _detected_platform():
    machine = platform_module.machine().lower()
    if machine not in ('x86_64', 'amd64'):
        raise UpdateError('此更新器仅支持 x64 安装包')
    if sys.platform == 'win32':
        return 'windows-x64'
    if sys.platform.startswith('linux'):
        return 'linux-x64'
    raise UpdateError('此更新器不支持当前平台')


def _rename_absent(source, target):
    """Atomically promote a directory without replacing even an empty target."""
    if os.name == 'nt':
        os.rename(source, target)  # Windows rename refuses an existing target.
        return
    library = ctypes.CDLL(None, use_errno=True)
    if not sys.platform.startswith('linux') or not hasattr(library, 'renameat2'):
        raise UpdateError('当前系统不支持安全的原子更新目录安装')
    rename = library.renameat2
    rename.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
    rename.restype = ctypes.c_int
    result = rename(-100, os.fsencode(source), -100, os.fsencode(target), 1)  # RENAME_NOREPLACE
    if result:
        code = ctypes.get_errno()
        raise OSError(code, os.strerror(code), str(target))


def _fsync_directory(path):
    # Windows does not expose directory fsync through os.open. Atomic replace is
    # still used; failures on platforms supporting directory fsync are surfaced.
    if os.name == 'nt':
        return
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


class Updater:
    def __init__(self, package_dir, current_version, platform=None, runtime_tag=RUNTIME):
        self.home = Path(os.path.abspath(package_dir))
        _not_link(self.home)
        _version(current_version)
        self.current_version = current_version
        self.platform = platform or _detected_platform()
        self.runtime = runtime_tag
        if self.platform not in ('linux-x64', 'windows-x64') or self.runtime != RUNTIME:
            raise UpdateError('安装包运行时或平台不受支持')
        compatibility = self.home / 'runtime-compat.json'
        _safe_chain(self.home, compatibility)
        if compatibility.exists():
            value = _read_json_file(self.home, compatibility)
            if (not isinstance(value, dict) or set(value) != {'schema', 'data_format', 'runtime', 'platform'}
                    or not _plain_integer(value['schema'], SCHEMA)
                    or not _plain_integer(value['data_format'], DATA_FORMAT)
                    or value['runtime'] != self.runtime or value['platform'] != self.platform):
                raise UpdateError('安装包运行时兼容信息无效')
        self._staged = {}
        self._thread_lock = threading.RLock()

    @contextmanager
    def _transaction(self):
        with self._thread_lock:
            path = self.home / '.update.lock'
            _safe_chain(self.home, path)
            flags = os.O_RDWR | os.O_CREAT | getattr(os, 'O_NOFOLLOW', 0)
            fd = os.open(path, flags, 0o600)
            stream = os.fdopen(fd, 'r+b')
            acquired = False
            try:
                _regular(path)
                if os.name == 'nt':
                    import msvcrt
                    if os.fstat(fd).st_size == 0:
                        stream.write(b'0')
                        stream.flush()
                    stream.seek(0)
                    try:
                        msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
                    except OSError as exc:
                        raise UpdateError('另一个程序正在处理更新，请稍后重试') from exc
                else:
                    import fcntl
                    try:
                        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    except OSError as exc:
                        raise UpdateError('另一个程序正在处理更新，请稍后重试') from exc
                acquired = True
                yield
            finally:
                if acquired and os.name == 'nt':
                    stream.seek(0)
                    msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
                stream.close()

    def _read_active(self):
        return _pointer(self.home, self.current_version)

    def status(self):
        active = self._read_active()
        return {'current_version': active['version'], 'running_version': self.current_version,
                'pending_restart': active['version'] != self.current_version,
                'can_rollback': active['previous'] is not None,
                'previous_version': active['previous']['version'] if active['previous'] else None,
                'platform': self.platform, 'runtime': self.runtime, 'data_format': DATA_FORMAT,
                'max_archive_bytes': MAX_ARCHIVE_BYTES}

    def _inspect(self, archive):
        if not isinstance(archive, bytes) or not archive or len(archive) > MAX_ARCHIVE_BYTES:
            raise UpdateError('更新包必须是非空 ZIP，且不能超过 20 MiB')
        try:
            with zipfile.ZipFile(io.BytesIO(archive)) as bundle:
                members = bundle.infolist()
                if not members or len(members) > MAX_FILES * 2 + 1:
                    raise UpdateError('更新包文件条目过多')
                seen, entries, directories = set(), {}, set()
                total = 0
                for info in members:
                    name = info.filename
                    if info.orig_filename != name or info.flag_bits & 1:
                        raise UpdateError('不支持加密文件或带空字符的路径')
                    is_dir = info.is_dir()
                    if name != 'manifest.json':
                        _member_path(name, is_dir)
                    key = name.rstrip('/').casefold()
                    if key in seen:
                        raise UpdateError('更新包包含重复或大小写冲突的路径')
                    seen.add(key)
                    mode = info.external_attr >> 16
                    kind = stat.S_IFMT(mode)
                    if kind not in (0, stat.S_IFDIR if is_dir else stat.S_IFREG):
                        raise UpdateError('更新包包含链接或特殊文件')
                    if info.external_attr & 0x400:
                        raise UpdateError('更新包包含 Windows 重解析点')
                    if info.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):
                        raise UpdateError('更新包使用了不支持的压缩方式')
                    if is_dir:
                        if info.file_size:
                            raise UpdateError('目录条目不能包含内容')
                        directories.add(name.rstrip('/'))
                        continue
                    if info.file_size < 0 or info.file_size > MAX_UNPACKED_BYTES:
                        raise UpdateError('更新包展开后过大')
                    total += info.file_size
                    if total > MAX_UNPACKED_BYTES + MAX_MANIFEST_BYTES:
                        raise UpdateError('更新包展开后超过 20 MiB')
                    entries[name] = info
                if 'manifest.json' not in entries or entries['manifest.json'].file_size > MAX_MANIFEST_BYTES:
                    raise UpdateError('更新包缺少有效的 manifest.json')
                manifest = _manifest(_json(bundle.read(entries['manifest.json'])), self.runtime, self.platform)
                if set(entries) != {'manifest.json', *manifest['files']}:
                    raise UpdateError('更新包文件列表与清单不一致')
                if any(not any(name.startswith(directory + '/') for name in manifest['files']) for directory in directories):
                    raise UpdateError('更新包包含清单之外的空目录')
                if _version(manifest.get('minimum_updater', '0.0.0')) > _version(self.current_version):
                    raise UpdateError('此更新需要新版更新器，请下载完整包')
                active = self._read_active()
                if _version(manifest['version']) <= max(_version(active['version']), _version(self.current_version)):
                    raise UpdateError('更新版本必须高于当前版本；请使用回退功能恢复旧版')
                payload, unpacked = {}, 0
                for name, digest in manifest['files'].items():
                    with bundle.open(entries[name]) as stream:
                        data = stream.read(MAX_UNPACKED_BYTES + 1)
                    unpacked += len(data)
                    if unpacked > MAX_UNPACKED_BYTES or len(data) != entries[name].file_size:
                        raise UpdateError('更新包展开大小无效或超过 20 MiB')
                    if hashlib.sha256(data).hexdigest() != digest:
                        raise UpdateError('更新文件 SHA-256 校验失败：' + name)
                    payload[name] = data
                preview = {'version': manifest['version'], 'current_version': active['version'],
                           'runtime': manifest['runtime'], 'platforms': list(manifest['platforms']),
                           'data_format': DATA_FORMAT, 'file_count': len(payload),
                           'files': sorted(payload), 'unpacked_bytes': unpacked,
                           'archive_sha256': hashlib.sha256(archive).hexdigest(),
                           'publisher_verified': False,
                           'warning': 'SHA-256 只能校验文件完整性，不能证明发布者身份；只安装可信来源的更新包。'}
                return manifest, payload, preview, active
        except (zipfile.BadZipFile, zipfile.LargeZipFile, RuntimeError, EOFError, NotImplementedError, zlib.error) as exc:
            raise UpdateError('ZIP 更新包损坏或格式不受支持') from exc

    def inspect(self, archive):
        """Validate bytes in memory; do not extract or run any archive content."""
        return self._inspect(archive)[2]

    def stage(self, archive):
        """Validate and extract to a fresh private stage; return its opaque token."""
        with self._transaction():
            if len(self._staged) >= 3:
                raise UpdateError('已有三个更新预览，请先取消旧预览再选择新包')
            manifest, payload, preview, active = self._inspect(archive)
            staging = self.home / '.update-staging'
            _safe_chain(self.home, staging)
            staging.mkdir(exist_ok=True)
            token = secrets.token_hex(16)
            target = staging / token
            target.mkdir(mode=0o700)
            try:
                for name, data in {'manifest.json': _bytes(manifest), **payload}.items():
                    path = target / name
                    _safe_chain(self.home, path)
                    path.parent.mkdir(parents=True, exist_ok=True)
                    with path.open('xb') as output:
                        output.write(data)
                        output.flush()
                        os.fsync(output.fileno())
                # Retain expected metadata in memory so a changed staged manifest
                # cannot redefine the bytes approved in this process's preview.
                for directory, _, _ in os.walk(target, topdown=False):
                    _fsync_directory(Path(directory))
                _fsync_directory(staging)
                self._staged[token] = {'manifest': manifest, 'active': active, 'preview': preview}
            except BaseException:
                shutil.rmtree(target, ignore_errors=True)
                raise
            return {**preview, 'stage_id': token}

    def discard(self, stage_id):
        """Delete only an uncommitted stage created by this updater instance."""
        with self._transaction():
            if not isinstance(stage_id, str) or not _STAGE.fullmatch(stage_id) or stage_id not in self._staged:
                raise UpdateError('更新预览已失效，请重新选择更新包')
            path = self.home / '.update-staging' / stage_id
            _safe_chain(self.home, path)
            if path.exists():
                shutil.rmtree(path)
            del self._staged[stage_id]

    def _verify_tree(self, root, manifest):
        _safe_chain(self.home, root)
        expected = {'manifest.json', *manifest['files']}
        found, total = set(), 0
        def walk_error(error):
            raise UpdateError('无法读取完整暂存版本') from error
        for directory, directories, files in os.walk(root, followlinks=False, onerror=walk_error):
            for name in directories + files:
                _safe_chain(self.home, Path(directory) / name)
            for name in files:
                path = Path(directory) / name
                _regular(path)
                relative = path.relative_to(root).as_posix()
                if relative not in expected:
                    raise UpdateError('暂存版本含有清单外文件，请重新选择更新包')
                found.add(relative)
                if path.stat().st_size > (MAX_MANIFEST_BYTES if relative == 'manifest.json' else MAX_UNPACKED_BYTES):
                    raise UpdateError('暂存版本文件过大')
                if relative == 'manifest.json':
                    if _read_json_file(self.home, path) != manifest:
                        raise UpdateError('暂存清单已改变，请重新选择更新包')
                    continue
                digest = hashlib.sha256()
                with path.open('rb') as stream:
                    while True:
                        chunk = stream.read(65536)
                        if not chunk:
                            break
                        total += len(chunk)
                        if total > MAX_UNPACKED_BYTES:
                            raise UpdateError('暂存版本文件过大')
                        digest.update(chunk)
                if digest.hexdigest() != manifest['files'][relative]:
                    raise UpdateError('暂存文件校验失败，请重新选择更新包')
        if found != expected:
            raise UpdateError('暂存版本缺少文件，请重新选择更新包')

    def _write_pointer(self, value):
        destination = self.home / 'active-release.json'
        _safe_chain(self.home, destination)
        temp = self.home / ('.active-release-' + secrets.token_hex(16) + '.tmp')
        try:
            with temp.open('xb') as output:
                output.write(_bytes(value) + b'\n')
                output.flush()
                os.fsync(output.fileno())
            os.replace(temp, destination)
            # Replacement has committed. A directory-fsync failure must not be
            # reported as a rejected update after the selection already changed.
            try:
                _fsync_directory(self.home)
            except OSError:
                print('更新指针已保存；目录同步失败，请勿立即断电。', file=sys.stderr, flush=True)
        finally:
            if temp.exists():
                temp.unlink()

    def install(self, stage_id):
        """After caller consent and consistent data backup, select staged code.

        No archive code executes. Restart through the permanent bootstrap to use
        it. A crash before pointer replacement leaves the old version selected.
        """
        with self._transaction():
            if not isinstance(stage_id, str) or not _STAGE.fullmatch(stage_id) or stage_id not in self._staged:
                raise UpdateError('更新预览已失效，请重新选择更新包')
            record = self._staged[stage_id]
            active = self._read_active()
            if active != record['active']:
                raise UpdateError('活动版本已改变，请重新预览更新包')
            manifest = record['manifest']
            if _version(manifest['version']) <= max(_version(active['version']), _version(self.current_version)):
                raise UpdateError('更新版本必须高于当前版本')
            staged = self.home / '.update-staging' / stage_id
            if record.get('promoted'):
                staged = self.home / 'releases' / manifest['version']
            self._verify_tree(staged, manifest)
            releases = self.home / 'releases'
            _safe_chain(self.home, releases)
            releases.mkdir(exist_ok=True)
            release = releases / manifest['version']
            _safe_chain(self.home, release)
            if release.exists():
                # Recover an identical orphan after a pointer-write failure, or
                # select an unchanged previously installed version. Never merge
                # into or overwrite an existing release directory.
                self._verify_tree(release, manifest)
            else:
                # Atomic directory rename is on the same package filesystem.
                # No file of a running release is ever opened for writing.
                _rename_absent(staged, release)
                record['promoted'] = True
                _fsync_directory(releases)
            new = {'schema': SCHEMA, 'version': manifest['version'],
                   'path': 'releases/' + manifest['version'] + '/app',
                   'previous': {key: active[key] for key in ('version', 'path')}}
            self._write_pointer(new)
            if not record.get('promoted'):
                shutil.rmtree(staged, ignore_errors=True)
            del self._staged[stage_id]
            return {'ok': True, 'version': new['version'], 'previous_version': active['version'],
                    'restart_required': True, 'path': new['path']}

    def rollback(self, *, minimum_version=None):
        """Select the recorded predecessor; data is not restored or modified."""
        with self._transaction():
            active = self._read_active()
            previous = active['previous']
            if previous is None:
                raise UpdateError('没有可回退的上一版本')
            if minimum_version is not None and _version(previous['version']) < _version(minimum_version):
                raise UpdateError('当前数据使用了旧版本不支持的功能，需要 v' + minimum_version +
                    ' 或更新版本，已取消回退。当前程序和数据保持不变；如需使用旧版，请退出程序后使用升级前数据备份和旧版完整包。')
            release = _check_release(self.home, previous).parent
            metadata = release / 'manifest.json'
            _safe_chain(self.home, metadata)
            # A packaged baseline may have no update manifest. Installed update
            # releases always have one and are checked before re-selection.
            if metadata.exists():
                manifest = _manifest(_read_json_file(self.home, metadata), self.runtime, self.platform)
                if manifest['version'] != previous['version']:
                    raise UpdateError('回退版本清单与指针不一致')
                self._verify_tree(release, manifest)
            new = {'schema': SCHEMA, **previous,
                   'previous': {key: active[key] for key in ('version', 'path')}}
            self._write_pointer(new)
            return {'ok': True, 'version': previous['version'], 'previous_version': active['version'],
                    'restart_required': True, 'path': new['path'], 'data_restored': False}
